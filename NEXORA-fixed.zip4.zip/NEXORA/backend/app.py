"""
NEXORA Backend — Flask application entrypoint (Phase 6 / Phase 7 scaffold)

Run locally with:
    python app.py

The app boots even without MySQL configured, so the frontend can be
demoed standalone; API routes that touch the database will return a
clear error until backend/.env is filled in and the schema is loaded
(see backend/database/schema.sql and the project README).
"""

from flask import Flask, jsonify
from flask_cors import CORS
from config import Config

from routes.auth_routes import auth_bp
from routes.product_routes import product_bp
from routes.category_routes import category_bp
from routes.cart_routes import cart_bp
from routes.wishlist_routes import wishlist_bp
from routes.order_routes import order_bp
from routes.review_routes import review_bp
from routes.contact_routes import contact_bp
from routes.newsletter_routes import newsletter_bp
from routes.admin_routes import admin_bp
from routes.payment_routes import payment_bp
from routes.shipping_routes import shipping_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Allow the static frontend (opened via Live Server / file server) to call this API.
    # Restricted to known local dev origins by default — see CORS_ORIGINS in config.py.
    CORS(app, resources={r"/api/*": {"origins": Config.CORS_ORIGINS}}, supports_credentials=True)

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(product_bp, url_prefix="/api/products")
    app.register_blueprint(category_bp, url_prefix="/api/categories")
    app.register_blueprint(cart_bp, url_prefix="/api/cart")
    app.register_blueprint(wishlist_bp, url_prefix="/api/wishlist")
    app.register_blueprint(order_bp, url_prefix="/api/orders")
    app.register_blueprint(review_bp, url_prefix="/api/reviews")
    app.register_blueprint(contact_bp, url_prefix="/api/contact")
    app.register_blueprint(newsletter_bp, url_prefix="/api/newsletter")
    app.register_blueprint(admin_bp, url_prefix="/api/admin")
    app.register_blueprint(payment_bp, url_prefix="/api/payments")
    app.register_blueprint(shipping_bp, url_prefix="/api/shipping")

    @app.get("/")
    def health():
        return jsonify({"status": "ok", "service": "NEXORA API", "message": "Server is running."})

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"success": False, "error": "Route not found"}), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify({"success": False, "error": "Internal server error"}), 500

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
