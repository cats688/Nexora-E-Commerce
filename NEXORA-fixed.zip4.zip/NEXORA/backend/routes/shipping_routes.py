"""
NEXORA Backend — routes/shipping_routes.py  (real courier integration)

Three real, working endpoints backed by Shiprocket (see utils/shiprocket.py):
  POST /api/shipping/serviceability  — "can you deliver to this pincode, and how fast?"
  POST /api/shipping/create-shipment — admin: hand an existing order to a real courier
  GET  /api/shipping/track/<order_id> — live tracking checkpoints for an order
"""

from flask import Blueprint, request
from datetime import datetime
from utils.db import run_query
from utils.responses import success, error
from utils.auth_middleware import token_required, admin_required
from utils import shiprocket
from utils.shiprocket import ShiprocketError

shipping_bp = Blueprint("shipping", __name__)


@shipping_bp.post("/serviceability")
def serviceability():
    """Public — used at checkout so a customer can see real delivery
    availability and an accurate ETA for their own pincode before paying."""
    data = request.get_json(silent=True) or {}
    delivery_pincode = data.get("pincode")
    if not delivery_pincode:
        return error("A delivery 'pincode' is required", 422)

    from config import Config
    if not Config.SHIPROCKET_PICKUP_LOCATION_PINCODE:
        return error(
            "Shiprocket pickup pincode not configured "
            "(SHIPROCKET_PICKUP_LOCATION_PINCODE in .env)", 503
        )

    try:
        result = shiprocket.check_serviceability(
            pickup_pincode=Config.SHIPROCKET_PICKUP_LOCATION_PINCODE,
            delivery_pincode=delivery_pincode,
            weight_kg=data.get("weight_kg", 0.5),
            cod=data.get("cod", False),
        )
    except ShiprocketError as exc:
        return error(str(exc), 502)

    couriers = (result.get("data") or {}).get("available_courier_companies") or []
    if not couriers:
        return success({"serviceable": False, "couriers": []}, "No couriers available for this pincode")

    fastest = min(couriers, key=lambda c: c.get("estimated_delivery_days", 99))
    return success({
        "serviceable": True,
        "estimated_days": fastest.get("estimated_delivery_days"),
        "cheapest_rate": min((c.get("rate", 0) for c in couriers), default=None),
        "courier_options": len(couriers),
    })


@shipping_bp.post("/create-shipment")
@admin_required
def create_shipment():
    """Admin-only: books a real courier pickup for an existing order and
    stores the resulting AWB (tracking number) back on that order."""
    data = request.get_json(silent=True) or {}
    order_id = data.get("order_id")
    if not order_id:
        return error("order_id is required", 422)

    order = run_query("SELECT * FROM orders WHERE id = %s", (order_id,), fetchone=True)
    if not order:
        return error("Order not found", 404)
    if order.get("awb_code"):
        return error("This order already has a tracking number assigned", 409)

    items = run_query(
        """SELECT oi.*, p.name AS product_name, p.sku
           FROM order_items oi JOIN products p ON p.id = oi.product_id
           WHERE oi.order_id = %s""",
        (order_id,), fetchall=True,
    )
    if not items:
        return error("Order has no items", 422)

    shiprocket_order = {
        "id": order["id"],
        "order_date": order["created_at"].strftime("%Y-%m-%d %H:%M") if isinstance(order["created_at"], datetime) else str(order["created_at"]),
        "shipping": {
            "name": order.get("shipping_name") or "Customer",
            "phone": order.get("shipping_phone") or "",
            "address": order.get("shipping_address") or "",
            "city": order.get("shipping_city") or "",
            "state": order.get("shipping_state") or "",
            "pincode": order.get("shipping_pincode") or "",
            "country": order.get("shipping_country") or "India",
        },
        "items": [
            {"name": i["product_name"], "sku": i.get("sku"), "units": i["quantity"], "price": float(i["price"]), "product_id": i["product_id"]}
            for i in items
        ],
        "payment_method": "cod",  # adjust if you store the real payment method per order
        "sub_total": float(order["total_amount"]),
        "weight_kg": sum(float(i.get("weight_kg") or 0.5) * i["quantity"] for i in items),
    }

    try:
        sr_order = shiprocket.create_order(shiprocket_order)
        shipment_id = sr_order.get("shipment_id")
        if not shipment_id:
            return error(f"Shiprocket did not return a shipment_id: {sr_order}", 502)

        awb_result = shiprocket.assign_awb(shipment_id)
        awb_data = (awb_result.get("response") or {}).get("data") or {}
        awb_code = awb_data.get("awb_code")
        courier_name = awb_data.get("courier_name")
    except ShiprocketError as exc:
        return error(str(exc), 502)

    run_query(
        """UPDATE orders SET
             status = 'shipped',
             courier_name = %s,
             awb_code = %s,
             shiprocket_order_id = %s,
             shiprocket_shipment_id = %s,
             tracking_url = %s
           WHERE id = %s""",
        (
            courier_name, awb_code,
            str(sr_order.get("order_id", "")), str(shipment_id),
            f"https://shiprocket.co/tracking/{awb_code}" if awb_code else None,
            order_id,
        ),
        commit=True,
    )

    return success({
        "awb_code": awb_code,
        "courier_name": courier_name,
        "shipment_id": shipment_id,
    }, "Shipment booked with courier")


@shipping_bp.get("/track/<int:order_id>")
@token_required
def track_order(order_id):
    """Live tracking checkpoints for one of the current user's own orders."""
    order = run_query(
        "SELECT * FROM orders WHERE id = %s AND user_id = %s",
        (order_id, request.user["sub"]), fetchone=True,
    )
    if not order:
        return error("Order not found", 404)
    if not order.get("awb_code"):
        return success({"tracked": False, "reason": "Not yet handed to a courier"})

    try:
        tracking = shiprocket.track_by_awb(order["awb_code"])
    except ShiprocketError as exc:
        return error(str(exc), 502)

    return success({
        "tracked": True,
        "courier_name": order.get("courier_name"),
        "awb_code": order["awb_code"],
        "tracking_url": order.get("tracking_url"),
        "checkpoints": tracking,
    })
