"""NEXORA Backend — Newsletter subscription route."""

from flask import Blueprint, request
from utils.db import run_query
from utils.responses import success, error

newsletter_bp = Blueprint("newsletter", __name__)


@newsletter_bp.post("/subscribe")
def subscribe():
    data = request.get_json(silent=True) or {}
    email = data.get("email")
    if not email:
        return error("email is required", 422)
    run_query(
        "INSERT IGNORE INTO newsletter_subscribers (email) VALUES (%s)",
        (email,), commit=True,
    )
    return success(None, "Subscribed", 201)
