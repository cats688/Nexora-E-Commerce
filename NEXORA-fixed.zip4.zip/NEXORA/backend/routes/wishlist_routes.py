"""NEXORA Backend — Wishlist routes (Phase 8)."""

from flask import Blueprint, request
from utils.db import run_query
from utils.responses import success, error
from utils.auth_middleware import token_required

wishlist_bp = Blueprint("wishlist", __name__)


@wishlist_bp.get("")
@token_required
def get_wishlist():
    rows = run_query(
        """SELECT w.id, p.* FROM wishlist w
           JOIN products p ON p.id = w.product_id
           WHERE w.user_id = %s""",
        (request.user["sub"],), fetchall=True,
    )
    return success(rows)


@wishlist_bp.post("/items")
@token_required
def add_item():
    data = request.get_json(silent=True) or {}
    product_id = data.get("product_id")
    if not product_id:
        return error("product_id is required", 422)
    run_query(
        "INSERT IGNORE INTO wishlist (user_id, product_id) VALUES (%s, %s)",
        (request.user["sub"], product_id), commit=True,
    )
    return success(None, "Added to wishlist", 201)


@wishlist_bp.delete("/items/<int:product_id>")
@token_required
def remove_item(product_id):
    run_query(
        "DELETE FROM wishlist WHERE user_id = %s AND product_id = %s",
        (request.user["sub"], product_id), commit=True,
    )
    return success(None, "Removed from wishlist")
