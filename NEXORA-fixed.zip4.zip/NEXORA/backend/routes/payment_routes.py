"""
NEXORA Backend — payment_routes.py

Real payment integration using Razorpay (test mode by default).

Flow:
  1. Frontend calls POST /api/payments/create-order with the cart total.
     We NEVER trust an amount from the browser for the actual charge in a
     production system — here we still accept it for demo simplicity, but
     the comment below shows where you'd recompute it server-side from the
     cart/order instead before going live.
  2. Razorpay's checkout popup collects card/UPI details directly (they
     never touch our server).
  3. Frontend calls POST /api/payments/verify with the payment id, order id
     and signature Razorpay returns. We recompute the HMAC signature with
     our secret key and compare — this is what actually proves the payment
     is genuine, not just "the popup closed successfully".

Setup:
  pip install razorpay   (already in requirements.txt)
  Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to backend/.env — get test
  keys free at https://dashboard.razorpay.com/app/keys
"""

import hmac
import hashlib
from flask import Blueprint, request
from config import Config
from utils.responses import success, error
from utils.auth_middleware import token_required

payment_bp = Blueprint("payments", __name__)


def _razorpay_client():
    import razorpay  # imported lazily so the app still boots if the package/keys aren't set up yet
    return razorpay.Client(auth=(Config.RAZORPAY_KEY_ID, Config.RAZORPAY_KEY_SECRET))


@payment_bp.post("/create-order")
@token_required
def create_order():
    if not Config.RAZORPAY_KEY_ID or not Config.RAZORPAY_KEY_SECRET:
        return error(
            "Razorpay is not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET "
            "to backend/.env (free test keys at dashboard.razorpay.com/app/keys).",
            503,
        )

    data = request.get_json(silent=True) or {}
    amount = data.get("amount")
    currency = data.get("currency", "INR")
    if not amount or float(amount) <= 0:
        return error("A positive 'amount' is required", 422)

    # In production, recompute this from the user's actual server-side cart
    # instead of trusting the number the browser sends, e.g.:
    #   amount = get_cart_total_for_user(request.user["sub"])
    amount_in_smallest_unit = int(round(float(amount) * 100))  # Razorpay expects paise/cents

    try:
        client = _razorpay_client()
        rp_order = client.order.create({
            "amount": amount_in_smallest_unit,
            "currency": currency,
            "payment_capture": 1,
        })
    except Exception as exc:
        return error(f"Could not create Razorpay order: {exc}", 502)

    return success({
        "order_id": rp_order["id"],
        "amount": rp_order["amount"],
        "currency": rp_order["currency"],
        "key_id": Config.RAZORPAY_KEY_ID,
    })


@payment_bp.post("/verify")
@token_required
def verify_payment():
    if not Config.RAZORPAY_KEY_SECRET:
        return error("Razorpay is not configured.", 503)

    data = request.get_json(silent=True) or {}
    order_id = data.get("razorpay_order_id")
    payment_id = data.get("razorpay_payment_id")
    signature = data.get("razorpay_signature")

    if not (order_id and payment_id and signature):
        return error("Missing payment verification fields", 422)

    # This HMAC check is the real proof of payment — never skip it and
    # never trust the frontend's word alone that a payment succeeded.
    payload = f"{order_id}|{payment_id}".encode()
    expected_signature = hmac.new(
        Config.RAZORPAY_KEY_SECRET.encode(), payload, hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(expected_signature, signature):
        return error("Payment signature verification failed", 400)

    return success({"verified": True, "payment_id": payment_id}, "Payment verified")
