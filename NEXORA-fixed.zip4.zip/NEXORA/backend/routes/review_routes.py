"""NEXORA Backend — Review routes (Phase 8)."""

from flask import Blueprint, request
from utils.db import run_query
from utils.responses import success, error
from utils.auth_middleware import token_required

review_bp = Blueprint("reviews", __name__)


@review_bp.get("/<int:product_id>")
def get_reviews(product_id):
    rows = run_query(
        """SELECT r.*, u.name AS user_name FROM reviews r
           JOIN users u ON u.id = r.user_id
           WHERE r.product_id = %s ORDER BY r.created_at DESC""",
        (product_id,), fetchall=True,
    )
    return success(rows)


@review_bp.post("")
@token_required
def create_review():
    data = request.get_json(silent=True) or {}
    product_id, rating, comment = data.get("product_id"), data.get("rating"), data.get("comment", "")
    if not product_id or not rating:
        return error("product_id and rating are required", 422)
    run_query(
        "INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (%s, %s, %s, %s)",
        (product_id, request.user["sub"], rating, comment), commit=True,
    )
    return success(None, "Review submitted", 201)
