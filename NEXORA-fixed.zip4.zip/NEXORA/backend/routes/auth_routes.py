"""NEXORA Backend — Authentication routes (Phase 6/8)."""

from datetime import datetime, timedelta
from flask import Blueprint, request
import jwt
from config import Config
from models.user import User
from utils.responses import success, error
from utils.auth_middleware import token_required

auth_bp = Blueprint("auth", __name__)


def _issue_token(user):
    payload = {
        "sub": user["id"],
        "email": user["email"],
        "role": user.get("role", "customer"),
        "exp": datetime.utcnow() + Config.JWT_ACCESS_TOKEN_EXPIRES,
    }
    return jwt.encode(payload, Config.JWT_SECRET_KEY, algorithm="HS256")


@auth_bp.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    name, email, password = data.get("name"), data.get("email"), data.get("password")

    if not name or not email or not password:
        return error("Name, email and password are required", 422)
    if len(password) < 8:
        return error("Password must be at least 8 characters", 422)
    if User.find_by_email(email):
        return error("An account with this email already exists", 409)

    user_id = User.create(name, email, password)
    return success({"id": user_id, "name": name, "email": email}, "Account created", 201)


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email, password = data.get("email"), data.get("password")

    if not email or not password:
        return error("Email and password are required", 422)

    user = User.find_by_email(email)
    if not user or not User.verify_password(user["password_hash"], password):
        return error("Incorrect email or password", 401)

    token = _issue_token(user)
    return success({
        "token": token,
        "user": {"id": user["id"], "name": user["name"], "email": user["email"], "role": user["role"]}
    }, "Login successful")


@auth_bp.get("/profile")
@token_required
def profile():
    user = User.find_by_id(request.user["sub"])
    if not user:
        return error("User not found", 404)
    return success(user)


@auth_bp.post("/logout")
@token_required
def logout():
    # Stateless JWT: the client simply discards the token. A token-blocklist
    # table can be added here later if immediate server-side revocation is needed.
    return success(None, "Logged out")
