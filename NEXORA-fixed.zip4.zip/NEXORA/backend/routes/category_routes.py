"""NEXORA Backend — Category routes."""

from flask import Blueprint
from utils.db import run_query
from utils.responses import success

category_bp = Blueprint("categories", __name__)


@category_bp.get("")
def list_categories():
    rows = run_query("SELECT * FROM categories ORDER BY name ASC", fetchall=True)
    return success(rows)


@category_bp.get("/<string:slug>/products")
def category_products(slug):
    rows = run_query("SELECT * FROM products WHERE category = %s", (slug,), fetchall=True)
    return success(rows)
