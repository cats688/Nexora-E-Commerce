"""
NEXORA Backend — Admin routes (Phase 10).

Every route here is wrapped in @admin_required, which first validates the
JWT (token_required) and then checks role == "admin". Normal customer
accounts receive a 403 from any of these endpoints.
"""

from flask import Blueprint, request
from utils.db import run_query
from utils.responses import success, error
from utils.auth_middleware import admin_required

admin_bp = Blueprint("admin", __name__)


@admin_bp.get("/stats")
@admin_required
def dashboard_stats():
    stats = {
        "total_users": run_query("SELECT COUNT(*) AS c FROM users", fetchone=True)["c"],
        "total_products": run_query("SELECT COUNT(*) AS c FROM products", fetchone=True)["c"],
        "total_orders": run_query("SELECT COUNT(*) AS c FROM orders", fetchone=True)["c"],
        "total_revenue": run_query("SELECT COALESCE(SUM(total_amount),0) AS s FROM orders WHERE status != 'cancelled'", fetchone=True)["s"],
        "pending_orders": run_query("SELECT COUNT(*) AS c FROM orders WHERE status = 'pending'", fetchone=True)["c"],
        "delivered_orders": run_query("SELECT COUNT(*) AS c FROM orders WHERE status = 'delivered'", fetchone=True)["c"],
    }
    return success(stats)


@admin_bp.get("/users")
@admin_required
def list_users():
    rows = run_query("SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC", fetchall=True)
    return success(rows)


@admin_bp.post("/products")
@admin_required
def create_product():
    data = request.get_json(silent=True) or {}
    required = ["name", "category", "price"]
    if not all(data.get(f) for f in required):
        return error("name, category and price are required", 422)
    product_id = run_query(
        """INSERT INTO products (name, brand, category, price, old_price, stock, image, description)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
        (data.get("name"), data.get("brand", "Nexora"), data.get("category"), data.get("price"),
         data.get("old_price"), data.get("stock", 0), data.get("image", ""), data.get("description", "")),
        commit=True,
    )
    return success({"id": product_id}, "Product created", 201)


@admin_bp.put("/products/<int:product_id>")
@admin_required
def update_product(product_id):
    data = request.get_json(silent=True) or {}
    fields, params = [], []
    for key in ["name", "brand", "category", "price", "old_price", "stock", "image", "description"]:
        if key in data:
            fields.append(f"{key} = %s")
            params.append(data[key])
    if not fields:
        return error("No fields to update", 422)
    params.append(product_id)
    run_query(f"UPDATE products SET {', '.join(fields)} WHERE id = %s", params, commit=True)
    return success(None, "Product updated")


@admin_bp.delete("/products/<int:product_id>")
@admin_required
def delete_product(product_id):
    run_query("DELETE FROM products WHERE id = %s", (product_id,), commit=True)
    return success(None, "Product deleted")


@admin_bp.get("/orders")
@admin_required
def list_all_orders():
    rows = run_query("SELECT * FROM orders ORDER BY created_at DESC", fetchall=True)
    return success(rows)


@admin_bp.put("/orders/<int:order_id>/status")
@admin_required
def update_order_status(order_id):
    data = request.get_json(silent=True) or {}
    status = data.get("status")
    valid = {"pending", "confirmed", "processing", "shipped", "delivered", "cancelled"}
    if status not in valid:
        return error(f"status must be one of {sorted(valid)}", 422)
    run_query("UPDATE orders SET status = %s WHERE id = %s", (status, order_id), commit=True)
    return success(None, "Order status updated")


@admin_bp.get("/contacts")
@admin_required
def list_contacts():
    rows = run_query("SELECT * FROM contacts ORDER BY created_at DESC", fetchall=True)
    return success(rows)


@admin_bp.get("/newsletter")
@admin_required
def list_subscribers():
    rows = run_query("SELECT * FROM newsletter_subscribers ORDER BY created_at DESC", fetchall=True)
    return success(rows)


@admin_bp.post("/categories")
@admin_required
def create_category():
    data = request.get_json(silent=True) or {}
    if not data.get("name") or not data.get("slug"):
        return error("name and slug are required", 422)
    category_id = run_query(
        "INSERT INTO categories (name, slug, icon) VALUES (%s, %s, %s)",
        (data.get("name"), data.get("slug"), data.get("icon", "fa-tag")),
        commit=True,
    )
    return success({"id": category_id}, "Category created", 201)


@admin_bp.put("/categories/<int:category_id>")
@admin_required
def update_category(category_id):
    data = request.get_json(silent=True) or {}
    fields, params = [], []
    for key in ["name", "slug", "icon"]:
        if key in data:
            fields.append(f"{key} = %s")
            params.append(data[key])
    if not fields:
        return error("No fields to update", 422)
    params.append(category_id)
    run_query(f"UPDATE categories SET {', '.join(fields)} WHERE id = %s", params, commit=True)
    return success(None, "Category updated")


@admin_bp.delete("/categories/<int:category_id>")
@admin_required
def delete_category(category_id):
    run_query("DELETE FROM categories WHERE id = %s", (category_id,), commit=True)
    return success(None, "Category deleted")


@admin_bp.get("/reviews")
@admin_required
def list_all_reviews():
    rows = run_query(
        """SELECT r.*, u.name AS user_name, p.name AS product_name FROM reviews r
           JOIN users u ON u.id = r.user_id
           JOIN products p ON p.id = r.product_id
           ORDER BY r.created_at DESC""",
        fetchall=True,
    )
    return success(rows)


@admin_bp.delete("/reviews/<int:review_id>")
@admin_required
def delete_review(review_id):
    run_query("DELETE FROM reviews WHERE id = %s", (review_id,), commit=True)
    return success(None, "Review deleted")
