"""NEXORA Backend — Order & checkout routes (Phase 9)."""

from flask import Blueprint, request
from utils.db import run_query
from utils.responses import success, error
from utils.auth_middleware import token_required

order_bp = Blueprint("orders", __name__)


@order_bp.post("")
@token_required
def create_order():
    data = request.get_json(silent=True) or {}
    items = data.get("items", [])
    shipping = data.get("shipping_address", {})  # {line1, city, state, zip, country?}
    if isinstance(shipping, str):
        shipping = {"line1": shipping}  # back-compat with older plain-string callers

    if not items:
        return error("Order must contain at least one item", 422)
    if not shipping.get("line1") or not shipping.get("zip"):
        return error("A complete shipping address (line1, city, state, zip) is required", 422)

    total = sum(i["price"] * i["quantity"] for i in items)
    full_address = f"{shipping.get('line1','')}, {shipping.get('city','')}, {shipping.get('state','')} {shipping.get('zip','')}"

    order_id = run_query(
        """INSERT INTO orders (
             user_id, total_amount, shipping_address,
             shipping_name, shipping_phone, shipping_city, shipping_state,
             shipping_pincode, shipping_country, status
           ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, 'pending')""",
        (
            request.user["sub"], total, full_address,
            data.get("name", ""), data.get("phone", ""),
            shipping.get("city", ""), shipping.get("state", ""),
            shipping.get("zip", ""), shipping.get("country", "India"),
        ), commit=True,
    )
    for i in items:
        run_query(
            """INSERT INTO order_items (order_id, product_id, quantity, price)
               VALUES (%s, %s, %s, %s)""",
            (order_id, i["product_id"], i["quantity"], i["price"]), commit=True,
        )
    # Clear the user's cart after a successful order
    cart = run_query("SELECT id FROM cart WHERE user_id = %s", (request.user["sub"],), fetchone=True)
    if cart:
        run_query("DELETE FROM cart_items WHERE cart_id = %s", (cart["id"],), commit=True)

    return success({"order_id": order_id, "total": total}, "Order placed", 201)


@order_bp.get("")
@token_required
def list_orders():
    rows = run_query(
        "SELECT * FROM orders WHERE user_id = %s ORDER BY created_at DESC",
        (request.user["sub"],), fetchall=True,
    )
    return success(rows)


@order_bp.get("/<int:order_id>")
@token_required
def get_order(order_id):
    order = run_query(
        "SELECT * FROM orders WHERE id = %s AND user_id = %s",
        (order_id, request.user["sub"]), fetchone=True,
    )
    if not order:
        return error("Order not found", 404)
    items = run_query("SELECT * FROM order_items WHERE order_id = %s", (order_id,), fetchall=True)
    order["items"] = items
    return success(order)
