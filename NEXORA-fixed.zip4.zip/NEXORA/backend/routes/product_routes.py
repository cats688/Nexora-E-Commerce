"""NEXORA Backend — Product routes (Phase 7/8)."""

from flask import Blueprint, request
from utils.db import run_query
from utils.responses import success, error

product_bp = Blueprint("products", __name__)


@product_bp.get("")
def list_products():
    category = request.args.get("category")
    search = request.args.get("q")
    sort = request.args.get("sort", "featured")
    page = int(request.args.get("page", 1))
    limit = int(request.args.get("limit", 12))
    offset = (page - 1) * limit

    query = "SELECT * FROM products WHERE 1=1"
    params = []

    if category:
        query += " AND category = %s"
        params.append(category)
    if search:
        query += " AND (name LIKE %s OR brand LIKE %s)"
        params += [f"%{search}%", f"%{search}%"]

    sort_map = {
        "price-asc": "price ASC",
        "price-desc": "price DESC",
        "rating": "rating DESC",
        "newest": "created_at DESC",
    }
    query += f" ORDER BY {sort_map.get(sort, 'id ASC')} LIMIT %s OFFSET %s"
    params += [limit, offset]

    rows = run_query(query, params, fetchall=True)
    return success(rows)


@product_bp.get("/<int:product_id>")
def get_product(product_id):
    row = run_query("SELECT * FROM products WHERE id = %s", (product_id,), fetchone=True)
    if not row:
        return error("Product not found", 404)
    return success(row)
