"""NEXORA Backend — Contact form route."""

from flask import Blueprint, request
from utils.db import run_query
from utils.responses import success, error

contact_bp = Blueprint("contact", __name__)


@contact_bp.post("")
def submit_contact():
    data = request.get_json(silent=True) or {}
    name, email, subject, message = data.get("name"), data.get("email"), data.get("subject"), data.get("message")
    if not name or not email or not message:
        return error("Name, email and message are required", 422)
    run_query(
        "INSERT INTO contacts (name, email, subject, message) VALUES (%s, %s, %s, %s)",
        (name, email, subject or "", message), commit=True,
    )
    return success(None, "Message received — we'll reply within 24 hours", 201)
