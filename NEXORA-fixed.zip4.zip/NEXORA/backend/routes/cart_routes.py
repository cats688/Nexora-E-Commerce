"""NEXORA Backend — Cart routes (Phase 8/9). All routes require a logged-in user."""

from flask import Blueprint, request
from utils.db import run_query
from utils.responses import success, error
from utils.auth_middleware import token_required

cart_bp = Blueprint("cart", __name__)


def _get_or_create_cart(user_id):
    cart = run_query("SELECT * FROM cart WHERE user_id = %s", (user_id,), fetchone=True)
    if cart:
        return cart["id"]
    return run_query("INSERT INTO cart (user_id) VALUES (%s)", (user_id,), commit=True)


@cart_bp.get("")
@token_required
def get_cart():
    cart_id = _get_or_create_cart(request.user["sub"])
    items = run_query(
        """SELECT ci.id, ci.product_id, ci.quantity, p.name, p.price, p.image
           FROM cart_items ci JOIN products p ON p.id = ci.product_id
           WHERE ci.cart_id = %s""",
        (cart_id,), fetchall=True,
    )
    return success(items)


@cart_bp.post("/items")
@token_required
def add_item():
    data = request.get_json(silent=True) or {}
    product_id, qty = data.get("product_id"), data.get("quantity", 1)
    if not product_id:
        return error("product_id is required", 422)

    cart_id = _get_or_create_cart(request.user["sub"])
    existing = run_query(
        "SELECT * FROM cart_items WHERE cart_id = %s AND product_id = %s",
        (cart_id, product_id), fetchone=True,
    )
    if existing:
        run_query(
            "UPDATE cart_items SET quantity = quantity + %s WHERE id = %s",
            (qty, existing["id"]), commit=True,
        )
    else:
        run_query(
            "INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (%s, %s, %s)",
            (cart_id, product_id, qty), commit=True,
        )
    return success(None, "Item added to cart", 201)


@cart_bp.put("/items/<int:item_id>")
@token_required
def update_item(item_id):
    data = request.get_json(silent=True) or {}
    qty = data.get("quantity")
    if not qty or qty < 1:
        return error("quantity must be at least 1", 422)
    run_query("UPDATE cart_items SET quantity = %s WHERE id = %s", (qty, item_id), commit=True)
    return success(None, "Cart item updated")


@cart_bp.delete("/items/<int:item_id>")
@token_required
def remove_item(item_id):
    run_query("DELETE FROM cart_items WHERE id = %s", (item_id,), commit=True)
    return success(None, "Item removed from cart")
