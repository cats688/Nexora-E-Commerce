"""
NEXORA Backend — configuration

Values are read from environment variables (see .env.example). Copy that
file to `.env` in the backend/ folder and fill in your local MySQL
credentials and a real secret key before running the app.
"""

import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me")
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "dev-jwt-secret-change-me")
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=int(os.environ.get("JWT_EXPIRES_HOURS", 24)))

    MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
    MYSQL_PORT = int(os.environ.get("MYSQL_PORT", 3306))
    MYSQL_USER = os.environ.get("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "")
    MYSQL_DB = os.environ.get("MYSQL_DB", "nexora_db")

    DEBUG = os.environ.get("FLASK_DEBUG", "1") == "1"

    # Comma-separated list of allowed frontend origins (Phase 12 hardening).
    # Defaults cover Live Server / VS Code preview / plain file usage during
    # local development. Set CORS_ORIGINS in .env for a real deployment,
    # e.g. CORS_ORIGINS=https://your-frontend-domain.com
    CORS_ORIGINS = os.environ.get(
        "CORS_ORIGINS",
        "http://127.0.0.1:5500,http://localhost:5500,http://127.0.0.1:5173,http://localhost:5173,null"
    ).split(",")

    # Razorpay (real payment gateway — Phase 9). Get free test keys at
    # https://dashboard.razorpay.com/app/keys. Leave blank to keep the
    # storefront in cash-on-delivery / demo mode only.
    RAZORPAY_KEY_ID = os.environ.get("RAZORPAY_KEY_ID", "")
    RAZORPAY_KEY_SECRET = os.environ.get("RAZORPAY_KEY_SECRET", "")

    # Shiprocket (real courier integration — see utils/shiprocket.py).
    # Free account at https://app.shiprocket.in/register. Leave blank to
    # keep orders in "manual fulfillment" mode (no real AWB/tracking).
    SHIPROCKET_EMAIL = os.environ.get("SHIPROCKET_EMAIL", "")
    SHIPROCKET_PASSWORD = os.environ.get("SHIPROCKET_PASSWORD", "")
    # Must exactly match a pickup address nickname you've configured in
    # Shiprocket's dashboard under Settings -> Pickup Addresses.
    SHIPROCKET_PICKUP_LOCATION = os.environ.get("SHIPROCKET_PICKUP_LOCATION", "")
    # The pincode of that same pickup address — used for serviceability/rate checks.
    SHIPROCKET_PICKUP_LOCATION_PINCODE = os.environ.get("SHIPROCKET_PICKUP_LOCATION_PINCODE", "")
