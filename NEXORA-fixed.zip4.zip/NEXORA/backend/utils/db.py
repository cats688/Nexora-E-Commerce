"""
NEXORA Backend — MySQL connection helper.

Uses mysql-connector-python. Each function opens a short-lived connection
and closes it, which is fine for a portfolio-scale project; swap for a
pooled connection (mysql.connector.pooling) if load ever requires it.
"""

import mysql.connector
from mysql.connector import Error
from config import Config


def get_connection():
    """Return a new MySQL connection using values from Config / .env."""
    try:
        return mysql.connector.connect(
            host=Config.MYSQL_HOST,
            port=Config.MYSQL_PORT,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DB,
        )
    except Error as exc:
        raise RuntimeError(
            "Could not connect to MySQL. Check backend/.env and confirm the "
            "database from database/schema.sql has been created. "
            f"Original error: {exc}"
        )


def run_query(query, params=None, fetchone=False, fetchall=False, commit=False):
    """Small helper to run a query and clean up the connection/cursor."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute(query, params or ())
        result = None
        if fetchone:
            result = cursor.fetchone()
        elif fetchall:
            result = cursor.fetchall()
        if commit:
            conn.commit()
            result = cursor.lastrowid
        return result
    finally:
        cursor.close()
        conn.close()
