"""
NEXORA Backend — auth middleware.

`token_required` protects any user route; `admin_required` additionally
checks the JWT's `role` claim so normal users can never reach admin APIs
(Phase 10 requirement).
"""

from functools import wraps
from flask import request
import jwt
from config import Config
from utils.responses import error


def _get_token_from_header():
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        return auth_header.split(" ", 1)[1]
    return None


def token_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        token = _get_token_from_header()
        if not token:
            return error("Missing or invalid Authorization header", 401)
        try:
            payload = jwt.decode(token, Config.JWT_SECRET_KEY, algorithms=["HS256"])
        except jwt.ExpiredSignatureError:
            return error("Session expired, please log in again", 401)
        except jwt.InvalidTokenError:
            return error("Invalid token", 401)
        request.user = payload
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    @token_required
    def wrapper(*args, **kwargs):
        if request.user.get("role") != "admin":
            return error("Admin access required", 403)
        return f(*args, **kwargs)
    return wrapper
