"""
NEXORA Backend — utils/shiprocket.py

A thin, real client for the Shiprocket API (https://apidocs.shiprocket.in).
Shiprocket aggregates dozens of Indian couriers (Delhivery, Bluedart, Xpressbees,
Ecom Express, etc.) behind one API — you sign up for one free Shiprocket
account instead of negotiating with each courier individually. This is the
same approach most small D2C brands in India actually use to ship real
orders.

Setup (free):
  1. Create an account at https://app.shiprocket.in/register
  2. Add at least one **pickup location** in Shiprocket's dashbound
     (Settings -> Pickup Addresses) — this is the address orders ship FROM.
     Note its exact "Pickup Location" nickname.
  3. Put your Shiprocket login email/password and that pickup location name
     into backend/.env (SHIPROCKET_EMAIL, SHIPROCKET_PASSWORD,
     SHIPROCKET_PICKUP_LOCATION).
  4. pip install requests   (already in requirements.txt)

Nothing in this file will run without those credentials — every function
fails with a clear error message rather than pretending to succeed, so a
half-configured store never shows a fake tracking number.
"""

import time
import requests
from config import Config

SHIPROCKET_BASE = "https://apiv2.shiprocket.in/v1/external"

_token_cache = {"token": None, "expires_at": 0}


class ShiprocketError(Exception):
    pass


def _require_credentials():
    if not Config.SHIPROCKET_EMAIL or not Config.SHIPROCKET_PASSWORD:
        raise ShiprocketError(
            "Shiprocket is not configured. Add SHIPROCKET_EMAIL and "
            "SHIPROCKET_PASSWORD to backend/.env (free account at "
            "app.shiprocket.in/register)."
        )


def _get_token():
    """Shiprocket tokens are valid ~10 days; cache and reuse until near expiry."""
    _require_credentials()
    if _token_cache["token"] and time.time() < _token_cache["expires_at"]:
        return _token_cache["token"]

    resp = requests.post(
        f"{SHIPROCKET_BASE}/auth/login",
        json={"email": Config.SHIPROCKET_EMAIL, "password": Config.SHIPROCKET_PASSWORD},
        timeout=15,
    )
    if resp.status_code != 200:
        raise ShiprocketError(f"Shiprocket login failed: {resp.text}")

    data = resp.json()
    token = data.get("token")
    if not token:
        raise ShiprocketError("Shiprocket login did not return a token.")

    _token_cache["token"] = token
    _token_cache["expires_at"] = time.time() + 9 * 24 * 60 * 60  # refresh a day early
    return token


def _headers():
    return {"Authorization": f"Bearer {_get_token()}", "Content-Type": "application/json"}


def check_serviceability(pickup_pincode, delivery_pincode, weight_kg=0.5, cod=False):
    """Real courier availability + rate check for a pincode pair — this is
    what powers 'Delivery available, arriving in ~3 days' at checkout."""
    resp = requests.get(
        f"{SHIPROCKET_BASE}/courier/serviceability/",
        headers=_headers(),
        params={
            "pickup_postcode": pickup_pincode,
            "delivery_postcode": delivery_pincode,
            "weight": weight_kg,
            "cod": 1 if cod else 0,
        },
        timeout=15,
    )
    if resp.status_code != 200:
        raise ShiprocketError(f"Serviceability check failed: {resp.text}")
    return resp.json()


def create_order(order):
    """
    Creates a real order + shipment in Shiprocket from a NEXORA order dict.
    Expects order to have: id, items (list of {name, sku, units, price}),
    shipping (name, phone, address, city, state, pincode, country),
    sub_total, payment_method ("cod" or "prepaid").

    Returns Shiprocket's response, including `order_id` and `shipment_id` —
    store these on the NEXORA order so `assign_awb` and `track` can use them.
    """
    if not Config.SHIPROCKET_PICKUP_LOCATION:
        raise ShiprocketError(
            "SHIPROCKET_PICKUP_LOCATION is not set in backend/.env — this must "
            "exactly match a pickup address nickname configured in your "
            "Shiprocket dashboard (Settings -> Pickup Addresses)."
        )

    payload = {
        "order_id": str(order["id"]),
        "order_date": order["order_date"],       # "YYYY-MM-DD HH:MM"
        "pickup_location": Config.SHIPROCKET_PICKUP_LOCATION,
        "billing_customer_name": order["shipping"]["name"],
        "billing_last_name": "",
        "billing_address": order["shipping"]["address"],
        "billing_city": order["shipping"]["city"],
        "billing_pincode": order["shipping"]["pincode"],
        "billing_state": order["shipping"]["state"],
        "billing_country": order["shipping"].get("country", "India"),
        "billing_phone": order["shipping"]["phone"],
        "shipping_is_billing": True,
        "order_items": [
            {
                "name": i["name"],
                "sku": i.get("sku") or f"NXR-{i.get('product_id', 'ITEM')}",
                "units": i["units"],
                "selling_price": i["price"],
            }
            for i in order["items"]
        ],
        "payment_method": "COD" if order["payment_method"] == "cod" else "Prepaid",
        "sub_total": order["sub_total"],
        # Reasonable default parcel dimensions/weight for small electronics —
        # adjust per-product if you stock larger items (see order_items.weight_kg).
        "length": 20, "breadth": 15, "height": 10,
        "weight": order.get("weight_kg", 0.5),
    }

    resp = requests.post(f"{SHIPROCKET_BASE}/orders/create/adhoc", headers=_headers(), json=payload, timeout=20)
    if resp.status_code not in (200, 201):
        raise ShiprocketError(f"Could not create Shiprocket order: {resp.text}")
    return resp.json()


def assign_awb(shipment_id, courier_id=None):
    """Assigns a courier + real AWB (tracking number) to a shipment. If
    courier_id is omitted, Shiprocket auto-picks its recommended courier."""
    payload = {"shipment_id": shipment_id}
    if courier_id:
        payload["courier_id"] = courier_id
    resp = requests.post(f"{SHIPROCKET_BASE}/courier/assign/awb", headers=_headers(), json=payload, timeout=20)
    if resp.status_code != 200:
        raise ShiprocketError(f"Could not assign AWB: {resp.text}")
    return resp.json()


def track_by_awb(awb_code):
    """Live tracking checkpoints for a real AWB number."""
    resp = requests.get(f"{SHIPROCKET_BASE}/courier/track/awb/{awb_code}", headers=_headers(), timeout=15)
    if resp.status_code != 200:
        raise ShiprocketError(f"Tracking lookup failed: {resp.text}")
    return resp.json()
