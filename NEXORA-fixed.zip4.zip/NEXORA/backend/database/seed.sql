-- ============================================================================
-- NEXORA Electronics — seed data (Phase 7)
-- Run AFTER schema.sql:  mysql -u root -p nexora_db < seed.sql
-- ============================================================================

USE nexora_db;

INSERT INTO categories (slug, name, icon) VALUES
  ('smartphones', 'Smartphones', 'fa-mobile-screen'),
  ('laptops', 'Laptops', 'fa-laptop'),
  ('tablets', 'Tablets', 'fa-tablet-screen-button'),
  ('smartwatches', 'Smartwatches', 'fa-clock'),
  ('earbuds', 'Earbuds', 'fa-headphones-simple'),
  ('headphones', 'Headphones', 'fa-headphones'),
  ('cameras', 'Cameras', 'fa-camera'),
  ('gaming', 'Gaming', 'fa-gamepad'),
  ('accessories', 'Accessories', 'fa-plug'),
  ('smart-home', 'Smart Home', 'fa-house-signal')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO products (name, brand, category, price, old_price, rating, reviews_count, stock, image, description) VALUES
  ('Nexora Pulse Pro', 'Nexora', 'smartphones', 899.00, 999.00, 4.8, 214, 18, 'https://images.unsplash.com/photo-1592286927505-1def25115558?q=80&w=800&auto=format&fit=crop', 'Flagship smartphone with a 120Hz LTPO display, titanium frame and an AI-tuned triple camera system.'),
  ('Nexora Air Slim 14', 'Nexora', 'laptops', 1299.00, 1499.00, 4.7, 168, 9, 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=800&auto=format&fit=crop', 'A 1.1kg ultraportable laptop with a 14-inch 2.8K display and all-day battery.'),
  ('Nexora Tab X', 'Nexora', 'tablets', 549.00, NULL, 4.5, 92, 24, 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=800&auto=format&fit=crop', 'An 11-inch tablet with stylus support for sketching, notes and media.'),
  ('Nexora Watch Fit', 'Nexora', 'smartwatches', 229.00, 279.00, 4.6, 301, 40, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop', 'Lightweight AMOLED smartwatch with 14-day battery life and SpO2 tracking.'),
  ('Nexora Buds Air', 'Nexora', 'earbuds', 129.00, 159.00, 4.4, 512, 60, 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?q=80&w=800&auto=format&fit=crop', 'True wireless earbuds with adaptive ANC and a 32-hour case battery.'),
  ('Nexora Studio Headphones', 'Nexora', 'headphones', 249.00, NULL, 4.7, 143, 15, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop', 'Over-ear studio headphones tuned for balanced monitoring, 40-hour battery.'),
  ('Nexora Lens Z1', 'Nexora', 'cameras', 1099.00, 1199.00, 4.9, 76, 6, 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=800&auto=format&fit=crop', 'Mirrorless camera with a 32MP APS-C sensor and 4K/60 video.'),
  ('Nexora Play Controller', 'Nexora', 'gaming', 79.00, 99.00, 4.5, 220, 55, 'https://images.unsplash.com/photo-1592840062661-eb5f8636022a?q=80&w=800&auto=format&fit=crop', 'Wireless controller with Hall-effect sticks and 30h battery.'),
  ('Nexora Hub Charge Dock', 'Nexora', 'accessories', 59.00, NULL, 4.3, 88, 70, 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=800&auto=format&fit=crop', '3-in-1 charging dock for phone, watch and earbuds, 18W fast charging.'),
  ('Nexora Home Hub', 'Nexora', 'smart-home', 149.00, 179.00, 4.4, 64, 20, 'https://images.unsplash.com/photo-1558002038-1055907df827?q=80&w=800&auto=format&fit=crop', 'Smart display hub centralizing lighting, cameras and voice control.'),
  ('Nexora Pulse Lite', 'Nexora', 'smartphones', 449.00, 499.00, 4.2, 190, 33, 'https://images.unsplash.com/photo-1585060544812-6b45742d762f?q=80&w=800&auto=format&fit=crop', 'Value flagship with a 120Hz display and 5000mAh battery.'),
  ('Nexora Book Pro 16', 'Nexora', 'laptops', 1899.00, NULL, 4.8, 54, 5, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=800&auto=format&fit=crop', '16-inch performance laptop for creators with a mini-LED display.');

-- Demo admin account — email: admin@nexora.com / password: Admin123
-- Real, working pbkdf2:sha256 hash — this account logs in as soon as you
-- load this file. To use a different password, regenerate the hash with:
--  `python -c "from werkzeug.security import generate_password_hash as g; print(g('YourNewPassword', method='pbkdf2:sha256'))"`
INSERT INTO users (name, email, password_hash, role)
VALUES ('Admin User', 'admin@nexora.com', 'pbkdf2:sha256:1000000$QOp2YQkRymU9xFHg$2dcc39836dd59006ec320527d75782974d15aeaeb9baf98abbe85672f7f90cc1', 'admin')
ON DUPLICATE KEY UPDATE role = 'admin';
