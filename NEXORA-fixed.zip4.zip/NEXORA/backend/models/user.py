"""NEXORA Backend — User model (raw SQL, no ORM, to keep the stack simple)."""

from werkzeug.security import generate_password_hash, check_password_hash
from utils.db import run_query


class User:
    @staticmethod
    def create(name, email, password, role="customer"):
        password_hash = generate_password_hash(password)
        return run_query(
            "INSERT INTO users (name, email, password_hash, role) VALUES (%s, %s, %s, %s)",
            (name, email, password_hash, role),
            commit=True,
        )

    @staticmethod
    def find_by_email(email):
        return run_query("SELECT * FROM users WHERE email = %s", (email,), fetchone=True)

    @staticmethod
    def find_by_id(user_id):
        return run_query("SELECT id, name, email, role, created_at FROM users WHERE id = %s", (user_id,), fetchone=True)

    @staticmethod
    def verify_password(stored_hash, password):
        return check_password_hash(stored_hash, password)
