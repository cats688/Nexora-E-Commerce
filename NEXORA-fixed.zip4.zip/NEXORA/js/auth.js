/* ==========================================================================
   NEXORA — auth.js   (Phase 5, wired for Phase 8 in js/config.js)

   Hybrid auth: if NEXORA_CONFIG.API_BASE_URL (js/config.js) is set, every
   call below hits the real Flask + MySQL backend and stores the real JWT
   it returns. If it's left empty, the exact same functions fall back to a
   localStorage-only demo so the site still works with zero setup.

     Register -> POST /api/auth/register   { name, email, password }
     Login    -> POST /api/auth/login      { email, password } -> { token, user }
     Profile  -> GET  /api/auth/profile    (Authorization: Bearer <token>)
     Logout   -> client-side token discard (+ optional POST /api/auth/logout)

   The token is stored in localStorage under NX_AUTH_KEY either way, so the
   rest of the site (nx_getSession, checkout.js, admin.js) never needs to
   know which mode is active.
   ========================================================================== */

const NX_AUTH_KEY = "nexora_auth";
const NX_USERS_KEY = "nexora_users_demo";

function nx_getUsers() {
  try { return JSON.parse(localStorage.getItem(NX_USERS_KEY)) || []; } catch { return []; }
}
function nx_saveUsers(users) { localStorage.setItem(NX_USERS_KEY, JSON.stringify(users)); }

function nx_getSession() {
  try { return JSON.parse(localStorage.getItem(NX_AUTH_KEY)); } catch { return null; }
}
function nx_setSession(session) { localStorage.setItem(NX_AUTH_KEY, JSON.stringify(session)); }
function nx_logout() {
  localStorage.removeItem(NX_AUTH_KEY);
  window.location.href = "login.html";
}

/** POST helper for the real API — throws with a readable message on failure. */
async function nx_apiPost(path, body) {
  const res = await fetch(nx_apiUrl(path), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.success === false) {
    throw new Error(data.error || data.message || `Request failed (${res.status})`);
  }
  return data;
}

function nx_isEmailValid(email) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); }
function nx_isPasswordValid(pw) { return pw.length >= 8 && /[A-Z]/.test(pw) && /[0-9]/.test(pw); }

function nx_showFieldError(input, message) {
  const group = input.closest(".form-group");
  const err = group?.querySelector(".field-error");
  if (err) { err.textContent = message; err.style.display = message ? "block" : "none"; }
  input.style.borderColor = message ? "var(--danger)" : "";
}

document.addEventListener("DOMContentLoaded", () => {
  nx_wirePasswordToggles();
  nx_wireLoginForm();
  nx_wireRegisterForm();
  nx_wireForgotForm();
  nx_wireResetForm();
  nx_guardProfilePage();
});

function nx_wirePasswordToggles() {
  document.querySelectorAll(".toggle-pass").forEach(btn => {
    btn.addEventListener("click", () => {
      const input = btn.closest(".input-wrap").querySelector("input");
      const isPass = input.type === "password";
      input.type = isPass ? "text" : "password";
      btn.innerHTML = `<i class="fa-solid ${isPass ? "fa-eye-slash" : "fa-eye"}"></i>`;
    });
  });
}

function nx_wireLoginForm() {
  const form = document.querySelector("[data-login-form]");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = form.querySelector("#email");
    const password = form.querySelector("#password");
    let valid = true;

    if (!nx_isEmailValid(email.value)) { nx_showFieldError(email, "Enter a valid email address."); valid = false; }
    else nx_showFieldError(email, "");

    if (!password.value) { nx_showFieldError(password, "Password is required."); valid = false; }
    else nx_showFieldError(password, "");

    if (!valid) return;

    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) { submitBtn.disabled = true; submitBtn.dataset.originalText = submitBtn.textContent; submitBtn.textContent = "Signing in…"; }

    try {
      if (nx_isBackendConnected()) {
        // ---- Real mode: hits Flask /api/auth/login, stores the real JWT ----
        const data = await nx_apiPost("/api/auth/login", { email: email.value.trim(), password: password.value });
        nx_setSession({ token: data.data.token, user: data.data.user });
        nx_toast(`Welcome back, ${data.data.user.name.split(" ")[0]}!`);
        setTimeout(() => (window.location.href = "profile.html"), 700);
        return;
      }

      // ---- Demo mode: localStorage-only ----
      const users = nx_getUsers();
      const user = users.find(u => u.email.toLowerCase() === email.value.toLowerCase());
      if (!user || user.password !== password.value) {
        nx_showFieldError(password, "Incorrect email or password.");
        nx_toast("Login failed — check your credentials.", "error");
        return;
      }
      nx_setSession({ token: "demo." + btoa(user.email) + "." + Date.now(), user: { name: user.name, email: user.email } });
      nx_toast(`Welcome back, ${user.name.split(" ")[0]}!`);
      setTimeout(() => (window.location.href = "profile.html"), 700);
    } catch (err) {
      nx_toast(err.message || "Login failed. Please try again.", "error");
    } finally {
      if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = submitBtn.dataset.originalText; }
    }
  });
}

function nx_wireRegisterForm() {
  const form = document.querySelector("[data-register-form]");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = form.querySelector("#name");
    const email = form.querySelector("#email");
    const password = form.querySelector("#password");
    const confirm = form.querySelector("#confirm");
    let valid = true;

    if (name.value.trim().length < 2) { nx_showFieldError(name, "Enter your full name."); valid = false; }
    else nx_showFieldError(name, "");

    if (!nx_isEmailValid(email.value)) { nx_showFieldError(email, "Enter a valid email address."); valid = false; }
    else nx_showFieldError(email, "");

    if (!nx_isPasswordValid(password.value)) { nx_showFieldError(password, "Min 8 characters, 1 uppercase letter, 1 number."); valid = false; }
    else nx_showFieldError(password, "");

    if (confirm.value !== password.value) { nx_showFieldError(confirm, "Passwords do not match."); valid = false; }
    else nx_showFieldError(confirm, "");

    if (!valid) return;

    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) { submitBtn.disabled = true; submitBtn.dataset.originalText = submitBtn.textContent; submitBtn.textContent = "Creating account…"; }

    try {
      if (nx_isBackendConnected()) {
        // ---- Real mode: hits Flask /api/auth/register, MySQL stores a
        // werkzeug-hashed password (see backend/models/user.py) ----
        await nx_apiPost("/api/auth/register", {
          name: name.value.trim(), email: email.value.trim(), password: password.value
        });
        nx_toast("Account created — please log in.");
        setTimeout(() => (window.location.href = "login.html"), 800);
        return;
      }

      // ---- Demo mode: localStorage-only. NOTE: plaintext here is fine only
      // because it's a client-side simulation with no server; the real
      // backend above never stores plaintext passwords. ----
      const users = nx_getUsers();
      if (users.some(u => u.email.toLowerCase() === email.value.toLowerCase())) {
        nx_showFieldError(email, "An account with this email already exists.");
        return;
      }
      users.push({ name: name.value.trim(), email: email.value.trim(), password: password.value });
      nx_saveUsers(users);
      nx_toast("Account created — please log in.");
      setTimeout(() => (window.location.href = "login.html"), 800);
    } catch (err) {
      nx_toast(err.message || "Could not create account. Please try again.", "error");
    } finally {
      if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = submitBtn.dataset.originalText; }
    }
  });
}

function nx_wireForgotForm() {
  const form = document.querySelector("[data-forgot-form]");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = form.querySelector("#email");
    if (!nx_isEmailValid(email.value)) { nx_showFieldError(email, "Enter a valid email address."); return; }
    nx_showFieldError(email, "");
    nx_toast("If that account exists, a reset link has been sent.");
    form.reset();
  });
}

function nx_wireResetForm() {
  const form = document.querySelector("[data-reset-form]");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const password = form.querySelector("#password");
    const confirm = form.querySelector("#confirm");
    let valid = true;
    if (!nx_isPasswordValid(password.value)) { nx_showFieldError(password, "Min 8 characters, 1 uppercase letter, 1 number."); valid = false; }
    else nx_showFieldError(password, "");
    if (confirm.value !== password.value) { nx_showFieldError(confirm, "Passwords do not match."); valid = false; }
    else nx_showFieldError(confirm, "");
    if (!valid) return;
    nx_toast("Password updated — please log in.");
    setTimeout(() => (window.location.href = "login.html"), 800);
  });
}

function nx_guardProfilePage() {
  const profileRoot = document.querySelector("[data-profile-page]");
  if (!profileRoot) return;
  const session = nx_getSession();
  if (!session) {
    window.location.href = "login.html";
    return;
  }
  document.querySelector("[data-profile-name]").textContent = session.user.name;
  document.querySelector("[data-profile-email]").textContent = session.user.email;
  document.querySelector("[data-profile-initial]").textContent = session.user.name.charAt(0).toUpperCase();
  document.querySelectorAll("[data-logout]").forEach(btn => btn.addEventListener("click", nx_logout));
}
