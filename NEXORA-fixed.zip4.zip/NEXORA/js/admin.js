/* ==========================================================================
   NEXORA — admin.js   (Phase 10)

   Frontend-only admin simulation, same philosophy as auth.js/cart.js: every
   function here maps 1:1 to a real endpoint already implemented in
   backend/routes/admin_routes.py, so wiring this to Flask later means
   swapping the body of each nx_admin* data function for a fetch() call —
   the views and event handlers do not change.

     Stats            -> GET    /api/admin/stats
     Users            -> GET    /api/admin/users
     Products CRUD    -> POST/PUT/DELETE /api/admin/products(/:id)
     Categories CRUD  -> POST/PUT/DELETE /api/admin/categories(/:id)
     Orders           -> GET /api/admin/orders, PUT /api/admin/orders/:id/status
     Reviews          -> GET /api/admin/reviews, DELETE /api/admin/reviews/:id
     Contacts         -> GET /api/admin/contacts
     Newsletter       -> GET /api/admin/newsletter

   Role-based authorization (client-side simulation of the real JWT +
   admin_required decorator on the backend): only a session with
   role === "admin" may view admin-dashboard.html. A normal customer
   session is redirected to admin-login.html, matching the 403 a real
   customer JWT would get from the API.
   ========================================================================== */

const NX_ADMIN_SESSION_KEY = "nexora_admin_session";
const NX_ADMIN_PRODUCTS_KEY = "nexora_admin_products";
const NX_ADMIN_CATEGORIES_KEY = "nexora_admin_categories";
const NX_ADMIN_USERS_KEY = "nexora_admin_users";
const NX_ADMIN_REVIEWS_KEY = "nexora_admin_reviews";
const NX_ADMIN_CONTACTS_KEY = "nexora_admin_contacts";
const NX_ADMIN_NEWSLETTER_KEY = "nexora_admin_newsletter";

/* ==========================================================================
   Seed demo data on first run (stands in for MySQL seed.sql rows)
   ========================================================================== */

function nx_adminSeedIfEmpty() {
  if (!localStorage.getItem(NX_ADMIN_PRODUCTS_KEY)) {
    localStorage.setItem(NX_ADMIN_PRODUCTS_KEY, JSON.stringify(NEXORA_PRODUCTS));
  }
  if (!localStorage.getItem(NX_ADMIN_CATEGORIES_KEY)) {
    localStorage.setItem(NX_ADMIN_CATEGORIES_KEY, JSON.stringify(NEXORA_CATEGORIES));
  }
  if (!localStorage.getItem(NX_ADMIN_USERS_KEY)) {
    localStorage.setItem(NX_ADMIN_USERS_KEY, JSON.stringify([
      { id: 1, name: "Admin Account", email: "admin@nexora.com", role: "admin", createdAt: "2026-01-04" },
      { id: 2, name: "Ava Martinez", email: "ava.martinez@example.com", role: "customer", createdAt: "2026-02-11" },
      { id: 3, name: "Liam Chen", email: "liam.chen@example.com", role: "customer", createdAt: "2026-03-02" },
      { id: 4, name: "Sofia Rossi", email: "sofia.rossi@example.com", role: "customer", createdAt: "2026-03-19" },
      { id: 5, name: "Noah Patel", email: "noah.patel@example.com", role: "customer", createdAt: "2026-04-05" }
    ]));
  }
  if (!localStorage.getItem(NX_ADMIN_REVIEWS_KEY)) {
    localStorage.setItem(NX_ADMIN_REVIEWS_KEY, JSON.stringify([
      { id: 1, productId: 1, productName: "Nexora Pulse Pro", userName: "Ava Martinez", rating: 5, comment: "Camera is outstanding in low light.", createdAt: "2026-05-02" },
      { id: 2, productId: 5, productName: "Nexora Buds Air", userName: "Liam Chen", rating: 4, comment: "Great sound, ANC could be a touch stronger.", createdAt: "2026-05-10" },
      { id: 3, productId: 2, productName: "Nexora Air Slim 14", userName: "Sofia Rossi", rating: 5, comment: "Battery genuinely lasts the full day.", createdAt: "2026-05-14" },
      { id: 4, productId: 7, productName: "Nexora Lens Z1", userName: "Noah Patel", rating: 5, comment: "Stabilization is incredible for handheld video.", createdAt: "2026-05-20" }
    ]));
  }
  if (!localStorage.getItem(NX_ADMIN_CONTACTS_KEY)) {
    localStorage.setItem(NX_ADMIN_CONTACTS_KEY, JSON.stringify([
      { id: 1, name: "Ethan Wright", email: "ethan.w@example.com", subject: "Bulk order enquiry", message: "Do you offer discounts for orders of 20+ units?", createdAt: "2026-05-01", read: false },
      { id: 2, name: "Maya Gupta", email: "maya.g@example.com", subject: "Warranty question", message: "How do I claim warranty on a Nexora Watch Fit?", createdAt: "2026-05-08", read: true }
    ]));
  }
  if (!localStorage.getItem(NX_ADMIN_NEWSLETTER_KEY)) {
    localStorage.setItem(NX_ADMIN_NEWSLETTER_KEY, JSON.stringify([
      { id: 1, email: "priya.k@example.com", createdAt: "2026-04-22" },
      { id: 2, email: "daniel.h@example.com", createdAt: "2026-04-30" },
      { id: 3, email: "grace.l@example.com", createdAt: "2026-05-06" }
    ]));
  }
}

function nx_adminRead(key) { try { return JSON.parse(localStorage.getItem(key)) || []; } catch { return []; } }
function nx_adminWrite(key, value) { localStorage.setItem(key, JSON.stringify(value)); }

/* ==========================================================================
   Admin auth (separate session key from the customer session in auth.js)
   ========================================================================== */

function nx_getAdminSession() {
  try { return JSON.parse(localStorage.getItem(NX_ADMIN_SESSION_KEY)); } catch { return null; }
}
function nx_setAdminSession(session) { localStorage.setItem(NX_ADMIN_SESSION_KEY, JSON.stringify(session)); }
function nx_adminLogout() {
  localStorage.removeItem(NX_ADMIN_SESSION_KEY);
  window.location.href = "admin-login.html";
}

const NX_ADMIN_DEMO_EMAIL = "admin@nexora.com";
const NX_ADMIN_DEMO_PASSWORD = "Admin123";

document.addEventListener("DOMContentLoaded", () => {
  nx_adminSeedIfEmpty();
  nx_wireAdminLoginForm();
  nx_guardAdminDashboard();
});

function nx_wireAdminLoginForm() {
  const form = document.querySelector("[data-admin-login-form]");
  if (!form) return;

  document.querySelectorAll(".toggle-pass").forEach(btn => {
    btn.addEventListener("click", () => {
      const input = btn.closest(".input-wrap").querySelector("input");
      const isPass = input.type === "password";
      input.type = isPass ? "text" : "password";
      btn.innerHTML = `<i class="fa-solid ${isPass ? "fa-eye-slash" : "fa-eye"}"></i>`;
    });
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = form.querySelector("#admin-email");
    const password = form.querySelector("#admin-password");
    const submitBtn = form.querySelector('button[type="submit"]');

    // Real mode: log in against the actual backend. Only a user whose
    // MySQL row has role='admin' gets a token that passes @admin_required
    // on the server — a real security boundary, not just a client-side check.
    if (typeof nx_isBackendConnected === "function" && nx_isBackendConnected()) {
      if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = "Signing in…"; }
      try {
        const res = await fetch(nx_apiUrl("/api/auth/login"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: email.value.trim(), password: password.value }),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.success || data.data.user.role !== "admin") {
          nx_showFieldError(password, "Invalid admin credentials, or this account isn't an admin.");
          nx_toast("Login failed — admin access denied.", "error");
          return;
        }
        nx_setAdminSession({ token: data.data.token, user: data.data.user });
        nx_toast(`Welcome back, ${data.data.user.name.split(" ")[0]}.`);
        setTimeout(() => (window.location.href = "admin-dashboard.html"), 500);
        return;
      } catch (err) {
        nx_toast("Could not reach the backend — check it's running.", "error");
        return;
      } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = "Sign In"; }
      }
    }

    // Demo mode fallback.
    if (email.value.trim().toLowerCase() !== NX_ADMIN_DEMO_EMAIL || password.value !== NX_ADMIN_DEMO_PASSWORD) {
      nx_showFieldError(password, "Invalid admin credentials.");
      nx_toast("Login failed — admin access denied.", "error");
      return;
    }
    nx_showFieldError(password, "");
    nx_setAdminSession({ token: "demo.admin." + Date.now(), user: { name: "Admin Account", email: NX_ADMIN_DEMO_EMAIL, role: "admin" } });
    nx_toast("Welcome back, Admin.");
    setTimeout(() => (window.location.href = "admin-dashboard.html"), 500);
  });
}

function nx_guardAdminDashboard() {
  const root = document.querySelector("[data-admin-dashboard]");
  if (!root) return;
  const session = nx_getAdminSession();
  if (!session || session.user.role !== "admin") {
    window.location.href = "admin-login.html";
    return;
  }
  document.querySelectorAll("[data-admin-name]").forEach(el => el.textContent = session.user.name);
  nx_initAdminDashboard();
}

/* ==========================================================================
   Dashboard shell: sidebar nav + view switching
   ========================================================================== */

function nx_initAdminDashboard() {
  document.querySelectorAll(".admin-nav-link[data-view]").forEach(link => {
    link.addEventListener("click", () => nx_switchAdminView(link.dataset.view));
  });
  document.querySelectorAll("[data-admin-logout]").forEach(btn => btn.addEventListener("click", nx_adminLogout));

  nx_renderAdminStats();
  nx_renderAdminCharts();
  nx_renderAdminProducts();
  nx_renderAdminCategories();
  nx_renderAdminUsers();
  nx_renderAdminOrders();
  nx_renderAdminReviews();
  nx_renderAdminContacts();
  nx_renderAdminNewsletter();
  nx_wireAdminModals();
  nx_wireAdminProductSearch();
}

/* Debounced search — avoids re-rendering the table on every keystroke */
function nx_wireAdminProductSearch() {
  const input = document.querySelector("[data-admin-product-search]");
  if (!input) return;
  let timer = null;
  input.addEventListener("input", () => {
    clearTimeout(timer);
    timer = setTimeout(() => nx_renderAdminProducts(), 250);
  });
}

function nx_switchAdminView(view) {
  document.querySelectorAll(".admin-nav-link").forEach(l => l.classList.toggle("active", l.dataset.view === view));
  document.querySelectorAll(".admin-view").forEach(v => v.classList.toggle("active", v.dataset.view === view));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

/* ==========================================================================
   Stats cards
   ========================================================================== */

function nx_renderAdminStats() {
  const users = nx_adminRead(NX_ADMIN_USERS_KEY);
  const products = nx_adminRead(NX_ADMIN_PRODUCTS_KEY);
  const orders = typeof nx_getLiveOrders === "function" ? nx_getLiveOrders() : (typeof nx_getOrders === "function" ? nx_getOrders() : []);

  const totalRevenue = orders.filter(o => o.status !== "cancelled").reduce((sum, o) => sum + o.total, 0);
  const pending = orders.filter(o => o.status === "pending").length;
  const delivered = orders.filter(o => o.status === "delivered").length;

  const stats = [
    { icon: "fa-users", label: "Total Users", value: users.length, delta: "+2 this week" },
    { icon: "fa-box", label: "Total Products", value: products.length, delta: `${products.filter(p=>p.stock<10).length} low stock` },
    { icon: "fa-receipt", label: "Total Orders", value: orders.length, delta: `${pending} pending` },
    { icon: "fa-dollar-sign", label: "Total Revenue", value: `$${totalRevenue.toLocaleString(undefined,{maximumFractionDigits:0})}`, delta: `${delivered} delivered` },
  ];

  const grid = document.querySelector("[data-admin-stat-cards]");
  if (!grid) return;
  grid.innerHTML = stats.map(s => `
    <div class="stat-card">
      <div class="top"><i class="fa-solid ${s.icon}"></i></div>
      <b data-counter="${typeof s.value === 'number' ? s.value : ''}">${s.value}</b>
      <span class="label">${s.label}</span>
      <div class="delta" style="margin-top:8px;">${s.delta}</div>
    </div>
  `).join("");

  // Simple count-up animation for numeric stats (Phase 11 polish)
  grid.querySelectorAll("[data-counter]").forEach(el => {
    const target = Number(el.dataset.counter);
    if (!target) return;
    let current = 0;
    const step = Math.max(1, Math.ceil(target / 30));
    const tick = () => {
      current = Math.min(target, current + step);
      el.textContent = current;
      if (current < target) requestAnimationFrame(tick);
    };
    tick();
  });
}

/* ==========================================================================
   Charts (Chart.js, loaded via CDN in admin-dashboard.html)
   ========================================================================== */

function nx_renderAdminCharts() {
  if (typeof Chart === "undefined") return;

  const orders = typeof nx_getLiveOrders === "function" ? nx_getLiveOrders() : (typeof nx_getOrders === "function" ? nx_getOrders() : []);
  const products = nx_adminRead(NX_ADMIN_PRODUCTS_KEY);

  Chart.defaults.color = "#a9b0c2";
  Chart.defaults.borderColor = "#262b38";
  Chart.defaults.font.family = "Inter, sans-serif";

  // Sales/revenue over the last 7 days (falls back to a smooth demo curve if no real orders yet)
  const salesCanvas = document.querySelector("#chart-sales");
  if (salesCanvas) {
    const labels = [];
    const values = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      labels.push(d.toLocaleDateString(undefined, { weekday: "short" }));
      const dayTotal = orders
        .filter(o => new Date(o.createdAt).toDateString() === d.toDateString())
        .reduce((sum, o) => sum + o.total, 0);
      values.push(dayTotal || Math.round(200 + Math.random() * 500));
    }
    new Chart(salesCanvas, {
      type: "line",
      data: { labels, datasets: [{ label: "Revenue ($)", data: values, borderColor: "#00e6c3", backgroundColor: "rgba(0,230,195,0.12)", fill: true, tension: 0.4, pointBackgroundColor: "#00e6c3" }] },
      options: { plugins: { legend: { display: false } }, scales: { y: { grid: { color: "#1b1f29" } }, x: { grid: { display: false } } } }
    });
  }

  // Orders by status
  const ordersCanvas = document.querySelector("#chart-orders");
  if (ordersCanvas) {
    const statuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"];
    const counts = statuses.map(s => orders.filter(o => o.status === s).length);
    new Chart(ordersCanvas, {
      type: "doughnut",
      data: {
        labels: statuses.map(s => s[0].toUpperCase() + s.slice(1)),
        datasets: [{ data: counts.some(c => c > 0) ? counts : [1,1,1,1,1,1], backgroundColor: ["#ffb454","#00e6c3","#05f7d1","#7aa6ff","#38d97a","#ff4d5e"] }]
      },
      options: { plugins: { legend: { position: "bottom", labels: { boxWidth: 10, font: { size: 11 } } } } }
    });
  }

  // Products by category
  const productsCanvas = document.querySelector("#chart-products");
  if (productsCanvas) {
    const byCat = {};
    products.forEach(p => { byCat[p.category] = (byCat[p.category] || 0) + 1; });
    new Chart(productsCanvas, {
      type: "bar",
      data: { labels: Object.keys(byCat), datasets: [{ label: "Products", data: Object.values(byCat), backgroundColor: "#00e6c3", borderRadius: 6 }] },
      options: { plugins: { legend: { display: false } }, scales: { y: { grid: { color: "#1b1f29" }, ticks: { stepSize: 1 } }, x: { grid: { display: false } } } }
    });
  }

  // Revenue by category (demo distribution)
  const revenueCanvas = document.querySelector("#chart-revenue");
  if (revenueCanvas) {
    const byCat = {};
    products.forEach(p => { byCat[p.category] = (byCat[p.category] || 0) + p.price; });
    new Chart(revenueCanvas, {
      type: "pie",
      data: {
        labels: Object.keys(byCat),
        datasets: [{ data: Object.values(byCat), backgroundColor: ["#00e6c3","#ff5d3b","#7aa6ff","#ffb454","#38d97a","#a9b0c2","#05f7d1","#ff4d5e","#f2f4f8","#0aa389"] }]
      },
      options: { plugins: { legend: { position: "bottom", labels: { boxWidth: 10, font: { size: 10 } } } } }
    });
  }
}

/* ==========================================================================
   Products CRUD
   ========================================================================== */

function nx_renderAdminProducts() {
  const searchInput = document.querySelector("[data-admin-product-search]");
  const query = (searchInput?.value || "").trim().toLowerCase();
  const products = nx_adminRead(NX_ADMIN_PRODUCTS_KEY).filter(p => !query || p.name.toLowerCase().includes(query) || p.category.toLowerCase().includes(query));
  const tbody = document.querySelector("[data-admin-products-body]");
  if (!tbody) return;
  tbody.innerHTML = products.map(p => `
    <tr>
      <td>
        <div class="prod-cell">
          <img src="${p.image}" alt="${p.name}">
          <div><strong>${p.name}</strong><br><span style="color:var(--text-3); font-size:.76rem;">${p.brand}</span></div>
        </div>
      </td>
      <td style="text-transform:capitalize;">${p.category.replace("-", " ")}</td>
      <td>$${p.price.toLocaleString()}</td>
      <td>${p.stock}</td>
      <td>
        <div class="row-actions">
          <button title="Edit" data-edit-product="${p.id}"><i class="fa-solid fa-pen"></i></button>
          <button title="Delete" class="danger" data-delete-product="${p.id}"><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    </tr>
  `).join("");

  tbody.querySelectorAll("[data-edit-product]").forEach(btn => btn.addEventListener("click", () => nx_openProductModal(Number(btn.dataset.editProduct))));
  tbody.querySelectorAll("[data-delete-product]").forEach(btn => btn.addEventListener("click", () => nx_deleteProduct(Number(btn.dataset.deleteProduct))));
}

function nx_deleteProduct(id) {
  if (!confirm("Delete this product? This cannot be undone.")) return;
  const products = nx_adminRead(NX_ADMIN_PRODUCTS_KEY).filter(p => p.id !== id);
  nx_adminWrite(NX_ADMIN_PRODUCTS_KEY, products);
  nx_toast("Product deleted", "error");
  nx_renderAdminProducts();
  nx_renderAdminStats();
}

function nx_openProductModal(id) {
  const modal = document.querySelector("#modal-product");
  const form = modal.querySelector("form");
  const products = nx_adminRead(NX_ADMIN_PRODUCTS_KEY);
  const product = id ? products.find(p => p.id === id) : null;

  form.reset();
  form.dataset.editingId = id || "";
  modal.querySelector("h3").textContent = product ? "Edit Product" : "Add Product";

  const categories = nx_adminRead(NX_ADMIN_CATEGORIES_KEY);
  const catSelect = form.querySelector("#pm-category");
  catSelect.innerHTML = categories.map(c => `<option value="${c.slug}">${c.label}</option>`).join("");

  if (product) {
    form.querySelector("#pm-name").value = product.name;
    form.querySelector("#pm-brand").value = product.brand;
    form.querySelector("#pm-category").value = product.category;
    form.querySelector("#pm-price").value = product.price;
    form.querySelector("#pm-old-price").value = product.oldPrice || "";
    form.querySelector("#pm-stock").value = product.stock;
    form.querySelector("#pm-image").value = product.image;
    form.querySelector("#pm-desc").value = product.desc || "";
  }
  modal.classList.add("open");
}

function nx_wireAdminModals() {
  document.querySelectorAll("[data-open-add-product]").forEach(btn => btn.addEventListener("click", () => nx_openProductModal(null)));
  document.querySelectorAll("[data-open-add-category]").forEach(btn => btn.addEventListener("click", () => nx_openCategoryModal(null)));
  document.querySelectorAll("[data-close-modal]").forEach(btn => btn.addEventListener("click", () => btn.closest(".modal-overlay").classList.remove("open")));
  document.querySelectorAll(".modal-overlay").forEach(overlay => {
    overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.classList.remove("open"); });
  });

  const productForm = document.querySelector("#modal-product form");
  if (productForm) {
    productForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const editingId = productForm.dataset.editingId ? Number(productForm.dataset.editingId) : null;
      const products = nx_adminRead(NX_ADMIN_PRODUCTS_KEY);

      const payload = {
        name: productForm.querySelector("#pm-name").value.trim(),
        brand: productForm.querySelector("#pm-brand").value.trim() || "Nexora",
        category: productForm.querySelector("#pm-category").value,
        price: Number(productForm.querySelector("#pm-price").value),
        oldPrice: productForm.querySelector("#pm-old-price").value ? Number(productForm.querySelector("#pm-old-price").value) : null,
        stock: Number(productForm.querySelector("#pm-stock").value) || 0,
        image: productForm.querySelector("#pm-image").value.trim(),
        desc: productForm.querySelector("#pm-desc").value.trim(),
      };

      if (!payload.name || !payload.category || !payload.price) {
        nx_toast("Name, category and price are required.", "error");
        return;
      }

      if (editingId) {
        const idx = products.findIndex(p => p.id === editingId);
        if (idx > -1) products[idx] = { ...products[idx], ...payload };
        nx_toast("Product updated");
      } else {
        const newId = products.length ? Math.max(...products.map(p => p.id)) + 1 : 1;
        products.push({ id: newId, rating: 0, reviews: 0, gallery: [payload.image], colors: ["#1e222d"], specs: {}, tag: "new", ...payload });
        nx_toast("Product created");
      }

      nx_adminWrite(NX_ADMIN_PRODUCTS_KEY, products);
      document.querySelector("#modal-product").classList.remove("open");
      nx_renderAdminProducts();
      nx_renderAdminStats();
      nx_renderAdminCharts();
    });
  }

  const categoryForm = document.querySelector("#modal-category form");
  if (categoryForm) {
    categoryForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const editingSlug = categoryForm.dataset.editingSlug || "";
      const categories = nx_adminRead(NX_ADMIN_CATEGORIES_KEY);

      const payload = {
        label: categoryForm.querySelector("#cm-name").value.trim(),
        slug: categoryForm.querySelector("#cm-slug").value.trim().toLowerCase().replace(/\s+/g, "-"),
        icon: categoryForm.querySelector("#cm-icon").value.trim() || "fa-tag",
      };
      if (!payload.label || !payload.slug) { nx_toast("Name and slug are required.", "error"); return; }

      if (editingSlug) {
        const idx = categories.findIndex(c => c.slug === editingSlug);
        if (idx > -1) categories[idx] = payload;
        nx_toast("Category updated");
      } else {
        if (categories.some(c => c.slug === payload.slug)) { nx_toast("A category with this slug already exists.", "error"); return; }
        categories.push(payload);
        nx_toast("Category created");
      }
      nx_adminWrite(NX_ADMIN_CATEGORIES_KEY, categories);
      document.querySelector("#modal-category").classList.remove("open");
      nx_renderAdminCategories();
    });
  }
}

/* ==========================================================================
   Categories CRUD
   ========================================================================== */

function nx_renderAdminCategories() {
  const categories = nx_adminRead(NX_ADMIN_CATEGORIES_KEY);
  const products = nx_adminRead(NX_ADMIN_PRODUCTS_KEY);
  const tbody = document.querySelector("[data-admin-categories-body]");
  if (!tbody) return;
  tbody.innerHTML = categories.map(c => `
    <tr>
      <td><i class="fa-solid ${c.icon}" style="color:var(--signal); width:20px;"></i> ${c.label}</td>
      <td><code style="color:var(--text-3);">${c.slug}</code></td>
      <td>${products.filter(p => p.category === c.slug).length}</td>
      <td>
        <div class="row-actions">
          <button title="Edit" data-edit-category="${c.slug}"><i class="fa-solid fa-pen"></i></button>
          <button title="Delete" class="danger" data-delete-category="${c.slug}"><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    </tr>
  `).join("");

  tbody.querySelectorAll("[data-edit-category]").forEach(btn => btn.addEventListener("click", () => nx_openCategoryModal(btn.dataset.editCategory)));
  tbody.querySelectorAll("[data-delete-category]").forEach(btn => btn.addEventListener("click", () => nx_deleteCategory(btn.dataset.deleteCategory)));
}

function nx_deleteCategory(slug) {
  if (!confirm("Delete this category?")) return;
  const categories = nx_adminRead(NX_ADMIN_CATEGORIES_KEY).filter(c => c.slug !== slug);
  nx_adminWrite(NX_ADMIN_CATEGORIES_KEY, categories);
  nx_toast("Category deleted", "error");
  nx_renderAdminCategories();
}

function nx_openCategoryModal(slug) {
  const modal = document.querySelector("#modal-category");
  const form = modal.querySelector("form");
  const categories = nx_adminRead(NX_ADMIN_CATEGORIES_KEY);
  const category = slug ? categories.find(c => c.slug === slug) : null;

  form.reset();
  form.dataset.editingSlug = slug || "";
  modal.querySelector("h3").textContent = category ? "Edit Category" : "Add Category";

  if (category) {
    form.querySelector("#cm-name").value = category.label;
    form.querySelector("#cm-slug").value = category.slug;
    form.querySelector("#cm-icon").value = category.icon;
  }
  modal.classList.add("open");
}

/* ==========================================================================
   Order management
   ========================================================================== */

function nx_renderAdminOrders() {
  const orders = typeof nx_getLiveOrders === "function" ? nx_getLiveOrders() : (typeof nx_getOrders === "function" ? nx_getOrders() : []);
  const tbody = document.querySelector("[data-admin-orders-body]");
  const empty = document.querySelector("[data-admin-orders-empty]");
  if (!tbody) return;

  if (!orders.length) {
    tbody.innerHTML = "";
    if (empty) empty.style.display = "block";
    return;
  }
  if (empty) empty.style.display = "none";

  const statuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"];
  tbody.innerHTML = orders.map(o => `
    <tr>
      <td><strong>${o.id}</strong></td>
      <td>${o.customer.name}<br><span style="color:var(--text-3); font-size:.76rem;">${o.customer.email}</span></td>
      <td>${new Date(o.createdAt).toLocaleDateString()}</td>
      <td>$${o.total.toFixed(2)}</td>
      <td>
        <select data-order-status-select="${o.id}">
          ${statuses.map(s => `<option value="${s}" ${s === o.status ? "selected" : ""}>${s[0].toUpperCase()+s.slice(1)}</option>`).join("")}
        </select>
      </td>
      <td class="row-actions">
        <a href="order-detail.html?order=${o.id}" target="_blank"><button title="View"><i class="fa-solid fa-eye"></i></button></a>
        ${nx_isBackendConnected() && o.backendOrderId
          ? `<button title="Book with real courier (Shiprocket)" data-ship-order="${o.backendOrderId}"><i class="fa-solid fa-truck-fast"></i></button>`
          : ""}
      </td>
    </tr>
  `).join("");

  tbody.querySelectorAll("[data-ship-order]").forEach(btn => {
    btn.addEventListener("click", () => nx_shipOrderViaCourier(btn.dataset.shipOrder, btn));
  });

  tbody.querySelectorAll("[data-order-status-select]").forEach(sel => {
    sel.addEventListener("change", () => {
      nx_updateOrderStatus(sel.dataset.orderStatusSelect, sel.value);
      nx_toast(`Order ${sel.dataset.orderStatusSelect} marked ${sel.value}`);
      nx_renderAdminStats();
      nx_renderAdminCharts();
    });
  });
}

/** Books a real courier pickup (Shiprocket, via the backend) for one order
 *  and stores the resulting AWB/tracking number — a genuine handoff to a
 *  real shipping partner, not a simulation. */
async function nx_shipOrderViaCourier(backendOrderId, btn) {
  const session = nx_getAdminSession();
  if (!session || !session.token) { nx_toast("Admin session expired — please log in again.", "error"); return; }

  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

  try {
    const res = await fetch(nx_apiUrl("/api/shipping/create-shipment"), {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${session.token}` },
      body: JSON.stringify({ order_id: backendOrderId }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) throw new Error(data.error || data.message || "Could not book courier");

    nx_toast(`Booked with ${data.data.courier_name || "courier"} — AWB ${data.data.awb_code}`);
    nx_renderAdminOrders();
  } catch (err) {
    nx_toast(err.message || "Could not book courier — check Shiprocket is configured in backend/.env.", "error");
    btn.disabled = false;
    btn.innerHTML = original;
  }
}

/* ==========================================================================
   Users, Reviews, Contacts, Newsletter (read + moderate)
   ========================================================================== */

function nx_renderAdminUsers() {
  const users = nx_adminRead(NX_ADMIN_USERS_KEY);
  const tbody = document.querySelector("[data-admin-users-body]");
  if (!tbody) return;
  tbody.innerHTML = users.map(u => `
    <tr>
      <td>${u.name}</td>
      <td>${u.email}</td>
      <td><span class="order-status-pill ${u.role === 'admin' ? 'status-delivered' : ''}">${u.role}</span></td>
      <td>${u.createdAt}</td>
      <td>
        <div class="row-actions">
          <button title="Remove" class="danger" data-delete-user="${u.id}" ${u.role === 'admin' ? 'disabled' : ''}><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    </tr>
  `).join("");
  tbody.querySelectorAll("[data-delete-user]").forEach(btn => btn.addEventListener("click", () => {
    if (!confirm("Remove this user account?")) return;
    const users2 = nx_adminRead(NX_ADMIN_USERS_KEY).filter(u => u.id !== Number(btn.dataset.deleteUser));
    nx_adminWrite(NX_ADMIN_USERS_KEY, users2);
    nx_toast("User removed", "error");
    nx_renderAdminUsers();
    nx_renderAdminStats();
  }));
}

function nx_renderAdminReviews() {
  const reviews = nx_adminRead(NX_ADMIN_REVIEWS_KEY);
  const tbody = document.querySelector("[data-admin-reviews-body]");
  if (!tbody) return;
  tbody.innerHTML = reviews.map(r => `
    <tr>
      <td>${r.productName}</td>
      <td>${r.userName}</td>
      <td>${"★".repeat(r.rating)}${"☆".repeat(5-r.rating)}</td>
      <td style="max-width:260px;">${r.comment}</td>
      <td>
        <div class="row-actions">
          <button title="Delete" class="danger" data-delete-review="${r.id}"><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    </tr>
  `).join("");
  tbody.querySelectorAll("[data-delete-review]").forEach(btn => btn.addEventListener("click", () => {
    const reviews2 = nx_adminRead(NX_ADMIN_REVIEWS_KEY).filter(r => r.id !== Number(btn.dataset.deleteReview));
    nx_adminWrite(NX_ADMIN_REVIEWS_KEY, reviews2);
    nx_toast("Review deleted", "error");
    nx_renderAdminReviews();
  }));
}

function nx_renderAdminContacts() {
  const contacts = nx_adminRead(NX_ADMIN_CONTACTS_KEY);
  const tbody = document.querySelector("[data-admin-contacts-body]");
  if (!tbody) return;
  tbody.innerHTML = contacts.map(c => `
    <tr>
      <td>${c.name}<br><span style="color:var(--text-3); font-size:.76rem;">${c.email}</span></td>
      <td>${c.subject}</td>
      <td style="max-width:280px;">${c.message}</td>
      <td>${c.createdAt}</td>
      <td>
        <div class="row-actions">
          <button title="${c.read ? 'Mark unread' : 'Mark read'}" data-toggle-read="${c.id}"><i class="fa-solid ${c.read ? 'fa-envelope-open' : 'fa-envelope'}"></i></button>
          <button title="Delete" class="danger" data-delete-contact="${c.id}"><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    </tr>
  `).join("");
  tbody.querySelectorAll("[data-toggle-read]").forEach(btn => btn.addEventListener("click", () => {
    const contacts2 = nx_adminRead(NX_ADMIN_CONTACTS_KEY);
    const item = contacts2.find(c => c.id === Number(btn.dataset.toggleRead));
    if (item) item.read = !item.read;
    nx_adminWrite(NX_ADMIN_CONTACTS_KEY, contacts2);
    nx_renderAdminContacts();
  }));
  tbody.querySelectorAll("[data-delete-contact]").forEach(btn => btn.addEventListener("click", () => {
    const contacts2 = nx_adminRead(NX_ADMIN_CONTACTS_KEY).filter(c => c.id !== Number(btn.dataset.deleteContact));
    nx_adminWrite(NX_ADMIN_CONTACTS_KEY, contacts2);
    nx_toast("Message deleted", "error");
    nx_renderAdminContacts();
  }));
}

function nx_renderAdminNewsletter() {
  const subs = nx_adminRead(NX_ADMIN_NEWSLETTER_KEY);
  const tbody = document.querySelector("[data-admin-newsletter-body]");
  const countEl = document.querySelector("[data-newsletter-count]");
  if (countEl) countEl.textContent = subs.length;
  if (!tbody) return;
  tbody.innerHTML = subs.map(s => `
    <tr>
      <td>${s.email}</td>
      <td>${s.createdAt}</td>
      <td>
        <div class="row-actions">
          <button title="Remove" class="danger" data-delete-sub="${s.id}"><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    </tr>
  `).join("");
  tbody.querySelectorAll("[data-delete-sub]").forEach(btn => btn.addEventListener("click", () => {
    const subs2 = nx_adminRead(NX_ADMIN_NEWSLETTER_KEY).filter(s => s.id !== Number(btn.dataset.deleteSub));
    nx_adminWrite(NX_ADMIN_NEWSLETTER_KEY, subs2);
    nx_toast("Subscriber removed", "error");
    nx_renderAdminNewsletter();
  }));
}
