/* ==========================================================================
   NEXORA — render.js
   Shared markup builders so every page renders product cards identically.
   ========================================================================== */

function nx_stars(rating) {
  const full = Math.round(rating);
  return "★".repeat(full) + "☆".repeat(5 - full);
}

function nx_productCardHTML(p) {
  const wished = nx_isWishlisted(p.id);
  const off = p.oldPrice ? Math.round(100 - (p.price / p.oldPrice) * 100) : null;
  const stockNote = p.stock === 0 ? `<span class="stock-note out">Out of stock</span>`
    : p.stock <= 8 ? `<span class="stock-note low">Only ${p.stock} left</span>`
    : `<span class="stock-note">In stock</span>`;

  return `
  <div class="product-card reveal" data-id="${p.id}">
    <div class="thumb">
      ${p.tag ? `<span class="badge-tag ${p.tag === "new" ? "new" : ""}">${p.tag === "new" ? "New" : `-${off}%`}</span>` : ""}
      <div class="quick-actions">
        <button type="button" title="Wishlist" data-wishlist-btn="${p.id}" class="${wished ? "active" : ""}" onclick="nx_toggleWishlist(${p.id})">
          <i class="fa-solid fa-heart"></i>
        </button>
        <button type="button" title="Quick view" onclick="window.location.href = 'product-details.html?id=${p.id}'">
          <i class="fa-solid fa-eye"></i>
        </button>
      </div>
      <a href="product-details.html?id=${p.id}"><img src="${p.image}" alt="${p.name}" loading="lazy"></a>
    </div>
    <div class="body">
      <span class="cat">${p.category.replace("-", " ")}</span>
      <h3><a href="product-details.html?id=${p.id}">${p.name}</a></h3>
      <div class="rating"><span class="stars">${nx_stars(p.rating)}</span> ${p.rating} (${p.reviews})</div>
      <div class="price-row">
        <span class="now">$${p.price.toLocaleString()}</span>
        ${p.oldPrice ? `<span class="was">$${p.oldPrice.toLocaleString()}</span><span class="off">-${off}%</span>` : ""}
      </div>
      ${stockNote}
      <button type="button" class="add-btn" ${p.stock === 0 ? "disabled" : ""} onclick="nx_addToCart(${p.id})">
        <i class="fa-solid fa-cart-plus"></i> ${p.stock === 0 ? "Out of stock" : "Add to Cart"}
      </button>
    </div>
  </div>`;
}

function nx_renderGrid(container, products) {
  if (!container) return;
  if (!products.length) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        <i class="fa-solid fa-magnifying-glass"></i>
        <h3>No products found</h3>
        <p>Try adjusting your filters or search terms.</p>
      </div>`;
    return;
  }
  container.innerHTML = products.map(nx_productCardHTML).join("");
  nx_initRevealOnScroll();
}
