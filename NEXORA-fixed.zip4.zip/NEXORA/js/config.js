/* ==========================================================================
   NEXORA — config.js
   Central switches for going from "demo mode" to a real, hosted site.
   Load this file FIRST, before any other <script>, on every page.
   ========================================================================== */

const NEXORA_CONFIG = {
  /**
   * Base URL of your deployed Flask API, e.g. "https://api.yourdomain.com"
   * or "http://127.0.0.1:5000" while testing locally.
   *
   * Leave this as an empty string to run the site in fully offline DEMO
   * MODE — accounts, cart, wishlist and orders are then stored only in
   * this browser's localStorage (nothing leaves the device).
   *
   * Set it once the backend in /backend is deployed and reachable, and
   * every login/register/order call in auth.js and checkout.js will
   * automatically switch to talking to your real API instead.
   */
  API_BASE_URL: "",

  /**
   * Razorpay publishable **test** key (safe to expose in frontend code —
   * it cannot move money on its own). Get your own at
   * https://dashboard.razorpay.com/app/keys — the "Key Id" starting with
   * rzp_test_ (or rzp_live_ once you go live).
   *
   * This is a placeholder test key id. Replace it with your own before
   * accepting real payments. The matching Key Secret goes server-side
   * only, in backend/.env — never in this file.
   */
  RAZORPAY_KEY_ID: "rzp_test_1DP5mmOlF5G5ag",

  /** Company details used in invoices, footer and the LICENSE. */
  COMPANY_NAME: "NEXORA Electronics",
  SUPPORT_EMAIL: "support@nexora.example",

  /**
   * Customer care / complaints helpline — shown in the footer, contact
   * page, product page and order page. Change it ONCE here and every
   * "Call Customer Care" link/number on the site updates automatically
   * (see nx_applySupportContact in main.js).
   * SUPPORT_PHONE_TEL must be in international dial format (no spaces,
   * starts with +countrycode) — this is what actually goes in tel:.
   * SUPPORT_PHONE_DISPLAY is the human-readable text shown to visitors.
   */
  SUPPORT_PHONE_TEL: "+18001234567",
  SUPPORT_PHONE_DISPLAY: "1800-123-4567",

  /**
   * UPI details used to render the "Scan & Pay" QR code on the checkout
   * page's UPI payment option. UPI_ID is your real VPA (e.g.
   * "yourbusiness@okhdfcbank" / "yourbusiness@ybl") — replace the demo
   * value below with your own before going live, or the QR code will
   * point at a non-existent account.
   */
  UPI_ID: "nexora@upi",
  UPI_PAYEE_NAME: "NEXORA Electronics",

  /** True once you've swapped in real keys/API_BASE_URL for production. */
  IS_LIVE: false,

  /**
   * Deterrent-level copy protection (js/protect.js): blocks right-click,
   * image dragging, and common "view source / save page / devtools"
   * shortcuts, and prints a warning in the browser console.
   *
   * Be clear with yourself about what this does and doesn't do: it stops
   * casual copying, but any visitor can still view your HTML/CSS/JS via
   * browser dev tools, "view-source:", or the Network tab — no front-end
   * trick can prevent that. Real protection is: the LICENSE file (legal
   * right to act if someone republishes your work), not publishing your
   * source publicly, and/or minifying or server-rendering sensitive logic.
   * Set to false any time during development — it re-enables normal
   * right-click/select/devtools behavior instantly.
   */
  ENABLE_COPY_PROTECTION: false,

  /**
   * Order tracking has two independent parts:
   *  - The delivery DATE shown to the customer is always realistic (2-3
   *    days for express, 5-7 for standard), calculated from real calendar
   *    days — this is what an actual customer would see.
   *  - The STATUS shown on the order-detail page (pending → confirmed →
   *    processing → shipped → delivered) can optionally progress on an
   *    accelerated demo clock instead of waiting real days, so you can
   *    actually watch an order move through its lifecycle while testing
   *    or demoing the site. This has zero effect on the delivery date
   *    shown — only on how fast the status badge updates.
   *  Set to false for status to progress on the same real-world timeline
   *  as the delivery date (realistic, but nothing will visibly move for
   *  days — appropriate once this is a real, hosted store).
   */
  DEMO_FAST_TRACKING: true,
};

function nx_isBackendConnected() {
  return Boolean(NEXORA_CONFIG.API_BASE_URL && NEXORA_CONFIG.API_BASE_URL.trim());
}

function nx_apiUrl(path) {
  return NEXORA_CONFIG.API_BASE_URL.replace(/\/$/, "") + path;
}
