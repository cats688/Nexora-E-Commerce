/* ==========================================================================
   NEXORA — product-details.js
   ========================================================================== */

let nx_pdQty = 1;

document.addEventListener("DOMContentLoaded", () => {
  if (!document.querySelector(".pd-layout")) return;

  const params = new URLSearchParams(window.location.search);
  const product = nx_findProduct(params.get("id") || 1);
  if (!product) {
    document.querySelector(".pd-layout").innerHTML = `<div class="empty-state"><h3>Product not found</h3></div>`;
    return;
  }
  nx_renderProductDetails(product);
  nx_wireTabs();
  nx_renderSimilar(product);
  nx_injectProductSEO(product);
  nx_wireProductTilt();
});

/**
 * 3D tilt-on-hover for the main product photo — the image tips toward
 * the cursor (like turning the device in your hand) with a glossy
 * highlight that tracks the pointer, and eases back flat on mouse-leave.
 * Pure CSS transform driven by two custom properties; skipped entirely
 * on touch devices and when the visitor prefers reduced motion.
 */
function nx_wireProductTilt() {
  const frame = document.querySelector(".pd-gallery .main-frame");
  const img = frame?.querySelector("[data-pd-main-img]");
  if (!frame || !img) return;
  if (window.matchMedia("(hover: none)").matches) return;
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

  const MAX_TILT = 14; // degrees

  frame.addEventListener("mousemove", (e) => {
    const rect = frame.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;  // 0..1
    const py = (e.clientY - rect.top) / rect.height;   // 0..1
    const ry = (px - 0.5) * 2 * MAX_TILT;
    const rx = (0.5 - py) * 2 * MAX_TILT;
    frame.classList.add("tilting");
    frame.style.setProperty("--pd-rx", `${rx}deg`);
    frame.style.setProperty("--pd-ry", `${ry}deg`);
    frame.style.setProperty("--pd-scale", "1.04");
    frame.style.setProperty("--pd-glow-x", `${px * 100}%`);
    frame.style.setProperty("--pd-glow-y", `${py * 100}%`);
  });

  frame.addEventListener("mouseleave", () => {
    frame.classList.remove("tilting");
    frame.style.setProperty("--pd-rx", "0deg");
    frame.style.setProperty("--pd-ry", "0deg");
    frame.style.setProperty("--pd-scale", "1");
  });
}

/** Injects Product structured data (JSON-LD) + Open Graph tags for this
 *  specific product — this is what lets Google show price/stock/rating
 *  directly in search results and Google Shopping once the site is live
 *  on a real domain. Runs client-side since the product is chosen by a
 *  ?id= query param; search engines that execute JS (Googlebot does) will
 *  still pick this up. */
function nx_injectProductSEO(p) {
  const baseUrl = "https://www.nexora.example"; // replace with your real domain once deployed
  const pageUrl = `${baseUrl}/product-details.html?id=${p.id}`;
  const desc = p.desc || `${p.name} by ${p.brand} — available now at NEXORA.`;

  const head = document.head;

  const metaDesc = document.createElement("meta");
  metaDesc.name = "description";
  metaDesc.content = desc;
  head.appendChild(metaDesc);

  const canonical = document.createElement("link");
  canonical.rel = "canonical";
  canonical.href = pageUrl;
  head.appendChild(canonical);

  [
    ["og:type", "product"],
    ["og:title", `${p.name} — NEXORA`],
    ["og:description", desc],
    ["og:image", p.image],
    ["og:url", pageUrl],
    ["product:price:amount", String(p.price)],
    ["product:price:currency", "USD"],
  ].forEach(([property, content]) => {
    const m = document.createElement("meta");
    m.setAttribute("property", property);
    m.setAttribute("content", content);
    head.appendChild(m);
  });

  const jsonLd = document.createElement("script");
  jsonLd.type = "application/ld+json";
  jsonLd.textContent = JSON.stringify({
    "@context": "https://schema.org",
    "@type": "Product",
    "name": p.name,
    "image": [p.image, ...(p.gallery || [])],
    "description": desc,
    "brand": { "@type": "Brand", "name": p.brand },
    "sku": `NXR-${p.id}`,
    "aggregateRating": p.reviews > 0 ? {
      "@type": "AggregateRating",
      "ratingValue": p.rating,
      "reviewCount": p.reviews
    } : undefined,
    "offers": {
      "@type": "Offer",
      "url": pageUrl,
      "priceCurrency": "USD",
      "price": p.price,
      "availability": p.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      "itemCondition": "https://schema.org/NewCondition"
    }
  });
  head.appendChild(jsonLd);
}

function nx_renderProductDetails(p) {
  document.title = `${p.name} — NEXORA`;

  document.querySelector("[data-pd-crumb]").textContent = p.name;
  document.querySelector("[data-pd-brand]").textContent = p.brand;
  document.querySelector("[data-pd-name]").textContent = p.name;
  document.querySelector("[data-pd-rating-stars]").textContent = nx_stars(p.rating);
  document.querySelector("[data-pd-rating-text]").textContent = `${p.rating} (${p.reviews} reviews)`;
  document.querySelector("[data-pd-price]").textContent = `$${p.price.toLocaleString()}`;
  const oldPriceEl = document.querySelector("[data-pd-old-price]");
  const offEl = document.querySelector("[data-pd-off]");
  if (p.oldPrice) {
    oldPriceEl.textContent = `$${p.oldPrice.toLocaleString()}`;
    offEl.textContent = `-${Math.round(100 - (p.price / p.oldPrice) * 100)}%`;
  } else {
    oldPriceEl.style.display = "none";
    offEl.style.display = "none";
  }
  document.querySelector("[data-pd-desc]").textContent = p.desc;
  document.querySelector("[data-pd-stock]").textContent = p.stock > 8 ? "In stock" : p.stock > 0 ? `Only ${p.stock} left` : "Out of stock";

  const mainImg = document.querySelector("[data-pd-main-img]");
  mainImg.src = p.image;
  mainImg.alt = p.name;

  const thumbWrap = document.querySelector("[data-pd-thumbs]");
  thumbWrap.innerHTML = p.gallery.map((src, i) =>
    `<button type="button" class="${i === 0 ? "active" : ""}" onclick="nx_switchThumb('${src}', this)"><img src="${src}" alt="thumbnail ${i + 1}"></button>`
  ).join("");

  const swatchWrap = document.querySelector("[data-pd-swatches]");
  swatchWrap.innerHTML = p.colors.map((c, i) =>
    `<button type="button" class="swatch ${i === 0 ? "active" : ""}" style="background:${c}" onclick="nx_switchSwatch(this)" title="Color option"></button>`
  ).join("");

  document.querySelector("[data-pd-specs]").innerHTML = Object.entries(p.specs).map(([k, v]) =>
    `<tr><td>${k}</td><td>${v}</td></tr>`
  ).join("");

  const wishBtn = document.querySelector("[data-pd-wishlist]");
  wishBtn.setAttribute("data-wishlist-btn", p.id);
  wishBtn.classList.toggle("active", nx_isWishlisted(p.id));
  wishBtn.onclick = () => nx_toggleWishlist(p.id);

  const addBtn = document.querySelector("[data-pd-add]");
  const buyBtn = document.querySelector("[data-pd-buy]");
  addBtn.disabled = p.stock === 0;
  buyBtn.disabled = p.stock === 0;
  addBtn.onclick = () => nx_addToCart(p.id, nx_pdQty);
  buyBtn.onclick = () => { nx_addToCart(p.id, nx_pdQty); window.location.href = "cart.html"; };

  document.querySelectorAll("[data-qty-minus]").forEach(b => b.onclick = () => nx_setPdQty(-1));
  document.querySelectorAll("[data-qty-plus]").forEach(b => b.onclick = () => nx_setPdQty(1));
  const qtyInput = document.querySelector("[data-qty-input]");
  if (qtyInput) qtyInput.value = nx_pdQty;
}

function nx_setPdQty(delta) {
  nx_pdQty = Math.max(1, nx_pdQty + delta);
  const qtyInput = document.querySelector("[data-qty-input]");
  if (qtyInput) qtyInput.value = nx_pdQty;
}

function nx_switchThumb(src, btn) {
  document.querySelector("[data-pd-main-img]").src = src;
  document.querySelectorAll("[data-pd-thumbs] button").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
}
function nx_switchSwatch(btn) {
  document.querySelectorAll("[data-pd-swatches] .swatch").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
}

function nx_wireTabs() {
  document.querySelectorAll(".tab-nav button").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-nav button").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      document.querySelector(`[data-tab-panel="${btn.dataset.tab}"]`).classList.add("active");
    });
  });
}

function nx_renderSimilar(p) {
  const similar = nx_getAllProducts().filter(x => x.category === p.category && x.id !== p.id).slice(0, 4);
  nx_renderGrid(document.querySelector("[data-similar-grid]"), similar);
}
