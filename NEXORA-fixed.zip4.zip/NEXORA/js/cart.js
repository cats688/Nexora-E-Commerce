/* ==========================================================================
   NEXORA — cart.js
   Frontend cart engine (Phase 4). Persists to localStorage now; every
   function here maps 1:1 to a future REST endpoint from Phase 8:
     nx_getCart()      -> GET  /api/cart
     nx_addToCart()    -> POST /api/cart/items
     nx_updateQty()    -> PUT  /api/cart/items/:id
     nx_removeFromCart() -> DELETE /api/cart/items/:id
   Swapping storage for fetch() later does not require touching the UI code
   in cart.html, since both paths resolve to the same shape: an array of
   { id, qty }-derived line items.
   ========================================================================== */

const NX_CART_KEY = "nexora_cart";
const NX_COUPONS = { NEXORA10: 0.10, WELCOME15: 0.15 };
const NX_COUPON_KEY = "nexora_active_coupon";

function nx_getActiveCoupon() {
  return localStorage.getItem(NX_COUPON_KEY) || "";
}
function nx_setActiveCoupon(code) {
  if (code) localStorage.setItem(NX_COUPON_KEY, code);
  else localStorage.removeItem(NX_COUPON_KEY);
}

function nx_getCart() {
  try {
    return JSON.parse(localStorage.getItem(NX_CART_KEY)) || [];
  } catch {
    return [];
  }
}

function nx_saveCart(cart) {
  localStorage.setItem(NX_CART_KEY, JSON.stringify(cart));
  nx_syncBadgeCounts();
}

function nx_addToCart(productId, qty = 1) {
  const cart = nx_getCart();
  const existing = cart.find(i => i.id === Number(productId));
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id: Number(productId), qty });
  }
  nx_saveCart(cart);
  const product = typeof nx_findProduct === "function" ? nx_findProduct(productId) : null;
  nx_toast(`${product ? product.name : "Item"} added to cart`);
}

function nx_updateQty(productId, qty) {
  const cart = nx_getCart();
  const item = cart.find(i => i.id === Number(productId));
  if (!item) return;
  item.qty = Math.max(1, qty);
  nx_saveCart(cart);
}

function nx_removeFromCart(productId) {
  let cart = nx_getCart();
  cart = cart.filter(i => i.id !== Number(productId));
  nx_saveCart(cart);
  nx_toast("Item removed from cart", "error");
}

function nx_clearCart() {
  nx_saveCart([]);
  nx_setActiveCoupon("");
}

function nx_cartTotals(couponCode) {
  const cart = nx_getCart();
  const lines = cart.map(i => {
    const product = nx_findProduct(i.id);
    return product ? { ...i, product, lineTotal: product.price * i.qty } : null;
  }).filter(Boolean);

  const subtotal = lines.reduce((sum, l) => sum + l.lineTotal, 0);
  const discountRate = couponCode && NX_COUPONS[couponCode.toUpperCase()] ? NX_COUPONS[couponCode.toUpperCase()] : 0;
  const discount = subtotal * discountRate;
  const shipping = subtotal === 0 || subtotal > 500 ? 0 : 15;
  const taxable = subtotal - discount;
  const tax = taxable * 0.08;
  const total = taxable + shipping + tax;

  return { lines, subtotal, discount, discountRate, shipping, tax, total };
}

/* ==========================================================================
   Wishlist
   ========================================================================== */

const NX_WISHLIST_KEY = "nexora_wishlist";

function nx_getWishlist() {
  try {
    return JSON.parse(localStorage.getItem(NX_WISHLIST_KEY)) || [];
  } catch {
    return [];
  }
}

function nx_saveWishlist(list) {
  localStorage.setItem(NX_WISHLIST_KEY, JSON.stringify(list));
  nx_syncBadgeCounts();
}

function nx_isWishlisted(productId) {
  return nx_getWishlist().includes(Number(productId));
}

function nx_toggleWishlist(productId) {
  let list = nx_getWishlist();
  const id = Number(productId);
  const product = nx_findProduct(id);
  if (list.includes(id)) {
    list = list.filter(x => x !== id);
    nx_toast(`${product ? product.name : "Item"} removed from wishlist`, "error");
  } else {
    list.push(id);
    nx_toast(`${product ? product.name : "Item"} added to wishlist`);
  }
  nx_saveWishlist(list);
  document.querySelectorAll(`[data-wishlist-btn="${id}"]`).forEach(btn => {
    btn.classList.toggle("active", list.includes(id));
  });
  return list.includes(id);
}

function nx_moveToCart(productId) {
  nx_addToCart(productId, 1);
  let list = nx_getWishlist().filter(x => x !== Number(productId));
  nx_saveWishlist(list);
}
