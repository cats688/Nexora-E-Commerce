/* ==========================================================================
   NEXORA — checkout.js   (Phase 9)
   Builds an order from the current cart, "processes" a mock payment, saves
   the order to localStorage (so both the customer's Order History and the
   Admin Dashboard can read it), then clears the cart.

   How this maps to the real backend (Phase 8/9):
     Create order -> POST /api/orders   { items, shipping_address }  (see
     backend/routes/order_routes.py — already implemented and DB-backed)
     List orders  -> GET  /api/orders
   Swapping nx_getOrders()/nx_placeOrder() below for fetch() calls is the
   only change needed once the backend is running.
   ========================================================================== */

const NX_ORDERS_KEY = "nexora_orders";
const NX_ORDER_STATUSES = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"];

// Real calendar days per shipping method — used for the delivery date shown
// to the customer (always realistic, regardless of demo tracking speed).
const NX_SHIPPING_DAYS = { standard: 6, express: 2 };

function nx_getOrders() {
  try { return JSON.parse(localStorage.getItem(NX_ORDERS_KEY)) || []; } catch { return []; }
}
function nx_saveOrders(orders) { localStorage.setItem(NX_ORDERS_KEY, JSON.stringify(orders)); }

function nx_generateOrderId() {
  const n = Math.floor(100000 + Math.random() * 900000);
  return `NXR-${n}`;
}

async function nx_placeOrder(details) {
  const { lines, subtotal, discount, shipping, tax, total } = nx_cartTotals(details.coupon || "");
  if (!lines.length) return null;

  const session = typeof nx_getSession === "function" ? nx_getSession() : null;
  const createdAt = new Date();
  const shippingDays = NX_SHIPPING_DAYS[details.shippingMethod] || NX_SHIPPING_DAYS.standard;
  const estimatedDelivery = new Date(createdAt.getTime() + shippingDays * 24 * 60 * 60 * 1000);

  // Real mode: also create the order in MySQL via the backend, so it's a
  // genuine, durable record (and — if Shiprocket is configured — something
  // an admin can actually hand to a real courier from the dashboard). This
  // never blocks checkout: if the API call fails, the order still saves
  // locally so the customer isn't stuck.
  let backendOrderId = null;
  if (nx_isBackendConnected() && session && session.token && !session.token.startsWith("demo.")) {
    try {
      const res = await fetch(nx_apiUrl("/api/orders"), {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${session.token}` },
        body: JSON.stringify({
          items: lines.map(l => ({ product_id: l.product.id, quantity: l.qty, price: l.product.price })),
          shipping_address: {
            line1: details.shippingAddress.line1,
            city: details.shippingAddress.city,
            state: details.shippingAddress.state,
            zip: details.shippingAddress.zip,
            country: "India",
          },
          name: details.name,
          phone: details.phone,
        }),
      });
      const resData = await res.json().catch(() => ({}));
      if (res.ok && resData.success) backendOrderId = resData.data.order_id;
    } catch (err) {
      console.warn("Backend order creation failed — order still saved locally.", err);
    }
  }

  const order = {
    id: nx_generateOrderId(),
    backendOrderId: backendOrderId, // MySQL order id, when the backend is connected — used for real courier tracking
    createdAt: createdAt.toISOString(),
    estimatedDelivery: estimatedDelivery.toISOString(),
    status: "pending",
    statusOverride: false, // true once an admin manually sets a status — stops auto-progression
    paymentReference: details.paymentReference || null,
    customer: {
      name: details.name,
      email: details.email,
      phone: details.phone
    },
    shippingAddress: details.shippingAddress,
    billingAddress: details.billingSameAsShipping ? details.shippingAddress : details.billingAddress,
    shippingMethod: details.shippingMethod,
    paymentMethod: details.paymentMethod,
    coupon: details.coupon || null,
    items: lines.map(l => ({
      productId: l.product.id,
      name: l.product.name,
      image: l.product.image,
      price: l.product.price,
      qty: l.qty,
      lineTotal: l.lineTotal
    })),
    subtotal, discount, shipping, tax, total,
    userEmail: session ? session.user.email : null
  };

  const orders = nx_getOrders();
  orders.unshift(order);
  nx_saveOrders(orders);
  nx_clearCart();
  localStorage.setItem("nexora_last_order", order.id);
  return order;
}

function nx_getOrder(orderId) {
  return nx_getOrders().find(o => o.id === orderId);
}

/** Same as nx_getOrders(), but recomputes each order's live status first —
 *  use this anywhere orders are listed/summarized (admin dashboard, order
 *  history) so figures never look frozen at "pending". */
function nx_getLiveOrders() {
  const orders = nx_getOrders();
  orders.forEach(o => nx_computeLiveStatus(o));
  return nx_getOrders(); // re-read: nx_computeLiveStatus persists any changes
}

function nx_updateOrderStatus(orderId, status) {
  const orders = nx_getOrders();
  const order = orders.find(o => o.id === orderId);
  if (!order || !NX_ORDER_STATUSES.includes(status)) return false;
  order.status = status;
  order.statusOverride = true; // an explicit (e.g. admin) status change stops auto-progression
  nx_saveOrders(orders);
  return true;
}

/**
 * Computes what an order's status SHOULD be right now based on elapsed
 * time, and persists it if it has moved forward — this is what makes
 * tracking feel "live" instead of frozen at "pending" forever. Orders
 * that were manually set (statusOverride) or are already in a terminal
 * state (delivered/cancelled) are left alone.
 */
function nx_computeLiveStatus(order) {
  if (!order || order.statusOverride) return order ? order.status : null;
  if (order.status === "delivered" || order.status === "cancelled") return order.status;

  const stages = ["pending", "confirmed", "processing", "shipped", "delivered"];
  const thresholds = [0, 0.06, 0.32, 0.62, 1]; // fraction of total journey at which each stage begins

  const createdMs = new Date(order.createdAt).getTime();
  const shippingDays = NX_SHIPPING_DAYS[order.shippingMethod] || NX_SHIPPING_DAYS.standard;
  const realDurationMs = shippingDays * 24 * 60 * 60 * 1000;
  const totalMs = (typeof NEXORA_CONFIG !== "undefined" && NEXORA_CONFIG.DEMO_FAST_TRACKING)
    ? 2 * 60 * 1000  // demo mode: full journey compressed into 2 minutes so it's visibly live
    : realDurationMs;

  const fraction = Math.min(1, Math.max(0, (Date.now() - createdMs) / totalMs));

  let stageIndex = 0;
  for (let i = 0; i < thresholds.length; i++) {
    if (fraction >= thresholds[i]) stageIndex = i;
  }
  const computedStatus = stages[stageIndex];

  if (computedStatus !== order.status) {
    const orders = nx_getOrders();
    const stored = orders.find(o => o.id === order.id);
    if (stored) {
      stored.status = computedStatus;
      nx_saveOrders(orders);
    }
    order.status = computedStatus;
  }
  return computedStatus;
}

/* ==========================================================================
   Checkout page wiring
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  if (document.querySelector("[data-checkout-page]")) nx_initCheckoutPage();
  if (document.querySelector("[data-confirmation-page]")) nx_renderConfirmationPage();
  if (document.querySelector("[data-orders-page]")) nx_renderOrdersPage();
  if (document.querySelector("[data-order-detail-page]")) nx_renderOrderDetailPage();
  if (document.querySelector("[data-profile-order-count]")) nx_renderProfileOrderCount();
});

function nx_renderProfileOrderCount() {
  const session = typeof nx_getSession === "function" ? nx_getSession() : null;
  const el = document.querySelector("[data-profile-order-count]");
  if (!session || !el) return;
  const orders = nx_getOrders().filter(o => o.userEmail === session.user.email);
  el.textContent = orders.length === 1 ? "1 order placed — view history" : `${orders.length} orders placed — view history`;
}

function nx_initCheckoutPage() {
  const { lines, subtotal, discount, shipping, tax, total } = nx_cartTotals(nx_activeCheckoutCoupon);
  const summaryBody = document.querySelector("[data-checkout-summary-items]");
  const emptyState = document.querySelector("[data-checkout-empty]");
  const formArea = document.querySelector("[data-checkout-form-area]");

  if (!lines.length) {
    if (emptyState) emptyState.style.display = "block";
    if (formArea) formArea.style.display = "none";
    return;
  }

  if (summaryBody) {
    summaryBody.innerHTML = lines.map(l => `
      <div class="cart-item-info" style="margin-bottom:16px;">
        <div class="thumb"><img src="${l.product.image}" alt="${l.product.name}"></div>
        <div style="flex:1;">
          <h4>${l.product.name}</h4>
          <span>Qty ${l.qty} · $${l.product.price.toLocaleString()}</span>
        </div>
        <strong>$${l.lineTotal.toLocaleString()}</strong>
      </div>
    `).join("");
  }

  nx_setText("[data-checkout-subtotal]", `$${subtotal.toFixed(2)}`);
  nx_setText("[data-checkout-discount]", discount ? `-$${discount.toFixed(2)}` : "$0.00");
  nx_setText("[data-checkout-shipping]", shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`);
  nx_setText("[data-checkout-tax]", `$${tax.toFixed(2)}`);
  nx_setText("[data-checkout-total]", `$${total.toFixed(2)}`);

  const couponInput = document.querySelector("[data-checkout-coupon-input]");
  if (couponInput && nx_activeCheckoutCoupon) couponInput.value = nx_activeCheckoutCoupon;
  const couponNote = document.querySelector("[data-checkout-coupon-note]");
  if (couponNote) couponNote.textContent = nx_activeCheckoutCoupon ? `Applied: ${nx_activeCheckoutCoupon}` : "";

  const couponForm = document.querySelector("[data-checkout-coupon-form]");
  if (couponForm) {
    couponForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const code = couponForm.querySelector("input").value.trim().toUpperCase();
      if (typeof NX_COUPONS !== "undefined" && NX_COUPONS[code]) {
        nx_activeCheckoutCoupon = code;
        nx_setActiveCoupon(code);
        nx_toast(`Coupon ${code} applied — ${NX_COUPONS[code] * 100}% off`);
      } else {
        nx_toast("Invalid coupon code", "error");
      }
      nx_initCheckoutPage();
    });
  }

  // Pre-fill from session if logged in
  const session = typeof nx_getSession === "function" ? nx_getSession() : null;
  if (session) {
    const nameInput = document.querySelector("#cf-name");
    const emailInput = document.querySelector("#cf-email");
    if (nameInput && !nameInput.value) nameInput.value = session.user.name;
    if (emailInput && !emailInput.value) emailInput.value = session.user.email;
  }

  nx_initUpiQr(total);

  // Step navigation
  document.querySelectorAll("[data-step-next]").forEach(btn => {
    btn.addEventListener("click", () => nx_goToCheckoutStep(Number(btn.dataset.stepNext)));
  });
  document.querySelectorAll("[data-step-back]").forEach(btn => {
    btn.addEventListener("click", () => nx_goToCheckoutStep(Number(btn.dataset.stepBack)));
  });

  const billingToggle = document.querySelector("#cf-billing-same");
  const billingFields = document.querySelector("[data-billing-fields]");
  if (billingToggle && billingFields) {
    billingToggle.addEventListener("change", () => {
      billingFields.style.display = billingToggle.checked ? "none" : "grid";
    });
  }

  nx_wireServiceabilityCheck();

  const form = document.querySelector("[data-checkout-form]");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      nx_submitCheckout(form);
    });
  }
}

/**
 * "Scan & Pay" UPI QR code. Shows/hides based on the selected payment
 * method, and regenerates the QR whenever the order total changes
 * (e.g. after a coupon is applied). The QR encodes a standard UPI deep
 * link (upi://pay?...) using the merchant details from js/config.js —
 * update NEXORA_CONFIG.UPI_ID there to your real VPA before going live.
 */
function nx_initUpiQr(total) {
  const panel = document.querySelector("[data-upi-qr-panel]");
  const img = document.querySelector("[data-upi-qr-img]");
  const idLabel = document.querySelector("[data-upi-id]");
  const amountLabel = document.querySelector("[data-upi-amount]");
  const copyBtn = document.querySelector("[data-copy-upi]");
  const radios = document.querySelectorAll('input[name="payment-method"]');
  if (!panel || !radios.length) return;

  const upiId = (typeof NEXORA_CONFIG !== "undefined" && NEXORA_CONFIG.UPI_ID) || "nexora@upi";
  const payeeName = (typeof NEXORA_CONFIG !== "undefined" && NEXORA_CONFIG.UPI_PAYEE_NAME) || "NEXORA Electronics";
  const amount = Number(total || 0).toFixed(2);

  if (idLabel) idLabel.textContent = upiId;
  if (amountLabel) amountLabel.textContent = `₹${amount}`;

  const upiLink = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=${encodeURIComponent("Order payment")}`;
  if (img) {
    img.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&margin=0&data=${encodeURIComponent(upiLink)}`;
  }

  const syncPanelVisibility = () => {
    const selected = document.querySelector('input[name="payment-method"]:checked');
    panel.style.display = selected && selected.value === "upi" ? "block" : "none";
  };
  radios.forEach(r => {
    if (!r.dataset.upiListenerAttached) {
      r.addEventListener("change", syncPanelVisibility);
      r.dataset.upiListenerAttached = "1";
    }
  });
  syncPanelVisibility();

  if (copyBtn && !copyBtn.dataset.upiListenerAttached) {
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(upiId).then(() => {
        nx_toast("UPI ID copied");
      }).catch(() => {
        nx_toast("Couldn't copy — please select and copy it manually", "error");
      });
    });
    copyBtn.dataset.upiListenerAttached = "1";
  }
}

let nx_activeCheckoutCoupon = (typeof nx_getActiveCoupon === "function") ? nx_getActiveCoupon() : "";

function nx_setText(selector, value) {
  document.querySelectorAll(selector).forEach(el => { el.textContent = value; });
}

/** Real pincode serviceability check (Shiprocket) — only active when the
 *  backend is connected and configured; otherwise the note simply stays
 *  hidden rather than showing a fake "delivery available" message. */
function nx_wireServiceabilityCheck() {
  const zipInput = document.querySelector("#cf-zip");
  const note = document.querySelector("[data-serviceability-note]");
  if (!zipInput || !note || zipInput.dataset.wired) return;
  zipInput.dataset.wired = "1";

  let debounceId = null;
  zipInput.addEventListener("input", () => {
    clearTimeout(debounceId);
    const pincode = zipInput.value.trim();
    if (!nx_isBackendConnected() || pincode.length < 5) { note.style.display = "none"; return; }

    debounceId = setTimeout(async () => {
      try {
        const res = await fetch(nx_apiUrl("/api/shipping/serviceability"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pincode }),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.success) { note.style.display = "none"; return; }

        note.style.display = "block";
        if (data.data.serviceable) {
          note.innerHTML = `<i class="fa-solid fa-circle-check" style="color:var(--success);"></i> Delivery available — arrives in ~${data.data.estimated_days} day(s)`;
        } else {
          note.innerHTML = `<i class="fa-solid fa-circle-exclamation" style="color:var(--danger);"></i> No courier currently serves this pincode`;
        }
      } catch {
        note.style.display = "none";
      }
    }, 500);
  });
}

function nx_goToCheckoutStep(step) {
  document.querySelectorAll("[data-checkout-step]").forEach(panel => {
    panel.classList.toggle("active", Number(panel.dataset.checkoutStep) === step);
  });
  document.querySelectorAll("[data-step-indicator]").forEach(ind => {
    const n = Number(ind.dataset.stepIndicator);
    ind.classList.toggle("done", n < step);
    ind.classList.toggle("current", n === step);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function nx_submitCheckout(form) {
  const requiredIds = ["cf-name", "cf-email", "cf-phone", "cf-address", "cf-city", "cf-state", "cf-zip"];
  let valid = true;
  requiredIds.forEach(id => {
    const input = form.querySelector("#" + id);
    if (!input) return;
    const group = input.closest(".form-group");
    const err = group ? group.querySelector(".field-error") : null;
    if (!input.value.trim()) {
      valid = false;
      if (err) { err.textContent = "This field is required."; err.style.display = "block"; }
      input.style.borderColor = "var(--danger)";
    } else {
      if (err) err.style.display = "none";
      input.style.borderColor = "";
    }
  });

  const emailInput = form.querySelector("#cf-email");
  if (emailInput && emailInput.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value)) {
    valid = false;
    nx_toast("Enter a valid email address.", "error");
  }

  if (!valid) {
    nx_toast("Please fill in all required fields.", "error");
    nx_goToCheckoutStep(1);
    return;
  }

  const submitBtn = form.querySelector("[data-place-order]");
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Processing payment…`;
  }

  const shippingMethod = form.querySelector('input[name="shipping-method"]:checked');
  const paymentMethod = form.querySelector('input[name="payment-method"]:checked');
  const billingSame = form.querySelector("#cf-billing-same")?.checked ?? true;

  const details = {
    name: form.querySelector("#cf-name").value.trim(),
    email: form.querySelector("#cf-email").value.trim(),
    phone: form.querySelector("#cf-phone").value.trim(),
    shippingAddress: {
      line1: form.querySelector("#cf-address").value.trim(),
      city: form.querySelector("#cf-city").value.trim(),
      state: form.querySelector("#cf-state").value.trim(),
      zip: form.querySelector("#cf-zip").value.trim(),
    },
    billingSameAsShipping: billingSame,
    billingAddress: billingSame ? null : {
      line1: form.querySelector("#cf-b-address")?.value.trim() || "",
      city: form.querySelector("#cf-b-city")?.value.trim() || "",
      state: form.querySelector("#cf-b-state")?.value.trim() || "",
      zip: form.querySelector("#cf-b-zip")?.value.trim() || "",
    },
    shippingMethod: shippingMethod ? shippingMethod.value : "standard",
    paymentMethod: paymentMethod ? paymentMethod.value : "card",
    coupon: nx_activeCheckoutCoupon
  };

  const resetBtn = () => { if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = '<i class="fa-solid fa-lock"></i> Place Order'; } };

  // Cash on delivery, or no payment gateway configured yet: skip straight to
  // order creation (same as the old mock-payment flow).
  if (details.paymentMethod === "cod" || !nx_isBackendConnected()) {
    await new Promise(r => setTimeout(r, 900)); // brief "processing" pause, matches the paid-flow feel
    const order = await nx_placeOrder(details);
    if (!order) { nx_toast("Something went wrong placing your order.", "error"); resetBtn(); return; }
    window.location.href = `order-confirmation.html?order=${order.id}`;
    return;
  }

  // Card / UPI with a real backend configured: run an actual Razorpay
  // payment before the order is created.
  nx_payWithRazorpay(details, resetBtn);
}

/* ==========================================================================
   Razorpay payment (real gateway — Phase 9 "real purchase" flow)

   Flow: ask our own backend to open a Razorpay order (amount kept
   server-side so it can't be tampered with in the browser) -> show the
   Razorpay checkout popup -> verify the signature with our backend ->
   only then create the NEXORA order.

   Needs: NEXORA_CONFIG.API_BASE_URL set (js/config.js), the backend
   running with RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET in .env, and the
   Razorpay checkout script tag already on the page (see checkout.html).
   ========================================================================== */

async function nx_payWithRazorpay(details, resetBtn) {
  const { total } = nx_cartTotals(details.coupon || "");

  if (typeof Razorpay === "undefined") {
    nx_toast("Payment library failed to load — check your connection.", "error");
    resetBtn();
    return;
  }

  try {
    // 1. Ask our backend to create a Razorpay order (amount decided server-side).
    const orderRes = await fetch(nx_apiUrl("/api/payments/create-order"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount: total, currency: "INR" }),
    });
    const orderData = await orderRes.json();
    if (!orderRes.ok || !orderData.success) {
      throw new Error(orderData.error || "Could not start payment.");
    }

    // 2. Open the Razorpay checkout popup.
    const rzp = new Razorpay({
      key: NEXORA_CONFIG.RAZORPAY_KEY_ID,
      amount: orderData.data.amount,
      currency: orderData.data.currency,
      order_id: orderData.data.order_id,
      name: NEXORA_CONFIG.COMPANY_NAME,
      description: "Order payment",
      prefill: { name: details.name, email: details.email, contact: details.phone },
      theme: { color: "#00e6c3" },
      handler: async function (response) {
        try {
          // 3. Verify the payment signature server-side before trusting it.
          const verifyRes = await fetch(nx_apiUrl("/api/payments/verify"), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            }),
          });
          const verifyData = await verifyRes.json();
          if (!verifyRes.ok || !verifyData.success) throw new Error("Payment verification failed.");

          // 4. Only now create the order.
          const order = await nx_placeOrder({ ...details, paymentReference: response.razorpay_payment_id });
          if (!order) throw new Error("Payment succeeded but the order could not be saved.");
          window.location.href = `order-confirmation.html?order=${order.id}`;
        } catch (err) {
          nx_toast(err.message || "Payment could not be confirmed.", "error");
          resetBtn();
        }
      },
      modal: { ondismiss: () => resetBtn() },
    });
    rzp.on("payment.failed", () => { nx_toast("Payment failed — please try again.", "error"); resetBtn(); });
    rzp.open();
  } catch (err) {
    nx_toast(err.message || "Could not start payment.", "error");
    resetBtn();
  }
}

/* ==========================================================================
   Confirmation page
   ========================================================================== */

function nx_renderConfirmationPage() {
  const params = new URLSearchParams(window.location.search);
  const orderId = params.get("order") || localStorage.getItem("nexora_last_order");
  const order = orderId ? nx_getOrder(orderId) : null;

  const root = document.querySelector("[data-confirmation-page]");
  if (!order) {
    root.innerHTML = `
      <div class="empty-state">
        <i class="fa-solid fa-circle-question"></i>
        <h3>Order not found</h3>
        <p>We couldn't find that order on this device.</p>
        <a href="index.html" class="btn btn-primary">Back to Home</a>
      </div>`;
    return;
  }

  nx_setText("[data-conf-order-id]", order.id);
  nx_setText("[data-conf-email]", order.customer.email);
  nx_setText("[data-conf-total]", `$${order.total.toFixed(2)}`);
  nx_setText("[data-conf-date]", new Date(order.createdAt).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }));
  if (order.estimatedDelivery) {
    nx_setText("[data-conf-eta]", new Date(order.estimatedDelivery).toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" }));
  }

  const itemsBody = document.querySelector("[data-conf-items]");
  if (itemsBody) {
    itemsBody.innerHTML = order.items.map(i => `
      <div class="cart-item-info" style="margin-bottom:14px;">
        <div class="thumb"><img src="${i.image}" alt="${i.name}"></div>
        <div style="flex:1;"><h4>${i.name}</h4><span>Qty ${i.qty}</span></div>
        <strong>$${i.lineTotal.toLocaleString()}</strong>
      </div>
    `).join("");
  }
}

/* ==========================================================================
   Order history page
   ========================================================================== */

function nx_renderOrdersPage() {
  const session = typeof nx_getSession === "function" ? nx_getSession() : null;
  if (!session) { window.location.href = "login.html"; return; }

  const orders = nx_getOrders().filter(o => o.userEmail === session.user.email);
  const list = document.querySelector("[data-orders-list]");
  const empty = document.querySelector("[data-orders-empty]");

  if (!orders.length) {
    if (empty) empty.style.display = "block";
    if (list) list.style.display = "none";
    return;
  }
  if (empty) empty.style.display = "none";
  if (list) list.style.display = "block";

  list.innerHTML = orders.map(o => {
    const liveStatus = nx_computeLiveStatus(o);
    return `
    <a href="order-detail.html?order=${o.id}" class="order-row">
      <div class="order-row-main">
        <strong>${o.id}</strong>
        <span>${new Date(o.createdAt).toLocaleDateString()}</span>
      </div>
      <span class="order-status-pill status-${liveStatus}">${liveStatus}</span>
      <span class="order-row-total">$${o.total.toFixed(2)}</span>
      <i class="fa-solid fa-chevron-right"></i>
    </a>
  `;
  }).join("");
}

let nx_orderDetailPollId = null;

function nx_renderOrderDetailPage() {
  const params = new URLSearchParams(window.location.search);
  const order = nx_getOrder(params.get("order"));
  const root = document.querySelector("[data-order-detail-page]");
  if (!order) {
    if (nx_orderDetailPollId) clearInterval(nx_orderDetailPollId);
    root.innerHTML = `<div class="empty-state"><i class="fa-solid fa-circle-question"></i><h3>Order not found</h3><a href="orders.html" class="btn btn-primary">Back to Orders</a></div>`;
    return;
  }

  nx_paintOrderDetail(order);
  nx_wireInvoiceButton(order.id);
  nx_checkRealTracking(order);

  // Live tracking: re-check the order's computed status every few seconds
  // so the tracker visibly advances without the person refreshing the
  // page — this is what makes "order tracking" feel real rather than a
  // static screenshot. Harmless once the order reaches a terminal state
  // (nx_computeLiveStatus simply stops changing it).
  if (nx_orderDetailPollId) clearInterval(nx_orderDetailPollId);
  nx_orderDetailPollId = setInterval(() => {
    const fresh = nx_getOrder(order.id);
    if (!fresh) { clearInterval(nx_orderDetailPollId); return; }
    nx_paintOrderDetail(fresh);
    if (fresh.status === "delivered" || fresh.status === "cancelled") clearInterval(nx_orderDetailPollId);
  }, 4000);
}

function nx_paintOrderDetail(order) {
  const liveStatus = nx_computeLiveStatus(order);

  nx_setText("[data-od-id]", order.id);
  nx_setText("[data-od-date]", new Date(order.createdAt).toLocaleDateString());
  if (order.estimatedDelivery) {
    const label = liveStatus === "delivered" ? "Delivered" : "Estimated delivery";
    nx_setText("[data-od-eta-label]", label);
    nx_setText("[data-od-eta]", new Date(order.estimatedDelivery).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }));
  }

  const statusEl = document.querySelector("[data-od-status]");
  if (statusEl) {
    statusEl.className = "order-status-pill status-" + liveStatus;
    statusEl.textContent = liveStatus;
  }

  nx_setText("[data-od-address]", `${order.shippingAddress.line1}, ${order.shippingAddress.city}, ${order.shippingAddress.state} ${order.shippingAddress.zip}`);
  nx_setText("[data-od-payment]", order.paymentMethod === "cod" ? "Cash on delivery" : order.paymentMethod);
  nx_setText("[data-od-subtotal]", `$${order.subtotal.toFixed(2)}`);
  nx_setText("[data-od-shipping]", order.shipping === 0 ? "Free" : `$${order.shipping.toFixed(2)}`);
  nx_setText("[data-od-tax]", `$${order.tax.toFixed(2)}`);
  nx_setText("[data-od-total]", `$${order.total.toFixed(2)}`);

  const track = document.querySelector("[data-od-tracker]");
  if (track) {
    const stages = ["pending", "confirmed", "processing", "shipped", "delivered"];
    const idx = order.status === "cancelled" ? -1 : stages.indexOf(liveStatus);
    track.innerHTML = stages.map((s, i) => `
      <div class="track-stage ${i <= idx ? "done" : ""}">
        <span class="dot"></span><label>${s}</label>
      </div>
    `).join("");
  }

  const itemsBody = document.querySelector("[data-od-items]");
  if (itemsBody) {
    itemsBody.innerHTML = order.items.map(i => `
      <div class="cart-item-info" style="margin-bottom:14px;">
        <div class="thumb"><img src="${i.image}" alt="${i.name}"></div>
        <div style="flex:1;"><h4>${i.name}</h4><span>Qty ${i.qty} · $${i.price}</span></div>
        <strong>$${i.lineTotal.toLocaleString()}</strong>
      </div>
    `).join("");
  }
}

function nx_wireInvoiceButton(orderId) {
  const btn = document.querySelector("[data-download-invoice]");
  if (!btn || btn.dataset.wired) return;
  btn.dataset.wired = "1";
  btn.addEventListener("click", () => nx_printInvoice(orderId));
}

/* ==========================================================================
   Real courier tracking (Shiprocket) — only fires when the backend is
   connected and this order has a real backend id. Shows nothing false: if
   the admin hasn't booked a courier yet, it says so plainly rather than
   inventing a tracking number.
   ========================================================================== */

async function nx_checkRealTracking(order) {
  const box = document.querySelector("[data-real-tracking]");
  if (!box) return;

  if (!nx_isBackendConnected() || !order.backendOrderId) {
    box.style.display = "none";
    return;
  }

  const session = typeof nx_getSession === "function" ? nx_getSession() : null;
  if (!session || !session.token) { box.style.display = "none"; return; }

  try {
    const res = await fetch(nx_apiUrl(`/api/shipping/track/${order.backendOrderId}`), {
      headers: { "Authorization": `Bearer ${session.token}` },
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success) { box.style.display = "none"; return; }

    box.style.display = "block";
    if (!data.data.tracked) {
      box.innerHTML = `<i class="fa-solid fa-box"></i> Not yet handed to a courier — the seller will book a real pickup shortly.`;
    } else {
      const d = data.data;
      box.innerHTML = `
        <i class="fa-solid fa-truck-fast"></i>
        Shipped via <strong>${d.courier_name || "courier partner"}</strong> —
        AWB <strong>${d.awb_code}</strong>
        ${d.tracking_url ? `· <a href="${d.tracking_url}" target="_blank" rel="noopener">Track on courier site</a>` : ""}`;
    }
  } catch {
    box.style.display = "none";
  }
}

/* ==========================================================================
   Invoice — a real, itemized, printable/PDF-savable document per order.
   Opens a clean print window; the person can "Save as PDF" from the
   browser's print dialog (Ctrl/Cmd+P also works from that window).
   ========================================================================== */

function nx_printInvoice(orderId) {
  const order = nx_getOrder(orderId);
  if (!order) { nx_toast("Order not found.", "error"); return; }

  const company = (typeof NEXORA_CONFIG !== "undefined" && NEXORA_CONFIG.COMPANY_NAME) || "NEXORA Electronics";
  const supportEmail = (typeof NEXORA_CONFIG !== "undefined" && NEXORA_CONFIG.SUPPORT_EMAIL) || "support@nexora.example";

  const rows = order.items.map(i => `
    <tr>
      <td>${i.name}</td>
      <td style="text-align:center;">${i.qty}</td>
      <td style="text-align:right;">$${i.price.toFixed(2)}</td>
      <td style="text-align:right;">$${i.lineTotal.toFixed(2)}</td>
    </tr>
  `).join("");

  const html = `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Invoice ${order.id} — ${company}</title>
<style>
  body { font-family: 'Segoe UI', Arial, sans-serif; color:#1a1a1a; max-width:760px; margin:40px auto; padding:0 20px; }
  .inv-head { display:flex; justify-content:space-between; align-items:flex-start; border-bottom:3px solid #00b89c; padding-bottom:20px; margin-bottom:30px; }
  .inv-head h1 { margin:0; font-size:22px; }
  .inv-head p { margin:4px 0 0; color:#555; font-size:13px; }
  .inv-meta { text-align:right; font-size:13px; color:#333; }
  .inv-meta strong { font-size:15px; }
  .addr-grid { display:flex; gap:40px; margin-bottom:30px; }
  .addr-grid div { flex:1; }
  .addr-grid h4 { margin:0 0 8px; font-size:12px; text-transform:uppercase; letter-spacing:.05em; color:#888; }
  .addr-grid p { margin:0; font-size:13px; line-height:1.6; }
  table { width:100%; border-collapse:collapse; margin-bottom:24px; }
  th { text-align:left; font-size:11px; text-transform:uppercase; letter-spacing:.04em; color:#888; border-bottom:2px solid #eee; padding:8px 6px; }
  td { padding:10px 6px; border-bottom:1px solid #eee; font-size:13px; }
  .totals { margin-left:auto; width:280px; }
  .totals div { display:flex; justify-content:space-between; padding:6px 0; font-size:13px; }
  .totals .grand { border-top:2px solid #1a1a1a; margin-top:8px; padding-top:10px; font-size:16px; font-weight:700; }
  .foot { margin-top:40px; padding-top:16px; border-top:1px solid #eee; font-size:11px; color:#999; text-align:center; }
  @media print { body { margin:0; padding:20px; } }
</style>
</head>
<body>
  <div class="inv-head">
    <div>
      <h1>${company}</h1>
      <p>Invoice · Order ${order.id}</p>
      <p>${supportEmail}</p>
    </div>
    <div class="inv-meta">
      <strong>INVOICE</strong><br>
      Order ID: ${order.id}<br>
      Date: ${new Date(order.createdAt).toLocaleDateString()}<br>
      Payment: ${order.paymentMethod === "cod" ? "Cash on delivery" : order.paymentMethod.toUpperCase()}${order.paymentReference ? " · Ref " + order.paymentReference : ""}
    </div>
  </div>

  <div class="addr-grid">
    <div>
      <h4>Billed to</h4>
      <p>${order.customer.name}<br>${order.customer.email}<br>${order.customer.phone || ""}</p>
    </div>
    <div>
      <h4>Shipping address</h4>
      <p>${order.shippingAddress.line1}<br>${order.shippingAddress.city}, ${order.shippingAddress.state} ${order.shippingAddress.zip}</p>
    </div>
  </div>

  <table>
    <thead><tr><th>Item</th><th style="text-align:center;">Qty</th><th style="text-align:right;">Price</th><th style="text-align:right;">Total</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>

  <div class="totals">
    <div><span>Subtotal</span><span>$${order.subtotal.toFixed(2)}</span></div>
    <div><span>Discount</span><span>-$${order.discount.toFixed(2)}</span></div>
    <div><span>Shipping</span><span>${order.shipping === 0 ? "Free" : "$" + order.shipping.toFixed(2)}</span></div>
    <div><span>Tax</span><span>$${order.tax.toFixed(2)}</span></div>
    <div class="grand"><span>Total</span><span>$${order.total.toFixed(2)}</span></div>
  </div>

  <div class="foot">
    © ${new Date().getFullYear()} ${company}. All Rights Reserved. This is a computer-generated invoice for order ${order.id}.
  </div>

  <script>window.onload = () => window.print();</script>
</body>
</html>`;

  const win = window.open("", "_blank");
  if (!win) { nx_toast("Please allow pop-ups to download the invoice.", "error"); return; }
  win.document.write(html);
  win.document.close();
}
