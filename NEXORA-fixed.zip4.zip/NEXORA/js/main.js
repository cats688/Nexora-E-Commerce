/* ==========================================================================
   NEXORA — main.js
   Shared behavior across every page: header state, mobile drawer,
   scroll reveal, toast notifications, back-to-top.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  document.body.classList.add("page-ready");
  nx_initHeaderScroll();
  nx_initMobileDrawer();
  nx_initRevealOnScroll();
  nx_initBackToTop();
  nx_syncBadgeCounts();
  nx_highlightActiveNav();
  nx_setCopyrightYear();
  nx_applySupportContact();
  nx_initFlipCountdown();
  nx_initHeroTilt();
});

/**
 * Hero 3D parallax — the whole scene (glow, particles, orbit rings,
 * device card, chips) tilts as one rigid body toward the cursor, with
 * each layer's translateZ (set inline via --z) producing real depth
 * parallax rather than a flat fake-3D trick. A soft light also tracks
 * the pointer via --mx/--my (see .hero-visual::before in style.css).
 * Eases back flat on mouse-leave; skipped for touch/reduced-motion.
 */
function nx_initHeroTilt() {
  const stage = document.querySelector("[data-tilt-stage]");
  const scene = document.querySelector("[data-tilt-scene]");
  if (!stage || !scene) return;
  if (window.matchMedia("(hover: none)").matches) return;
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

  const MAX_TILT = 10; // degrees

  stage.addEventListener("mousemove", (e) => {
    const rect = stage.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const py = (e.clientY - rect.top) / rect.height;
    const ry = (px - 0.5) * 2 * MAX_TILT;
    const rx = (0.5 - py) * 2 * MAX_TILT;
    stage.classList.add("is-active");
    scene.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`;
    stage.style.setProperty("--mx", `${px * 100}%`);
    stage.style.setProperty("--my", `${py * 100}%`);
  });

  stage.addEventListener("mouseleave", () => {
    stage.classList.remove("is-active");
    scene.style.transform = "rotateX(0deg) rotateY(0deg)";
  });
}

/* Single source of truth for the customer-care phone number: every
   element tagged data-support-phone gets its href/text synced from
   NEXORA_CONFIG.SUPPORT_PHONE_TEL / SUPPORT_PHONE_DISPLAY here, so
   changing the number in js/config.js updates it everywhere at once. */
function nx_applySupportContact() {
  if (typeof NEXORA_CONFIG === "undefined") return;
  const tel = NEXORA_CONFIG.SUPPORT_PHONE_TEL;
  const display = NEXORA_CONFIG.SUPPORT_PHONE_DISPLAY;
  if (!tel || !display) return;
  document.querySelectorAll("[data-support-phone]").forEach(a => {
    a.setAttribute("href", "tel:" + tel);
    a.textContent = display;
  });
}

/* Keeps the footer's © year correct without editing every HTML file each January */
function nx_setCopyrightYear() {
  document.querySelectorAll("[data-copyright-year]").forEach(el => {
    el.textContent = new Date().getFullYear();
  });
}

/**
 * Real, ticking countdown for the homepage promo banner, rendered as a
 * 3D flip-clock (each digit pair rotates on its own axis when it
 * changes — pure CSS transforms, no image/video assets). The end time
 * persists in localStorage so it survives a page refresh instead of
 * jumping back to 18:42:09; once it hits zero the sale window quietly
 * restarts so the banner always reads as "live" for demo purposes.
 */
function nx_initFlipCountdown() {
  const timer = document.querySelector("[data-flip-timer]");
  if (!timer) return;

  const DURATION_MS = (18 * 3600 + 42 * 60 + 9) * 1000;
  const STORAGE_KEY = "nx_sale_end_at";

  let endAt = Number(localStorage.getItem(STORAGE_KEY));
  if (!endAt || endAt < Date.now()) {
    endAt = Date.now() + DURATION_MS;
    localStorage.setItem(STORAGE_KEY, String(endAt));
  }

  const cards = {
    h: timer.querySelector('[data-flip-card="h"]'),
    m: timer.querySelector('[data-flip-card="m"]'),
    s: timer.querySelector('[data-flip-card="s"]'),
  };

  function flipTo(card, value) {
    if (!card) return;
    const text = String(value).padStart(2, "0");
    const front = card.querySelector("[data-flip-front]");
    const back = card.querySelector("[data-flip-back]");
    if (front.textContent === text) return;
    back.textContent = text;
    card.classList.add("flipping");
    window.setTimeout(() => {
      front.textContent = text;
      card.classList.remove("flipping");
    }, 620);
  }

  function tick() {
    let remaining = endAt - Date.now();
    if (remaining <= 0) {
      endAt = Date.now() + DURATION_MS;
      localStorage.setItem(STORAGE_KEY, String(endAt));
      remaining = DURATION_MS;
    }
    const totalSeconds = Math.floor(remaining / 1000);
    flipTo(cards.h, Math.floor(totalSeconds / 3600));
    flipTo(cards.m, Math.floor((totalSeconds % 3600) / 60));
    flipTo(cards.s, totalSeconds % 60);
  }

  tick();
  window.setInterval(tick, 1000);
}

/* Header background intensifies on scroll */
function nx_initHeaderScroll() {
  const header = document.querySelector(".site-header");
  if (!header) return;
  const onScroll = () => {
    header.style.borderBottomColor = window.scrollY > 12 ? "var(--line)" : "var(--line-soft)";
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
}

/* Mobile nav drawer */
function nx_initMobileDrawer() {
  const burger = document.querySelector(".nav-burger");
  const drawer = document.querySelector(".mobile-drawer");
  if (!burger || !drawer) return;
  burger.addEventListener("click", () => drawer.classList.toggle("open"));
  drawer.querySelectorAll("a").forEach(a => a.addEventListener("click", () => drawer.classList.remove("open")));
  document.addEventListener("click", (e) => {
    if (!drawer.contains(e.target) && !burger.contains(e.target)) drawer.classList.remove("open");
  });
}

/* IntersectionObserver-based reveal animation, applied once per element */
function nx_initRevealOnScroll() {
  const items = document.querySelectorAll(".reveal");
  if (!items.length) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("in");
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  items.forEach(el => io.observe(el));
}

/* Back to top button */
function nx_initBackToTop() {
  const btn = document.querySelector(".back-to-top");
  if (!btn) return;
  window.addEventListener("scroll", () => {
    btn.classList.toggle("show", window.scrollY > 600);
  }, { passive: true });
  btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

/* Mark the current page's nav link as active */
function nx_highlightActiveNav() {
  const path = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a, .mobile-drawer a").forEach(a => {
    const href = a.getAttribute("href");
    if (href === path) a.classList.add("active");
  });
}

/* ==========================================================================
   Toast notifications
   ========================================================================== */

function nx_ensureToastStack() {
  let stack = document.querySelector(".toast-stack");
  if (!stack) {
    stack = document.createElement("div");
    stack.className = "toast-stack";
    document.body.appendChild(stack);
  }
  return stack;
}

function nx_toast(message, type = "success") {
  const stack = nx_ensureToastStack();
  const el = document.createElement("div");
  el.className = "toast" + (type === "error" ? " error" : "");
  const icon = type === "error" ? "fa-circle-exclamation" : "fa-circle-check";
  el.innerHTML = `<i class="fa-solid ${icon}"></i><span>${message}</span>`;
  stack.appendChild(el);
  setTimeout(() => {
    el.style.transition = "opacity .25s ease, transform .25s ease";
    el.style.opacity = "0";
    el.style.transform = "translateX(20px)";
    setTimeout(() => el.remove(), 260);
  }, 2600);
}

/* ==========================================================================
   Header cart / wishlist badge counts (reads from localStorage, see cart.js)
   ========================================================================== */

function nx_syncBadgeCounts() {
  const cart = nx_getCart();
  const wishlist = nx_getWishlist();
  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0);
  document.querySelectorAll("[data-cart-count]").forEach(el => {
    el.textContent = cartCount;
    el.style.display = cartCount > 0 ? "grid" : "none";
  });
  document.querySelectorAll("[data-wishlist-count]").forEach(el => {
    el.textContent = wishlist.length;
    el.style.display = wishlist.length > 0 ? "grid" : "none";
  });
}

/* Simple newsletter form handler shared across pages */
document.addEventListener("submit", (e) => {
  if (e.target.matches(".newsletter-form")) {
    e.preventDefault();
    const input = e.target.querySelector("input");
    if (input.value.trim()) {
      nx_toast("Subscribed! Check your inbox for a confirmation.");
      e.target.reset();
    }
  }
  if (e.target.matches(".contact-form")) {
    e.preventDefault();
    const form = e.target;
    const name = form.querySelector("#cname")?.value.trim() || "";
    const email = form.querySelector("#cemail")?.value.trim() || "";
    const subject = form.querySelector("#csubject")?.value.trim() || "Contact form message";
    const message = form.querySelector("#cmessage")?.value.trim() || "";

    if (nx_isBackendConnected()) {
      // Real backend configured — send it as an actual API call.
      fetch(nx_apiUrl("/api/contact"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, subject, message }),
      })
        .then(res => { if (!res.ok) throw new Error(); })
        .then(() => { nx_toast("Message sent — our team will reply within 24 hours."); form.reset(); })
        .catch(() => nx_toast("Couldn't send right now — please call our helpline instead.", "error"));
      return;
    }

    // No backend yet (demo mode): open the visitor's own email app with
    // the complaint pre-filled, addressed to the real support inbox, so
    // it actually gets sent — no server needed.
    const to = (typeof NEXORA_CONFIG !== "undefined" && NEXORA_CONFIG.SUPPORT_EMAIL) || "support@nexora.example";
    const body = `Name: ${name}\nEmail: ${email}\n\n${message}`;
    const mailto = `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    nx_toast("Opening your email app to send this to our support team…");
    window.location.href = mailto;
    form.reset();
  }
});
