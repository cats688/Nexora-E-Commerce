/* ==========================================================================
   NEXORA — Demo product catalog
   Structured to mirror the future MySQL `products` table so it can be
   swapped for a fetch('/api/products') response in Phase 8 with no
   changes to the rendering code.
   ========================================================================== */

const NEXORA_PRODUCTS = [
  {
    id: 1, name: "Nexora Pulse Pro", brand: "Nexora", category: "smartphones",
    price: 899, oldPrice: 999, rating: 4.8, reviews: 214, stock: 18,
    image: "https://images.unsplash.com/photo-1592286927505-1def25115558?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1592286927505-1def25115558?q=80&w=800&auto=format&fit=crop","https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#00e6c3", "#ff5d3b"],
    desc: "Flagship smartphone with a 120Hz LTPO display, titanium frame and an AI-tuned triple camera system built for low light.",
    specs: { Display: "6.7\" LTPO AMOLED, 120Hz", Chip: "Nexora X3 Octa-core", RAM: "12GB", Storage: "256GB", Battery: "5000mAh, 65W", Camera: "50MP + 12MP + 12MP" }
  },
  {
    id: 2, name: "Nexora Air Slim 14", brand: "Nexora", category: "laptops",
    price: 1299, oldPrice: 1499, rating: 4.7, reviews: 168, stock: 9,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#a9b0c2"],
    desc: "A 1.1kg ultraportable laptop with a 14-inch 2.8K display, all-day battery and a fanless silent chassis.",
    specs: { Display: "14\" 2.8K OLED", Chip: "Nexora N2 12-core", RAM: "16GB", Storage: "512GB SSD", Battery: "18 hrs", Weight: "1.1kg" }
  },
  {
    id: 3, name: "Nexora Tab X", brand: "Nexora", category: "tablets",
    price: 549, oldPrice: null, rating: 4.5, reviews: 92, stock: 24,
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d", "#00e6c3"],
    desc: "An 11-inch tablet with stylus support, ideal for sketching, notes and media on the go.",
    specs: { Display: "11\" LCD, 90Hz", Chip: "Nexora T1", RAM: "8GB", Storage: "128GB", Battery: "8000mAh", Stylus: "Included" }
  },
  {
    id: 4, name: "Nexora Watch Fit", brand: "Nexora", category: "smartwatches",
    price: 229, oldPrice: 279, rating: 4.6, reviews: 301, stock: 40,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#ff5d3b", "#a9b0c2"],
    desc: "A lightweight AMOLED smartwatch with 14-day battery life, SpO2 tracking and 100+ sport modes.",
    specs: { Display: "1.43\" AMOLED", Battery: "14 days", "Water rating": "5ATM", Sensors: "HR, SpO2, GPS" }
  },
  {
    id: 5, name: "Nexora Buds Air", brand: "Nexora", category: "earbuds",
    price: 129, oldPrice: 159, rating: 4.4, reviews: 512, stock: 60,
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1590658268037-6bf12165a8df?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#f2f4f8"],
    desc: "True wireless earbuds with adaptive ANC, spatial audio and a 32-hour case battery.",
    specs: { Driver: "11mm dynamic", ANC: "Adaptive, -42dB", Battery: "8h + 24h case", Codec: "LDAC, AAC" }
  },
  {
    id: 6, name: "Nexora Studio Headphones", brand: "Nexora", category: "headphones",
    price: 249, oldPrice: null, rating: 4.7, reviews: 143, stock: 15,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "Over-ear studio headphones tuned for balanced monitoring with 40-hour battery life.",
    specs: { Driver: "45mm", Battery: "40 hrs", Weight: "260g", ANC: "Hybrid" }
  },
  {
    id: 7, name: "Nexora Lens Z1", brand: "Nexora", category: "cameras",
    price: 1099, oldPrice: 1199, rating: 4.9, reviews: 76, stock: 6,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d"],
    desc: "Mirrorless camera with a 32MP APS-C sensor, in-body stabilization and 4K/60 video.",
    specs: { Sensor: "32MP APS-C", ISO: "100–51200", Video: "4K60", Stabilization: "5-axis IBIS" }
  },
  {
    id: 8, name: "Nexora Play Controller", brand: "Nexora", category: "gaming",
    price: 79, oldPrice: 99, rating: 4.5, reviews: 220, stock: 55,
    image: "https://images.unsplash.com/photo-1592840062661-eb5f8636022a?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1592840062661-eb5f8636022a?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#00e6c3"],
    desc: "A wireless gaming controller with Hall-effect sticks, low-latency 2.4GHz link and 30h battery.",
    specs: { Connection: "2.4GHz + BT 5.3", Battery: "30 hrs", Sticks: "Hall-effect" }
  },
  {
    id: 9, name: "Nexora Hub Charge Dock", brand: "Nexora", category: "accessories",
    price: 59, oldPrice: null, rating: 4.3, reviews: 88, stock: 70,
    image: "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1583863788434-e58a36330cf0?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "A 3-in-1 charging dock for phone, watch and earbuds with 18W fast charging.",
    specs: { Output: "18W USB-C PD", Ports: "3-in-1", Cable: "1.2m braided" }
  },
  {
    id: 10, name: "Nexora Home Hub", brand: "Nexora", category: "smart-home",
    price: 149, oldPrice: 179, rating: 4.4, reviews: 64, stock: 20,
    image: "https://images.unsplash.com/photo-1558002038-1055907df827?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1558002038-1055907df827?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#f2f4f8"],
    desc: "A smart display hub that centralizes lighting, security cameras and voice control.",
    specs: { Display: "7\" touch", Connectivity: "Wi-Fi 6, Zigbee", Voice: "Built-in assistant" }
  },
  {
    id: 11, name: "Nexora Pulse Lite", brand: "Nexora", category: "smartphones",
    price: 449, oldPrice: 499, rating: 4.2, reviews: 190, stock: 33,
    image: "https://images.unsplash.com/photo-1585060544812-6b45742d762f?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1585060544812-6b45742d762f?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#00e6c3"],
    desc: "A value flagship with a 120Hz display, 5000mAh battery and clean, near-stock software.",
    specs: { Display: "6.5\" AMOLED, 120Hz", Chip: "Nexora X1", RAM: "8GB", Storage: "128GB", Battery: "5000mAh" }
  },
  {
    id: 12, name: "Nexora Book Pro 16", brand: "Nexora", category: "laptops",
    price: 1899, oldPrice: null, rating: 4.8, reviews: 54, stock: 5,
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "A 16-inch performance laptop for creators, with a mini-LED display and discrete graphics.",
    specs: { Display: "16\" mini-LED, 120Hz", Chip: "Nexora N2 Pro 14-core", RAM: "32GB", Storage: "1TB SSD", GPU: "Nexora RTX-class" }
  },

  /* ===== Budget tier — Voltrix (value sub-brand sold on NEXORA marketplace) ===== */
  {
    id: 13, name: "Voltrix Buds Basic", brand: "Voltrix", category: "earbuds",
    price: 24.99, oldPrice: 34.99, rating: 4.0, reviews: 812, stock: 140,
    image: "https://images.unsplash.com/photo-1590658006821-98a1fa73a1d2?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1590658006821-98a1fa73a1d2?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#f2f4f8"],
    desc: "Reliable everyday earbuds with 20-hour combined battery life and a lightweight fit — the easy first-earbuds pick.",
    specs: { Driver: "8mm dynamic", Battery: "5h + 15h case", Water: "IPX4", Weight: "3.8g each" }
  },
  {
    id: 14, name: "Voltrix Watch Go", brand: "Voltrix", category: "smartwatches",
    price: 39.99, oldPrice: 54.99, rating: 4.1, reviews: 634, stock: 95,
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#ff5d3b"],
    desc: "A no-fuss fitness tracker with step counting, heart-rate alerts and a 10-day battery, priced for everyone.",
    specs: { Display: "1.1\" color LCD", Battery: "10 days", Water: "IP68", Sensors: "HR, step count" }
  },
  {
    id: 15, name: "Voltrix Power Bank 20K", brand: "Voltrix", category: "accessories",
    price: 19.99, oldPrice: 27.99, rating: 4.3, reviews: 1024, stock: 210,
    image: "https://images.unsplash.com/photo-1591290619762-c8f5f88dad30?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1591290619762-c8f5f88dad30?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d"],
    desc: "20,000mAh of backup power with dual USB-A and one USB-C output — enough for 3-4 full phone charges.",
    specs: { Capacity: "20,000mAh", Output: "18W max", Ports: "2x USB-A, 1x USB-C", Weight: "340g" }
  },
  {
    id: 16, name: "Voltrix Cam Mini", brand: "Voltrix", category: "cameras",
    price: 44.99, oldPrice: null, rating: 3.9, reviews: 288, stock: 60,
    image: "https://images.unsplash.com/photo-1516724562728-afc824a36e84?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1516724562728-afc824a36e84?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "A compact 1080p webcam with a built-in privacy shutter — an easy upgrade for calls and streaming on a budget.",
    specs: { Resolution: "1080p @ 30fps", FOV: "78°", Mic: "Built-in, noise-reduced", Mount: "Clip-on / tripod" }
  },
  {
    id: 17, name: "Nexora Tab Mini", brand: "Nexora", category: "tablets",
    price: 179, oldPrice: 219, rating: 4.2, reviews: 156, stock: 48,
    image: "https://images.unsplash.com/photo-1561154464-82e9adf32764?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1561154464-82e9adf32764?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#f2f4f8"],
    desc: "An 8-inch tablet built for reading, browsing and video — small enough to hold in one hand all day.",
    specs: { Display: "8\" LCD, 60Hz", Chip: "Nexora T0", RAM: "4GB", Storage: "64GB", Battery: "5000mAh" }
  },
  {
    id: 18, name: "Voltrix Smart Plug Duo", brand: "Voltrix", category: "smart-home",
    price: 16.99, oldPrice: 22.99, rating: 4.0, reviews: 401, stock: 150,
    image: "https://images.unsplash.com/photo-1558089687-f282ffcbc126?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1558089687-f282ffcbc126?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#f2f4f8"],
    desc: "A 2-pack of Wi-Fi smart plugs with app scheduling and voice control — the cheapest way to start a smart home.",
    specs: { Connectivity: "Wi-Fi 2.4GHz", "Max Load": "1800W", Voice: "Works with major assistants", Pack: "2 plugs" }
  },

  /* ===== Mid tier — Nexora core range + Pulseon (gaming sub-brand) ===== */
  {
    id: 19, name: "Pulseon Gaming Headset X", brand: "Pulseon", category: "headphones",
    price: 69.99, oldPrice: 89.99, rating: 4.4, reviews: 347, stock: 70,
    image: "https://images.unsplash.com/photo-1599669454699-248893623440?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1599669454699-248893623440?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#ff5d3b"],
    desc: "A gaming headset with 7.1 surround, a detachable noise-cancelling mic, and RGB accents that don't drain the battery.",
    specs: { Driver: "50mm", Surround: "7.1 virtual", Mic: "Detachable, cardioid", Compatibility: "PC, PS5, Xbox, Switch" }
  },
  {
    id: 20, name: "Nexora Buds Pro 2", brand: "Nexora", category: "earbuds",
    price: 179, oldPrice: 209, rating: 4.6, reviews: 268, stock: 44,
    image: "https://images.unsplash.com/photo-1608156639585-b3a032ef9689?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1608156639585-b3a032ef9689?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d", "#f2f4f8", "#ff5d3b"],
    desc: "The step up from Buds Air — stronger ANC, wireless charging case, and a richer, bass-forward tuning.",
    specs: { Driver: "12mm dynamic", ANC: "Adaptive, -38dB", Battery: "9h + 27h case", Charging: "Wireless + USB-C" }
  },
  {
    id: 21, name: "Pulseon Mechanical Keyboard", brand: "Pulseon", category: "accessories",
    price: 79.99, oldPrice: 99.99, rating: 4.5, reviews: 512, stock: 66,
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d"],
    desc: "Hot-swappable mechanical switches, per-key RGB, and a compact 75% layout that leaves room for your mouse.",
    specs: { Switches: "Hot-swap mechanical", Layout: "75%", Backlight: "Per-key RGB", Connection: "USB-C, wired" }
  },
  {
    id: 22, name: "Nexora Watch Active", brand: "Nexora", category: "smartwatches",
    price: 149, oldPrice: 179, rating: 4.5, reviews: 203, stock: 38,
    image: "https://images.unsplash.com/photo-1544117519-31a4b719223d?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1544117519-31a4b719223d?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#00e6c3"],
    desc: "Built-in GPS, 100+ sport modes and a bright always-on display for runners and gym regulars alike.",
    specs: { Display: "1.3\" AMOLED, always-on", Battery: "9 days", GPS: "Built-in, dual-band", Water: "5ATM" }
  },
  {
    id: 23, name: "Nexora Cam Action 4K", brand: "Nexora", category: "cameras",
    price: 219, oldPrice: 259, rating: 4.4, reviews: 122, stock: 27,
    image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1502920917128-1aa500764cbd?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "A rugged 4K action camera with electronic stabilization, waterproof to 10m without a case.",
    specs: { Video: "4K30 / 1080p120", Stabilization: "Electronic, 3-axis", Waterproof: "10m (no case)", Battery: "1350mAh" }
  },
  {
    id: 24, name: "Nexora Pulse Core", brand: "Nexora", category: "smartphones",
    price: 599, oldPrice: 649, rating: 4.5, reviews: 176, stock: 30,
    image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#a9b0c2", "#00e6c3"],
    desc: "The sweet spot in the Pulse lineup — flagship camera hardware and a 120Hz display at a mid-range price.",
    specs: { Display: "6.6\" AMOLED, 120Hz", Chip: "Nexora X2", RAM: "8GB", Storage: "256GB", Camera: "50MP + 8MP" }
  },
  {
    id: 25, name: "Pulseon Play Deck", brand: "Pulseon", category: "gaming",
    price: 329, oldPrice: 379, rating: 4.6, reviews: 98, stock: 16,
    image: "https://images.unsplash.com/photo-1600861194942-f883de0dfe96?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1600861194942-f883de0dfe96?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "A handheld gaming PC with a 7-inch 120Hz screen — full library access, no cloud streaming required.",
    specs: { Display: "7\" LCD, 120Hz", Chip: "Pulseon P1 8-core", RAM: "16GB", Storage: "512GB SSD", Battery: "40Wh" }
  },

  /* ===== Premium tier — flagship Nexora + Aurelia (premium audio/imaging sub-brand) ===== */
  {
    id: 26, name: "Aurelia Sound Max", brand: "Aurelia", category: "headphones",
    price: 399, oldPrice: 459, rating: 4.8, reviews: 87, stock: 12,
    image: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1546435770-a3e426bf472b?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d"],
    desc: "Reference-tuned over-ears with planar drivers and hand-finished earcups — built for critical listening.",
    specs: { Driver: "Planar magnetic, 90mm", Frequency: "5Hz–45kHz", Impedance: "35 ohm", Cable: "Detachable, braided" }
  },
  {
    id: 27, name: "Nexora Book Air 15", brand: "Nexora", category: "laptops",
    price: 1399, oldPrice: 1549, rating: 4.7, reviews: 61, stock: 9,
    image: "https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#a9b0c2"],
    desc: "A 15-inch ultra-thin laptop that still hits 20 hours of battery — the daily driver for people who hate carrying a charger.",
    specs: { Display: "15\" 2.5K OLED", Chip: "Nexora N2", RAM: "16GB", Storage: "512GB SSD", Battery: "20 hrs" }
  },
  {
    id: 28, name: "Aurelia Lens Pro X", brand: "Aurelia", category: "cameras",
    price: 1799, oldPrice: 1999, rating: 4.9, reviews: 34, stock: 4,
    image: "https://images.unsplash.com/photo-1519638831568-d9897f54ed69?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1519638831568-d9897f54ed69?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "A full-frame mirrorless body with a 45MP sensor and pro-grade weather sealing, for photographers who don't compromise.",
    specs: { Sensor: "45MP full-frame", ISO: "50–102400", Video: "8K30 / 4K120", Stabilization: "8-stop IBIS" }
  },
  {
    id: 29, name: "Nexora Pulse Ultra", brand: "Nexora", category: "smartphones",
    price: 1199, oldPrice: 1299, rating: 4.9, reviews: 143, stock: 11,
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=800&auto=format&fit=crop"],
    tag: "sale", colors: ["#1e222d", "#00e6c3", "#ff5d3b"],
    desc: "The top of the Pulse range: periscope zoom, titanium frame and satellite SOS for when there's no signal at all.",
    specs: { Display: "6.9\" LTPO AMOLED, 144Hz", Chip: "Nexora X4 Pro", RAM: "16GB", Storage: "512GB", Camera: "50MP + 48MP + 12MP periscope" }
  },
  {
    id: 30, name: "Aurelia Home Theater Hub", brand: "Aurelia", category: "smart-home",
    price: 899, oldPrice: 999, rating: 4.7, reviews: 29, stock: 8,
    image: "https://images.unsplash.com/photo-1558002038-bfe98f8dcaa3?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1558002038-bfe98f8dcaa3?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "A whole-home audio and automation hub with room-filling sound and Dolby Atmos support for a true home theater.",
    specs: { Audio: "Dolby Atmos, 4 drivers", Connectivity: "Wi-Fi 6, Zigbee, Thread", Ports: "HDMI eARC, optical", Voice: "Built-in assistant" }
  },

  /* ===== Luxury / flagship-plus tier ===== */
  {
    id: 31, name: "Nexora Book Studio 18", brand: "Nexora", category: "laptops",
    price: 2799, oldPrice: 3099, rating: 4.9, reviews: 18, stock: 3,
    image: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "An 18-inch mobile workstation built for video editing and 3D rendering — discrete pro-grade graphics and a color-calibrated display out of the box.",
    specs: { Display: "18\" 4K mini-LED, 120Hz", Chip: "Nexora N3 Pro 16-core", RAM: "64GB", Storage: "2TB SSD", GPU: "Nexora RTX-class Pro" }
  },
  {
    id: 32, name: "Aurelia Cinema Camera 8K", brand: "Aurelia", category: "cameras",
    price: 3499, oldPrice: null, rating: 4.9, reviews: 9, stock: 2,
    image: "https://images.unsplash.com/photo-1500634245200-e5245c7574ef?q=80&w=800&auto=format&fit=crop",
    gallery: ["https://images.unsplash.com/photo-1500634245200-e5245c7574ef?q=80&w=800&auto=format&fit=crop"],
    tag: "new", colors: ["#1e222d"],
    desc: "A cinema-grade 8K body with a Super35 sensor and internal RAW recording — the camera behind the scenes, not in front of the influencer.",
    specs: { Sensor: "Super35, 8K RAW", "Dynamic Range": "16 stops", Mounts: "Interchangeable, PL/EF", Recording: "Internal ProRes RAW" }
  }
];

const NEXORA_CATEGORIES = [
  { slug: "smartphones", label: "Smartphones", icon: "fa-mobile-screen" },
  { slug: "laptops", label: "Laptops", icon: "fa-laptop" },
  { slug: "tablets", label: "Tablets", icon: "fa-tablet-screen-button" },
  { slug: "smartwatches", label: "Smartwatches", icon: "fa-clock" },
  { slug: "earbuds", label: "Earbuds", icon: "fa-headphones-simple" },
  { slug: "headphones", label: "Headphones", icon: "fa-headphones" },
  { slug: "cameras", label: "Cameras", icon: "fa-camera" },
  { slug: "gaming", label: "Gaming", icon: "fa-gamepad" },
  { slug: "accessories", label: "Accessories", icon: "fa-plug" },
  { slug: "smart-home", label: "Smart Home", icon: "fa-house-signal" }
];

/* ==========================================================================
   Live product/category accessors (Phase 10 wiring)

   The admin dashboard (js/admin.js) stores its editable copy of products
   and categories under these same localStorage keys. Every storefront page
   reads through nx_getAllProducts()/nx_getAllCategories() instead of the
   raw NEXORA_PRODUCTS/NEXORA_CATEGORIES constants above, so a product the
   admin creates, edits or deletes shows up on the storefront immediately —
   no separate sync step needed. NEXORA_PRODUCTS/NEXORA_CATEGORIES remain as
   the seed/default data and the fallback when nothing has been edited yet.
   ========================================================================== */

const NX_PRODUCTS_KEY = "nexora_admin_products";
const NX_CATEGORIES_KEY = "nexora_admin_categories";

function nx_getAllProducts() {
  try {
    const stored = JSON.parse(localStorage.getItem(NX_PRODUCTS_KEY));
    if (Array.isArray(stored) && stored.length) return stored;
  } catch { /* fall through to defaults */ }
  return NEXORA_PRODUCTS;
}

function nx_getAllCategories() {
  try {
    const stored = JSON.parse(localStorage.getItem(NX_CATEGORIES_KEY));
    if (Array.isArray(stored) && stored.length) return stored;
  } catch { /* fall through to defaults */ }
  return NEXORA_CATEGORIES;
}

function nx_findProduct(id) {
  return nx_getAllProducts().find(p => p.id === Number(id));
}
