/* ==========================================================================
   NEXORA — protect.js
   © 2026 NEXORA Electronics. All Rights Reserved. See /LICENSE.

   Deterrent-level front-end protection. This raises friction for casual
   copying (right-click "Save As", drag-and-drop image theft, opening
   dev tools by accident) — it is NOT real security. Any visitor with
   basic browser knowledge can still inspect this site's HTML/CSS/JS, and
   nothing running in the browser can change that. Your actual protection
   is the LICENSE file (the legal right to act if someone republishes
   your work) plus normal good practice (don't commit secrets to a public
   repo, keep the backend's real logic server-side).

   Toggle this off entirely by setting NEXORA_CONFIG.ENABLE_COPY_PROTECTION
   to false in js/config.js — useful while you're developing.
   ========================================================================== */

(function () {
  if (typeof NEXORA_CONFIG === "undefined" || !NEXORA_CONFIG.ENABLE_COPY_PROTECTION) return;

  // Console warning banner — the same pattern big consumer sites use to
  // warn people against pasting untrusted code into their own console.
  const bannerStyle = "color:#00e6c3; font-size:20px; font-weight:700; font-family:sans-serif;";
  const subStyle = "color:#a9b0c2; font-size:13px; font-family:sans-serif;";
  console.log("%cSTOP", bannerStyle);
  console.log(
    "%cThis is a browser feature intended for developers. If someone told you to " +
    "paste code here, it's very likely a scam and could give them access to your " +
    "account. This site and its source are © NEXORA Electronics — see /LICENSE.",
    subStyle
  );

  // Disable the right-click context menu site-wide (deterrent only).
  document.addEventListener("contextmenu", (e) => e.preventDefault());

  // Prevent images (including product photos) from being dragged out to
  // the desktop or another tab.
  document.addEventListener("dragstart", (e) => {
    if (e.target.tagName === "IMG") e.preventDefault();
  });

  // Block the most common "view/save source" and dev-tools keyboard
  // shortcuts. Again: a deterrent, not a barrier — dev tools can still be
  // opened via the browser menu on every browser.
  document.addEventListener("keydown", (e) => {
    const key = e.key.toUpperCase();
    const blockedCombo =
      key === "F12" ||
      (e.ctrlKey && key === "U") ||                          // view-source
      (e.ctrlKey && key === "S") ||                           // save page
      (e.ctrlKey && e.shiftKey && (key === "I" || key === "J" || key === "C")); // dev tools panels
    if (blockedCombo) e.preventDefault();
  });
})();
