/* ==========================================================================
   NEXORA — cart-page.js
   Renders cart.html and wishlist.html from the cart.js / data.js engines.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  if (document.querySelector("[data-cart-page]")) nx_renderCartPage();
  if (document.querySelector("[data-wishlist-page]")) nx_renderWishlistPage();
});

let nx_activeCoupon = nx_getActiveCoupon();

function nx_renderCartPage() {
  const { lines, subtotal, discount, shipping, tax, total } = nx_cartTotals(nx_activeCoupon);
  const body = document.querySelector("[data-cart-body]");
  const emptyState = document.querySelector("[data-cart-empty]");
  const filledState = document.querySelector("[data-cart-filled]");

  if (!lines.length) {
    if (emptyState) emptyState.style.display = "block";
    if (filledState) filledState.style.display = "none";
    return;
  }
  if (emptyState) emptyState.style.display = "none";
  if (filledState) filledState.style.display = "grid";

  body.innerHTML = lines.map(l => `
    <tr>
      <td>
        <div class="cart-item-info">
          <div class="thumb"><img src="${l.product.image}" alt="${l.product.name}"></div>
          <div>
            <h4>${l.product.name}</h4>
            <span>${l.product.category.replace("-", " ")}</span>
            <div><button class="remove-link" onclick="nx_removeFromCart(${l.id}); nx_renderCartPage();">Remove</button></div>
          </div>
        </div>
      </td>
      <td>$${l.product.price.toLocaleString()}</td>
      <td>
        <div class="qty-stepper">
          <button onclick="nx_updateQty(${l.id}, ${l.qty - 1}); nx_renderCartPage();">−</button>
          <input type="text" value="${l.qty}" readonly>
          <button onclick="nx_updateQty(${l.id}, ${l.qty + 1}); nx_renderCartPage();">+</button>
        </div>
      </td>
      <td><strong>$${l.lineTotal.toLocaleString()}</strong></td>
    </tr>
  `).join("");

  document.querySelector("[data-sum-subtotal]").textContent = `$${subtotal.toFixed(2)}`;
  document.querySelector("[data-sum-discount]").textContent = discount ? `-$${discount.toFixed(2)}` : "$0.00";
  document.querySelector("[data-sum-shipping]").textContent = shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`;
  document.querySelector("[data-sum-tax]").textContent = `$${tax.toFixed(2)}`;
  document.querySelector("[data-sum-total]").textContent = `$${total.toFixed(2)}`;

  const couponForm = document.querySelector("[data-coupon-form]");
  if (couponForm && !couponForm.dataset.wired) {
    couponForm.dataset.wired = "true";
    couponForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const code = couponForm.querySelector("input").value.trim().toUpperCase();
      if (NX_COUPONS[code]) {
        nx_activeCoupon = code;
        nx_setActiveCoupon(code);
        nx_toast(`Coupon ${code} applied — ${NX_COUPONS[code] * 100}% off`);
      } else {
        nx_toast("Invalid coupon code", "error");
      }
      nx_renderCartPage();
    });
  }

  const checkoutBtn = document.querySelector("[data-checkout-btn]");
  if (checkoutBtn && !checkoutBtn.dataset.wired) {
    checkoutBtn.dataset.wired = "true";
    checkoutBtn.addEventListener("click", () => {
      window.location.href = "checkout.html";
    });
  }
}

function nx_renderWishlistPage() {
  const ids = nx_getWishlist();
  const products = ids.map(nx_findProduct).filter(Boolean);
  const grid = document.querySelector("[data-wishlist-grid]");
  const emptyState = document.querySelector("[data-wishlist-empty]");

  if (!products.length) {
    if (grid) grid.style.display = "none";
    if (emptyState) emptyState.style.display = "block";
    return;
  }
  if (emptyState) emptyState.style.display = "none";
  if (grid) grid.style.display = "grid";
  nx_renderGrid(grid, products);
}
