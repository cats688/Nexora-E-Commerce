/* ==========================================================================
   NEXORA — products.js  (Products & Categories page controller)
   ========================================================================== */

const NX_PAGE_SIZE = 8;

let nx_state = {
  category: new Set(),
  brand: new Set(),
  maxPrice: 3500,
  minRating: 0,
  search: "",
  sort: "featured",
  page: 1
};

document.addEventListener("DOMContentLoaded", () => {
  if (!document.querySelector(".products-layout")) return;

  nx_hydrateFromURL();
  nx_buildCategoryFilters();
  nx_buildBrandFilters();
  nx_wireControls();
  nx_applyFilters();
});

function nx_hydrateFromURL() {
  const params = new URLSearchParams(window.location.search);
  const cat = params.get("category");
  if (cat) nx_state.category.add(cat);
  const q = params.get("q");
  if (q) {
    nx_state.search = q;
    const searchInputs = document.querySelectorAll(".search-box input");
    searchInputs.forEach(i => (i.value = q));
  }
}

function nx_buildCategoryFilters() {
  const wrap = document.querySelector("[data-category-filters]");
  if (!wrap) return;
  wrap.innerHTML = nx_getAllCategories().map(c => {
    const count = nx_getAllProducts().filter(p => p.category === c.slug).length;
    const checked = nx_state.category.has(c.slug) ? "checked" : "";
    return `
      <label class="filter-option">
        <input type="checkbox" value="${c.slug}" ${checked} data-cat-check>
        ${c.label}
        <span class="count">${count}</span>
      </label>`;
  }).join("");

  wrap.querySelectorAll("[data-cat-check]").forEach(cb => {
    cb.addEventListener("change", () => {
      cb.checked ? nx_state.category.add(cb.value) : nx_state.category.delete(cb.value);
      nx_state.page = 1;
      nx_applyFilters();
    });
  });
}

function nx_buildBrandFilters() {
  const wrap = document.querySelector("[data-brand-filters]");
  if (!wrap) return;
  const brands = [...new Set(nx_getAllProducts().map(p => p.brand))].sort();
  wrap.innerHTML = brands.map(b => {
    const count = nx_getAllProducts().filter(p => p.brand === b).length;
    const checked = nx_state.brand.has(b) ? "checked" : "";
    return `
      <label class="filter-option">
        <input type="checkbox" value="${b}" ${checked} data-brand-check>
        ${b}
        <span class="count">${count}</span>
      </label>`;
  }).join("");

  wrap.querySelectorAll("[data-brand-check]").forEach(cb => {
    cb.addEventListener("change", () => {
      cb.checked ? nx_state.brand.add(cb.value) : nx_state.brand.delete(cb.value);
      nx_state.page = 1;
      nx_applyFilters();
    });
  });
}

function nx_wireControls() {
  const priceRange = document.querySelector("[data-price-range]");
  const priceLabel = document.querySelector("[data-price-label]");
  if (priceRange) {
    priceRange.addEventListener("input", () => {
      nx_state.maxPrice = Number(priceRange.value);
      priceLabel.textContent = `Up to $${Number(priceRange.value).toLocaleString()}`;
      nx_state.page = 1;
      nx_applyFilters();
    });
  }

  document.querySelectorAll("[data-rating-check]").forEach(cb => {
    cb.addEventListener("change", () => {
      nx_state.minRating = cb.checked ? Number(cb.value) : 0;
      document.querySelectorAll("[data-rating-check]").forEach(other => { if (other !== cb) other.checked = false; });
      nx_state.page = 1;
      nx_applyFilters();
    });
  });

  const sortSelect = document.querySelector(".sort-select");
  if (sortSelect) {
    sortSelect.addEventListener("change", () => {
      nx_state.sort = sortSelect.value;
      nx_applyFilters();
    });
  }

  document.querySelectorAll(".search-box input").forEach(input => {
    input.addEventListener("input", () => {
      nx_state.search = input.value.trim().toLowerCase();
      nx_state.page = 1;
      nx_applyFilters();
    });
  });

  const clearBtn = document.querySelector("[data-clear-filters]");
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      nx_state = { category: new Set(), brand: new Set(), maxPrice: 3500, minRating: 0, search: "", sort: "featured", page: 1 };
      document.querySelectorAll("[data-cat-check]").forEach(cb => (cb.checked = false));
      document.querySelectorAll("[data-brand-check]").forEach(cb => (cb.checked = false));
      document.querySelectorAll("[data-rating-check]").forEach(cb => (cb.checked = false));
      if (priceRange) priceRange.value = 3500;
      if (priceLabel) priceLabel.textContent = "Up to $3,500";
      document.querySelectorAll(".search-box input").forEach(i => (i.value = ""));
      nx_applyFilters();
    });
  }
}

function nx_filteredProducts() {
  let list = [...nx_getAllProducts()];

  if (nx_state.category.size) list = list.filter(p => nx_state.category.has(p.category));
  if (nx_state.brand.size) list = list.filter(p => nx_state.brand.has(p.brand));
  if (nx_state.maxPrice) list = list.filter(p => p.price <= nx_state.maxPrice);
  if (nx_state.minRating) list = list.filter(p => p.rating >= nx_state.minRating);
  if (nx_state.search) {
    list = list.filter(p =>
      p.name.toLowerCase().includes(nx_state.search) ||
      p.category.toLowerCase().includes(nx_state.search) ||
      p.brand.toLowerCase().includes(nx_state.search)
    );
  }

  switch (nx_state.sort) {
    case "price-asc": list.sort((a, b) => a.price - b.price); break;
    case "price-desc": list.sort((a, b) => b.price - a.price); break;
    case "rating": list.sort((a, b) => b.rating - a.rating); break;
    case "newest": list.sort((a, b) => (b.tag === "new") - (a.tag === "new")); break;
    default: break;
  }

  return list;
}

function nx_applyFilters() {
  const all = nx_filteredProducts();
  const totalPages = Math.max(1, Math.ceil(all.length / NX_PAGE_SIZE));
  nx_state.page = Math.min(nx_state.page, totalPages);
  const start = (nx_state.page - 1) * NX_PAGE_SIZE;
  const pageItems = all.slice(start, start + NX_PAGE_SIZE);

  nx_renderGrid(document.querySelector("[data-product-grid]"), pageItems);

  const countEl = document.querySelector("[data-result-count]");
  if (countEl) countEl.textContent = `${all.length} product${all.length === 1 ? "" : "s"} found`;

  nx_renderActiveChips();
  nx_renderPagination(totalPages);
}

function nx_renderActiveChips() {
  const wrap = document.querySelector("[data-active-chips]");
  if (!wrap) return;
  const chips = [];
  nx_state.category.forEach(c => {
    const label = nx_getAllCategories().find(x => x.slug === c)?.label || c;
    chips.push(`<span class="chip">${label} <button onclick="nx_removeCategoryChip('${c}')">&times;</button></span>`);
  });
  nx_state.brand.forEach(b => {
    chips.push(`<span class="chip">${b} <button onclick="nx_removeBrandChip('${b}')">&times;</button></span>`);
  });
  if (nx_state.search) chips.push(`<span class="chip">"${nx_state.search}" <button onclick="nx_clearSearchChip()">&times;</button></span>`);
  wrap.innerHTML = chips.join("");
}

function nx_removeCategoryChip(slug) {
  nx_state.category.delete(slug);
  document.querySelectorAll(`[data-cat-check][value="${slug}"]`).forEach(cb => (cb.checked = false));
  nx_applyFilters();
}
function nx_removeBrandChip(brand) {
  nx_state.brand.delete(brand);
  document.querySelectorAll(`[data-brand-check][value="${brand}"]`).forEach(cb => (cb.checked = false));
  nx_applyFilters();
}
function nx_clearSearchChip() {
  nx_state.search = "";
  document.querySelectorAll(".search-box input").forEach(i => (i.value = ""));
  nx_applyFilters();
}

function nx_renderPagination(totalPages) {
  const wrap = document.querySelector(".pagination");
  if (!wrap) return;
  if (totalPages <= 1) { wrap.innerHTML = ""; return; }
  let html = "";
  for (let i = 1; i <= totalPages; i++) {
    html += `<button class="${i === nx_state.page ? "active" : ""}" onclick="nx_goToPage(${i})">${i}</button>`;
  }
  wrap.innerHTML = html;
}

function nx_goToPage(page) {
  nx_state.page = page;
  nx_applyFilters();
  document.querySelector(".products-layout")?.scrollIntoView({ behavior: "smooth", block: "start" });
}
