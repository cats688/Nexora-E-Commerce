# NEXORA Electronics — E-Commerce Website

A premium, animated, full-stack e-commerce storefront for a fictional
electronics brand, built end-to-end following the 13-phase plan in
`NEXORA_Claude_AI_Phase_Prompts.docx`. Built for a portfolio, resume,
college project, or interview demo.

---

## Features

- **Storefront** — homepage, 10 categories, 32 products across 4 brands ($16.99 budget items to $3,499 pro-grade gear), search, filters (category/brand/price/rating), sort, pagination
- **Product details** — gallery, color/size selection, quantity stepper, spec table, tabs
- **Cart & wishlist** — persistent, coupon codes, quantity controls, move-to-cart
- **Authentication** — register, login, forgot/reset password, profile page
- **Checkout** — 3-step flow (shipping → payment → review), mock payment, tax + shipping calculation
- **Orders** — order confirmation, order history, order detail with a **live-updating** delivery tracker and a downloadable/printable invoice per order
- **Admin dashboard** — login, stats with charts (Chart.js), product/category/order/user/review management, contact messages, newsletter subscribers
- **Backend API** — Flask + MySQL, JWT auth, role-based authorization, parameterized queries throughout
- **Design** — dark graphite theme, signal-cyan/ember accents, Space Grotesk + Inter type, fully responsive, scroll-reveal and micro-interaction animations

## Screenshots

> Add your own screenshots here before publishing — open each page with
> Live Server, capture it, and drop the images into an `assets/img/screenshots/`
> folder, then reference them below:
>
> `![Homepage](assets/img/screenshots/home.png)`
> `![Products](assets/img/screenshots/products.png)`
> `![Checkout](assets/img/screenshots/checkout.png)`
> `![Admin Dashboard](assets/img/screenshots/admin.png)`

## Technology stack

| Layer | Tech |
|---|---|
| Frontend | HTML5, CSS3, vanilla JavaScript, Font Awesome icons, Chart.js (admin charts) |
| Backend | Python, Flask, Flask-CORS, PyJWT, Werkzeug |
| Database | MySQL (schema + seed data provided) |
| Auth | JWT tokens, `werkzeug.security` password hashing (PBKDF2) |

The **frontend runs standalone** — every page works immediately with demo
data and a localStorage-backed cart/wishlist/auth/orders/admin, so you can
open it and see the full site with zero setup. The **backend is a
complete, working Flask + MySQL API** (Phases 6–10) ready to wire in — see
"Connecting frontend to backend" below.

## Folder structure

```
NEXORA/
├── LICENSE                       Proprietary "all rights reserved" license
├── robots.txt                    Keeps account/checkout/admin pages out of search engines
├── sitemap.xml                   Submit to Google Search Console once deployed on a real domain
├── index.html                    Homepage
├── products.html                 Product listing — filters, search, sort, pagination
├── product-details.html          Single product page
├── cart.html                     Cart
├── wishlist.html                 Wishlist
├── checkout.html                 3-step checkout (shipping / payment / review)
├── order-confirmation.html       Post-checkout confirmation
├── orders.html                   Customer order history
├── order-detail.html             Single order detail + status tracker
├── login.html / register.html / forgot-password.html / reset-password.html / profile.html
├── about.html / contact.html
├── admin-login.html              Admin sign-in (role-gated)
├── admin-dashboard.html          Admin dashboard shell (stats, charts, CRUD tables)
├── css/
│   └── style.css                 Full design system (tokens, components, pages, animations)
├── js/
│   ├── config.js                 API base URL, Razorpay key, copyright-protection toggle
│   ├── protect.js                Deterrent-level right-click / devtools-shortcut protection
│   ├── data.js                   Demo product catalog (mirrors the MySQL schema)
│   ├── main.js                   Header, drawer, reveal-on-scroll, toasts
│   ├── render.js                 Shared product card markup
│   ├── cart.js                   Cart + wishlist engine (localStorage now, API-ready)
│   ├── cart-page.js              Cart/wishlist page rendering
│   ├── products.js               Filter/sort/search/pagination controller
│   ├── product-details.js        Product detail page controller
│   ├── auth.js                   Login/register/forgot/reset/profile logic
│   ├── checkout.js               Checkout steps, order creation, order history/detail rendering
│   └── admin.js                  Admin auth guard, stats, charts, product/order/user/review CRUD
├── assets/img/                   Logo, favicons, brand photography used across the site
└── backend/
    ├── app.py                    Flask entrypoint
    ├── config.py                 Reads .env (including CORS_ORIGINS)
    ├── requirements.txt
    ├── .env.example
    ├── models/
    │   └── user.py
    ├── routes/
    │   ├── auth_routes.py         Register / login / profile / logout
    │   ├── product_routes.py
    │   ├── category_routes.py
    │   ├── cart_routes.py
    │   ├── wishlist_routes.py
    │   ├── order_routes.py        Checkout, order history, order status
    │   ├── review_routes.py
    │   ├── contact_routes.py
    │   ├── newsletter_routes.py
    │   ├── admin_routes.py        Role-protected admin dashboard APIs
    │   ├── payment_routes.py      Razorpay order creation + signature verification
    │   └── shipping_routes.py     Shiprocket serviceability, shipment booking, live tracking
    ├── utils/
    │   ├── db.py                   MySQL connection + parameterized query helper
    │   ├── responses.py            Consistent JSON response format
    │   ├── auth_middleware.py      @token_required / @admin_required
    │   └── shiprocket.py           Real Shiprocket API client (login, serviceability, booking, tracking)
    └── database/
        ├── schema.sql              13 tables: users, products, cart, orders, reviews, newsletter, etc.
        └── seed.sql                Demo products, categories and an admin user
```

## Installation guide

### 1. Running the frontend (VS Code)

1. Open the `NEXORA` folder in VS Code.
2. Install the **Live Server** extension (or use any static file server).
3. Right-click `index.html` → **Open with Live Server**.
4. The site opens at something like `http://127.0.0.1:5500`.

No build step, no `npm install` — it's plain HTML/CSS/JS.

Try it out: add items to the cart, apply coupon code `NEXORA10` on the
cart page, complete the 3-step checkout, register an account then log in,
check `orders.html` for order history, and open `admin-login.html` with
the demo admin credentials below for the dashboard.

### 2. Python virtual environment & backend dependencies

```bash
cd backend

# Create and activate a virtual environment
python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate     # macOS/Linux

# Install dependencies
pip install -r requirements.txt
```

### 3. Environment variables

```bash
copy .env.example .env       # Windows
cp .env.example .env         # macOS/Linux
```

Then edit `.env`:
- Set `MYSQL_PASSWORD` (and other MySQL_* values) to match your local install.
- Set `SECRET_KEY` / `JWT_SECRET_KEY` to random strings — never reuse the defaults in production.
- Set `CORS_ORIGINS` to the exact URL Live Server gives you if it differs from the defaults.

### 4. MySQL setup / database setup

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p nexora_db < database/seed.sql
```

This creates the `nexora_db` database, all 13 tables, and seeds demo
categories, products and an admin account.

> The demo admin row in `seed.sql` uses a placeholder password hash — see
> the comment above it in that file for the one-line command to generate a
> real hash for `Admin123` (or your own password) before relying on it.

### 5. Running Flask

```bash
python app.py
```

The API runs at `http://127.0.0.1:5000`. Visiting `http://127.0.0.1:5000/`
returns a small JSON health check confirming the server is up.

## Connecting frontend to backend

The frontend currently reads `NEXORA_PRODUCTS` from `js/data.js` and
stores cart/wishlist/auth/orders in `localStorage`. Every function in
`cart.js`, `auth.js`, `checkout.js` and `admin.js` is written to mirror a
REST call 1:1 (see the comments at the top of each file), so swapping
localStorage for `fetch()` calls to the endpoints below does not require
restructuring the UI code.

## API documentation

All endpoints are prefixed with `/api`. Protected routes require an
`Authorization: Bearer <token>` header (token returned from login).
Admin-only routes additionally require the token's `role` claim to be `admin`.

| Feature | Method & endpoint | Auth |
|---|---|---|
| Register | `POST /api/auth/register` | — |
| Login | `POST /api/auth/login` | — |
| Profile | `GET /api/auth/profile` | User |
| Products | `GET /api/products?category=&q=&sort=&page=` | — |
| Product detail | `GET /api/products/:id` | — |
| Categories | `GET /api/categories` | — |
| Cart | `GET/POST /api/cart`, `PUT/DELETE /api/cart/items/:id` | User |
| Wishlist | `GET /api/wishlist`, `POST/DELETE /api/wishlist/items/:id` | User |
| Orders | `POST /api/orders` (checkout), `GET /api/orders`, `GET /api/orders/:id` | User |
| Reviews | `GET /api/reviews?product_id=`, `POST /api/reviews` | User (post) |
| Contact | `POST /api/contact` | — |
| Newsletter | `POST /api/newsletter/subscribe` | — |
| Admin stats | `GET /api/admin/stats` | Admin |
| Admin products | `POST/PUT/DELETE /api/admin/products[/:id]` | Admin |
| Admin categories | `POST/PUT/DELETE /api/admin/categories[/:id]` | Admin |
| Admin users | `GET /api/admin/users` | Admin |
| Admin orders | `GET /api/admin/orders`, `PUT /api/admin/orders/:id/status` | Admin |
| Create payment order | `POST /api/payments/create-order` | User |
| Verify payment | `POST /api/payments/verify` | User |
| Check delivery serviceability | `POST /api/shipping/serviceability` | — |
| Book real courier shipment | `POST /api/shipping/create-shipment` | Admin |
| Track a shipment | `GET /api/shipping/track/:order_id` | User |

Every response follows `{ "success": bool, "data"|"error": ..., "message"?: str }`.

## Demo credentials

**Storefront (frontend-only, localStorage):** register a new account on
`register.html` — it's stored locally in your browser, so you can log in
with the same browser afterward on `login.html`.

**Admin dashboard (frontend-only, localStorage):**
- Email: `admin@nexora.com`
- Password: `Admin123`
- Open `admin-login.html` to sign in.

**Backend (once MySQL is seeded):** the same `admin@nexora.com` row is
inserted by `seed.sql` — regenerate its password hash first (see the note
in that file) before logging in against the real API.

## Testing

This project was verified with the following checks before release —
re-run them any time after making changes:

```bash
# JS syntax check (from the NEXORA/js folder, requires Node.js)
for f in *.js; do node --check "$f"; done

# Python syntax check (from NEXORA/backend, any environment with Python 3)
find . -name "*.py" -exec python3 -m py_compile {} \;
```

Manually exercised flows: register → login → browse/filter products →
add to cart → apply coupon → checkout (all 3 steps) → order confirmation
→ order history → order detail status tracker → wishlist add/remove →
contact form → newsletter signup → admin login → admin stats/charts →
admin product create/edit/delete → admin order status update.

Backend routes were reviewed for: parameterized SQL (no string-built
queries from user input), password hashing via `werkzeug.security`, JWT
expiry and signature checks, and `@admin_required` gating on every admin
route so a normal user's token is rejected with `403`.

## Troubleshooting

| Problem | Likely cause / fix |
|---|---|
| Product images don't load | They come from Unsplash over the network — check your internet connection, or swap the URLs in `js/data.js` for files in `assets/img/`. |
| Frontend can't reach the API | Confirm `python app.py` is running on port 5000, and that the URL Live Server gives you is listed in `CORS_ORIGINS` in `backend/.env`. |
| `Could not connect to MySQL` on startup | Check `MYSQL_HOST/PORT/USER/PASSWORD/DB` in `backend/.env`, and that `schema.sql` has been run to create `nexora_db`. |
| Admin login fails against the real API | The seeded password hash is a placeholder — regenerate it per the comment in `database/seed.sql`. |
| `403 Admin access required` | The logged-in user's JWT has `role: customer`. Log in with the seeded admin account, or promote a user's `role` column to `admin` in MySQL. |
| Cart/wishlist/orders "disappear" | They're stored in that browser's `localStorage`. Clearing site data or switching browsers/incognito resets them — this is expected in frontend-only mode. |

## Phase map

This build follows the 13-phase plan in the original prompt document:

1. **Architecture** — this README + folder structure
2. **Homepage** — `index.html`
3. **Products & categories** — `products.html`, `product-details.html`
4. **Cart & wishlist** — `cart.html`, `wishlist.html`, `cart.js`
5. **Authentication** — `login.html`, `register.html`, `forgot-password.html`, `reset-password.html`, `profile.html`, `auth.js`
6. **Flask backend** — `backend/app.py` and `backend/routes/`
7. **MySQL database** — `backend/database/schema.sql`, `seed.sql`
8. **REST API integration** — swap `data.js`/localStorage calls for `fetch()` per the API table above
9. **Checkout & orders** — `checkout.html`, `order-confirmation.html`, `orders.html`, `order-detail.html`, `js/checkout.js`, `backend/routes/order_routes.py`
10. **Admin dashboard** — `admin-login.html`, `admin-dashboard.html`, `js/admin.js`, `backend/routes/admin_routes.py`
11. **Animation & UI polish** — scroll reveals, hero glow/particles, hover states, toasts, skeleton loading, modal transitions, counter animations across `main.js`/`admin.js`/`style.css`
12. **Security, testing & optimization** — hashed passwords, JWT expiry, parameterized SQL (whitelisted column names, never raw user input in queries), CORS scoped to named origins, syntax-checked JS/Python, manual flow testing (see above)
13. **Final setup & README** — this file, `.gitignore`, `.env.example`, API docs, demo credentials, troubleshooting

## Going live — real accounts, real payments, protected code

This project ships with three things specifically so it can go from
"demo" to a hostable, customer-facing site:

**1. Real accounts (backend-connected auth)**
`js/auth.js` is hybrid: with `NEXORA_CONFIG.API_BASE_URL` (in
`js/config.js`) left empty, accounts live only in that browser's
localStorage. Deploy `/backend` (steps above), then set
`API_BASE_URL: "https://your-api-domain.com"` in `js/config.js` — every
register/login call automatically switches to the real Flask + MySQL API,
with `werkzeug`-hashed passwords and real JWTs. No other code changes needed.

**2. Real payments (Razorpay)**
`checkout.html`/`js/checkout.js` include the real Razorpay checkout
widget. Card/UPI payments open an actual Razorpay popup, and the backend
(`backend/routes/payment_routes.py`) creates the order and verifies the
payment signature server-side (`HMAC-SHA256`) before an order is ever
saved — this is the same verification pattern Razorpay's own docs
recommend, not just "trust the browser". To accept real payments:
  1. Create a free account at [razorpay.com](https://razorpay.com) and grab your **Key Id** and **Key Secret** (test mode first).
  2. Put `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` in `backend/.env`.
  3. Put the same `RAZORPAY_KEY_ID` in `js/config.js`.
  4. Set `API_BASE_URL` in `js/config.js` so checkout can reach `/api/payments/*`.
  5. Test with [Razorpay's test cards](https://razorpay.com/docs/payments/payments/test-card-upi-details/), then switch to live keys (`rzp_live_...`) when ready to accept real money.

Cash-on-delivery, and card/UPI when no backend is configured yet, both
fall back to the original mock flow — so the site is always demoable
even before a gateway is wired up.

**3. Product catalog**
32 products across 10 categories and 4 brands (`Nexora` house brand,
plus `Voltrix` for budget picks, `Pulseon` for gaming/mid-range, and
`Aurelia` for premium/pro gear), spanning $16.99 accessories to $3,499
cinema cameras — filterable by category, brand, price and rating on
`products.html`. Add more any time by appending entries to
`NEXORA_PRODUCTS` in `js/data.js` (each needs a unique `id`).

**4. Order tracking that actually moves**
Every order gets a real `estimatedDelivery` date (2-3 days for express,
5-7 for standard, calculated from the moment it's placed) and a status
that progresses through pending → confirmed → processing → shipped →
delivered on its own — `order-detail.html` polls and repaints itself
every few seconds so you can watch it happen live instead of it being
frozen at "pending". By default the full journey is compressed into ~2
minutes (`DEMO_FAST_TRACKING: true` in `js/config.js`) so it's visibly
alive while testing/demoing; set it to `false` once this is a real store
so status progresses on the same realistic multi-day timeline as the
delivery date shown to the customer. An admin manually changing an
order's status (from the admin dashboard) always takes precedence and
stops further auto-progression for that order.

Each order also gets a **real, itemized invoice** — click "Download
Invoice" on `order-detail.html` to open a print-formatted document
(billing/shipping address, line items, totals) that can be printed or
saved as a PDF straight from the browser's print dialog.

> Honest limitation: this is a demo storefront for a fictional brand —
> there is no warehouse or courier behind it, so nothing physically
> ships. What's real is everything *digital* a customer would see: a
> genuine payment charge via Razorpay, a persisted order record, an
> accurate delivery estimate, a live-updating tracker, and a proper
> invoice. Wiring this to an actual fulfillment provider (e.g. Shiprocket,
> Shippo) would be the next step for a real launch, and would plug into
> `backend/routes/order_routes.py` the same way payments plug into
> `payment_routes.py`.

**5. Copyright / anti-copy protection**
- `LICENSE` — a proprietary "all rights reserved" license. Edit the name/email/year before publishing.
- `robots.txt` — keeps account, cart, checkout and admin pages out of Google.
- Every page carries `<meta name="copyright">` and a footer notice with an auto-updating year.
- `js/protect.js` blocks right-click, image drag, and view-source/devtools keyboard shortcuts, and prints a console warning. **Be realistic about this**: it deters casual copying, but no front-end script can stop someone from viewing a public website's HTML/CSS/JS — that's how browsers work. Your real protection is the LICENSE (the legal right to act if someone republishes this) and not publishing your source publicly. Toggle it off anytime via `ENABLE_COPY_PROTECTION: false` in `js/config.js`.

**6. Real courier integration (Shiprocket)**
`backend/utils/shiprocket.py` and `backend/routes/shipping_routes.py` wire
this store to [Shiprocket](https://app.shiprocket.in/register) — a free
account that aggregates dozens of real Indian couriers (Delhivery, Xpressbees,
Ecom Express, Bluedart...) behind one API, which is how most small D2C
brands in India actually ship. Three real things this unlocks once
`SHIPROCKET_EMAIL` / `SHIPROCKET_PASSWORD` / `SHIPROCKET_PICKUP_LOCATION` /
`SHIPROCKET_PICKUP_LOCATION_PINCODE` are set in `backend/.env`:
  - **Checkout** calls `/api/shipping/serviceability` as the customer types
    their pincode and shows a real "Delivery available, arrives in ~N days"
    (or "not serviceable") — genuinely checked against live courier coverage.
  - **Admin dashboard** gets a "Ship via Courier" button per order (once it
    exists in the real backend, not just localStorage) that calls
    `/api/shipping/create-shipment` — this books an actual pickup and
    returns a **real AWB (tracking number)**, stored on the order.
  - **Order detail page** shows that real courier name + AWB + tracking
    link once it's been booked, alongside the built-in status tracker.

For this to do anything, `js/config.js`'s `API_BASE_URL` needs to point at
your deployed backend (see below) — with it empty, checkout/admin skip
straight to the original demo behavior, exactly like the payment and auth
hybrids above.

## Launching for real — from localhost to real customers finding you on Google

This section is the honest version of "how do I make NEXORA a real
business people can find on Google and order from" — what's already built
for you, and what genuinely requires you to take real-world action (no
amount of code can substitute for these, and anyone who claims otherwise
is skipping a step):

**1. Get a domain and host the site (this is what makes a URL exist)**
- Buy a domain (Namecheap, GoDaddy, or India-based registrars like
  Hostinger — roughly $8-15/year for a `.com`).
- Host the **frontend** (this `NEXORA/` folder minus `backend/`) on
  Netlify, Vercel, GitHub Pages, or Cloudflare Pages — all have free tiers
  that work fine for a static HTML/CSS/JS site like this one. Drag-and-drop
  deploy is enough; no build step is needed.
- Host the **backend** (`backend/`) on Render, Railway, or PythonAnywhere
  — set the same environment variables from `.env` in that platform's
  dashboard (never commit your real `.env` to a public repo).
- Host **MySQL** on Railway, PlanetScale, or your host's managed MySQL —
  run `schema.sql` then `seed.sql` against it once.
- Update `js/config.js`'s `API_BASE_URL` to your real backend URL, and
  `backend/.env`'s `CORS_ORIGINS` to your real frontend URL.

**2. Get it onto Google**
- Once the domain is live, create a free [Google Search Console](https://search.google.com/search-console)
  account, verify domain ownership (Search Console walks you through this
  — usually a DNS record or an HTML file upload), and submit
  `https://yourdomain.com/sitemap.xml` (already in this repo — update the
  placeholder URLs in `sitemap.xml` and the `og:`/canonical tags across the
  HTML files to your real domain first).
- Product pages already emit `Product` structured data (JSON-LD) via
  `js/product-details.js` — this is what lets Google show price, stock and
  rating directly in search results, and is required for **Google
  Shopping** / **Google Merchant Center** listings if you want your
  products to appear in Google's Shopping tab.
- Indexing isn't instant — expect days to a few weeks after submission
  before pages reliably show up in search results, and longer to rank well.
  This is normal for every new site, not a NEXORA-specific limitation.

**3. Accept real money (business registration — this part is legally yours to do)**
- Razorpay's **live mode** (real charges, not test cards) requires KYC:
  business PAN, bank account details, and — in India — typically GST
  registration for anything beyond very small/individual sellers. This is
  a compliance step no code can bypass; apply for it from the Razorpay
  dashboard once you have those documents.
- Once approved, swap `RAZORPAY_KEY_ID`/`RAZORPAY_KEY_SECRET` (backend
  `.env`) and `RAZORPAY_KEY_ID` (`js/config.js`) from `rzp_test_...` to
  `rzp_live_...` keys, and set `IS_LIVE: true` in `js/config.js`.

**4. Ship real physical products**
- This repo's product catalog (`js/data.js`) is demo data with stock
  photos — replace it with your actual inventory, real photos, and real
  prices once you have physical stock (or a dropship/wholesale
  arrangement with a supplier).
- Sign up for [Shiprocket](https://app.shiprocket.in/register) (free) and
  add a real pickup address — that's what turns the "Ship via Courier"
  button in the admin dashboard from inert into booking an actual courier
  pickup with a real tracking number (see item 6 above).

**5. What's already done vs. what's on you**

| Already built for you | Requires you, specifically |
|---|---|
| Full storefront, cart, checkout, order tracking UI | Registering a business entity / GST (if required in your country) |
| Real payment verification code (Razorpay) | Getting KYC-approved for Razorpay live mode |
| Real courier booking + tracking code (Shiprocket) | Creating a Shiprocket account + a real pickup address |
| SEO markup (sitemap, structured data, Open Graph) | Buying a domain, hosting the site, submitting to Search Console |
| Copyright protection, security hardening | Sourcing/photographing/pricing real inventory |

None of the "requires you" column is something an AI assistant — or any
piece of code — can complete on your behalf; they're real-world business
and legal steps by design (this is exactly how Amazon, Flipkart and every
other real marketplace works underneath their UI too). What this project
gives you is every line of code fully written and wired so that, the
moment you complete those steps, the site behaves like a real store
immediately — no further development needed to "turn on" real payments,
real shipping, or search visibility.

## Notes

- All product images load from Unsplash over the network — an internet
  connection is needed to see them (or swap `js/data.js` image URLs for
  local files in `assets/img/`). The logo, favicons and brand photography
  in `assets/img/` are already local and need no network access.
- This is a fictional brand built for portfolio/demo purposes only.
